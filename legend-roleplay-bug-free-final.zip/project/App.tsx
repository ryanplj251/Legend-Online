
import React, { useState, useEffect } from 'react';
import { autoMigrate } from './lib/migration';
import Header from './components/Header';
import Hero from './components/Hero';
import About from './components/About';
import Systems from './components/Systems';
import HowToPlay from './components/HowToPlay';
import Rules from './components/Rules';
import DiscordSection from './components/DiscordSection';
import Footer from './components/Footer';
import ForumHome from './components/Forum/ForumHome';
import AdminDashboard from './components/Admin/AdminDashboard';
import LoginModal from './components/Auth/LoginModal';
import UserProfile from './components/Profile/UserProfile';
import ChatSystem from './components/Chat/ChatSystem';
import AccountSettings from './components/Profile/AccountSettings';
import Ranking from './components/Ranking';
import ServerStats from './components/ServerStats';
import NotificationCenter from './components/NotificationCenter';
import UserManagement from './components/Admin/UserManagement';
import VerifiedClientsPanel from './components/Admin/VerifiedClientsPanel';
import IPTracker from './components/Admin/IPTracker';
import SecurityLogs from './components/Admin/SecurityLogs';
import NotificationManager from './components/Admin/NotificationManager';
import NotificationDisplay from './components/NotificationDisplay';
import StaffMenu from './components/Admin/StaffMenu';
import PlayerSearch from './components/PlayerSearch/PlayerSearch';

function App() {
  const [currentView, setCurrentView] = useState('home'); 
  const [user, setUser] = useState<any | null>(null);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [selectedProfile, setSelectedProfile] = useState<string | null>(null);
  const [unreadMessages, setUnreadMessages] = useState(0);

  useEffect(() => {
    // Executar migração de IDs ao iniciar
    autoMigrate().catch(err => console.error('Erro na migração:', err));
    
    // Persistência de Sessão - Manter admin logado
    const savedUser = localStorage.getItem('legend_user');
    if (savedUser) {
      const parsedUser = JSON.parse(savedUser);
      setUser(parsedUser);
      // Se for admin ou fundador específico, manter logado permanentemente
      const permanentAdmins = ['Ruan_LGD', 'Pereira_LGD', 'Galo_LGD', 'p2castro_LGD'];
      if (parsedUser.role === 'admin' || parsedUser.isFounder || permanentAdmins.includes(parsedUser.username)) {
        localStorage.setItem('legend_user', JSON.stringify(parsedUser));
      }
    }
    
    const checkMessages = () => {
      const chats = JSON.parse(localStorage.getItem('legend_chats') || '[]');
      const savedUser = localStorage.getItem('legend_user');
      if (savedUser) {
        const currentUser = JSON.parse(savedUser);
        const unread = chats.filter((c: any) => c.to === currentUser.name && !c.read).length;
        setUnreadMessages(unread);
      }
    };
    
    checkMessages();
    const interval = setInterval(checkMessages, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleLogin = (userData: any) => {
    setUser(userData);
    localStorage.setItem('legend_user', JSON.stringify(userData));
    setIsLoginModalOpen(false);
    
    // REDIRECIONAMENTO AUTOMÁTICO PARA FUNDADORES/ADMINS
    if (userData.role === 'admin' || userData.role === 'staff' || userData.isFounder) {
      setCurrentView('admin');
      window.scrollTo(0, 0);
    }
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('legend_user');
    setCurrentView('home');
  };

  const handleUpdateUser = (updatedUser: any) => {
    setUser(updatedUser);
    localStorage.setItem('legend_user', JSON.stringify(updatedUser));
  };

  const navigateToProfile = (username: string) => {
    setSelectedProfile(username);
    setCurrentView('profile');
    window.scrollTo(0, 0);
  };

  const renderView = () => {
    switch (currentView) {
      case 'forum':
        if (!user) {
          return (
            <div className="min-h-screen flex items-center justify-center pt-20">
              <div className="text-center p-8 bg-slate-900 rounded-2xl border border-blue-500/30">
                <h2 className="text-3xl font-orbitron font-bold mb-4">Acesso Restrito</h2>
                <p className="text-slate-400 mb-6">Você precisa estar logado para acessar o fórum.</p>
                <button 
                  onClick={() => setIsLoginModalOpen(true)}
                  className="bg-blue-600 px-8 py-3 rounded-xl font-bold hover:bg-blue-500 transition-all"
                >
                  Entrar Agora
                </button>
              </div>
            </div>
          );
        }
        return <ForumHome user={user} onProfileClick={navigateToProfile} />;
      
      case 'admin':
        if (user?.role !== 'admin' && user?.role !== 'staff') {
          return (
            <div className="min-h-screen flex items-center justify-center pt-20">
              <div className="text-center p-8 bg-slate-900 rounded-2xl border border-red-500/30">
                <h2 className="text-3xl font-orbitron font-bold mb-4">Área Proibida</h2>
                <p className="text-slate-400 mb-6">Apenas membros da staff podem acessar o painel administrativo.</p>
                <button onClick={() => setCurrentView('home')} className="bg-slate-800 px-8 py-3 rounded-xl font-bold hover:bg-slate-700 transition-all">Voltar para Home</button>
              </div>
            </div>
          );
        }
        return <AdminDashboard user={user} onBack={() => setCurrentView('home')} onNavigate={setCurrentView} />;

      case 'profile':
        return <UserProfile 
          username={selectedProfile || ''} 
          currentUser={user} 
          onOpenChat={() => setCurrentView('chat')}
          onBack={() => setCurrentView('forum')}
        />;

      case 'chat':
        if (!user) return null;
        return <ChatSystem user={user} onBack={() => setCurrentView('home')} />;

      case 'player-search':
        return <PlayerSearch onBack={() => setCurrentView('home')} currentUser={user} onOpenChat={(username) => {
          if (user) {
            localStorage.setItem('legend_active_chat_with', username);
            setCurrentView('chat');
          }
        }} />;

      case 'settings':
        if (!user) return null;
        return <AccountSettings user={user} onUpdate={handleUpdateUser} onBack={() => setCurrentView('home')} />;

      case 'ranking':
        return <Ranking />;

      case 'stats':
        return <ServerStats />;

      case 'users':
        if (user?.role !== 'admin') {
          return (
            <div className="min-h-screen flex items-center justify-center pt-20">
              <div className="text-center p-8 bg-slate-900 rounded-2xl border border-red-500/30">
                <h2 className="text-3xl font-orbitron font-bold mb-4">Acesso Negado</h2>
                <p className="text-slate-400 mb-6">Apenas administradores podem acessar o gerenciamento de usuários.</p>
                <button onClick={() => setCurrentView('home')} className="bg-slate-800 px-8 py-3 rounded-xl font-bold hover:bg-slate-700 transition-all">Voltar para Home</button>
              </div>
            </div>
          );
        }
        return <UserManagement onBack={() => setCurrentView('admin')} />;

      case 'verified-clients':
        return <VerifiedClientsPanel onBack={() => setCurrentView('admin')} user={user} />;

      case 'ip-tracker':
        return <IPTracker onBack={() => setCurrentView('admin')} user={user} />;

      case 'security-logs':
        return <SecurityLogs onBack={() => setCurrentView('admin')} user={user} />;

      case 'notification-manager':
        return <NotificationManager onBack={() => setCurrentView('admin')} user={user} />;

      default:
        return (
          <>
            <section id="home"><Hero /></section>
            <section id="about" className="py-20 bg-slate-900/50"><About /></section>
            <section id="systems" className="py-20 bg-slate-950"><Systems /></section>
            <section id="how-to-play" className="py-20 bg-slate-900/50"><HowToPlay /></section>
            <section id="rules" className="py-20 bg-slate-950"><Rules /></section>
            <section id="discord" className="py-20 bg-blue-900/10"><DiscordSection /></section>
          </>
        );
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col overflow-x-hidden">
      <Header 
        onNavigate={setCurrentView} 
        currentView={currentView}
        user={user}
        unreadMessages={unreadMessages}
        onLoginClick={() => setIsLoginModalOpen(true)}
        onLogout={handleLogout}
      />
      <main className="flex-grow">{renderView()}</main>
      <Footer />
      {isLoginModalOpen && <LoginModal onClose={() => setIsLoginModalOpen(false)} onLogin={handleLogin} />}
      <NotificationCenter />
      <NotificationDisplay />
      {user?.role === 'admin' && <StaffMenu user={user} onNavigate={setCurrentView} onClose={() => {}} />}
    </div>
  );
}

export default App;
