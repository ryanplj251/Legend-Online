
import React, { useState, useRef } from 'react';
import { Mic, Square, Play, Trash2, Send } from 'lucide-react';

interface AudioRecorderProps {
  onSendAudio: (audioBlob: Blob, duration: number) => void;
}

const AudioRecorder: React.FC<AudioRecorderProps> = ({ onSendAudio }) => {
  const [isRecording, setIsRecording] = useState(false);
  const [recordedAudio, setRecordedAudio] = useState<Blob | null>(null);
  const [duration, setDuration] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const audioElementRef = useRef<HTMLAudioElement | null>(null);
  const durationIntervalRef = useRef<NodeJS.Timeout | null>(null);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;
      audioChunksRef.current = [];

      mediaRecorder.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data);
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/wav' });
        setRecordedAudio(audioBlob);
        stream.getTracks().forEach(track => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
      setDuration(0);

      // Contar duração
      durationIntervalRef.current = setInterval(() => {
        setDuration(prev => prev + 1);
      }, 1000);
    } catch (err) {
      console.error('Erro ao acessar microfone:', err);
      alert('Permissão de microfone negada');
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      if (durationIntervalRef.current) {
        clearInterval(durationIntervalRef.current);
      }
    }
  };

  const playAudio = () => {
    if (recordedAudio) {
      const url = URL.createObjectURL(recordedAudio);
      const audio = new Audio(url);
      audioElementRef.current = audio;
      
      audio.onplay = () => setIsPlaying(true);
      audio.onended = () => setIsPlaying(false);
      
      audio.play();
    }
  };

  const sendAudio = () => {
    if (recordedAudio) {
      onSendAudio(recordedAudio, duration);
      setRecordedAudio(null);
      setDuration(0);
    }
  };

  const discardAudio = () => {
    if (isPlaying && audioElementRef.current) {
      audioElementRef.current.pause();
      setIsPlaying(false);
    }
    setRecordedAudio(null);
    setDuration(0);
  };

  const formatDuration = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (recordedAudio) {
    return (
      <div className="flex items-center gap-2 p-2 bg-slate-800 rounded-lg border border-slate-700">
        <button
          onClick={playAudio}
          className="p-2 text-blue-500 hover:bg-slate-700 rounded transition-all"
          title="Ouvir"
        >
          <Play size={18} />
        </button>
        <div className="flex-1">
          <p className="text-xs font-bold text-white">Áudio gravado</p>
          <p className="text-xs text-slate-400">{formatDuration(duration)}</p>
        </div>
        <button
          onClick={discardAudio}
          className="p-2 text-red-500 hover:bg-slate-700 rounded transition-all"
          title="Descartar"
        >
          <Trash2 size={18} />
        </button>
        <button
          onClick={sendAudio}
          className="p-2 text-green-500 hover:bg-slate-700 rounded transition-all"
          title="Enviar"
        >
          <Send size={18} />
        </button>
      </div>
    );
  }

  if (isRecording) {
    return (
      <div className="flex items-center gap-2 p-2 bg-red-900/20 rounded-lg border border-red-500/50">
        <div className="w-3 h-3 rounded-full bg-red-500 animate-pulse" />
        <p className="text-xs font-bold text-red-400">Gravando: {formatDuration(duration)}</p>
        <button
          onClick={stopRecording}
          className="ml-auto p-2 bg-red-600 hover:bg-red-700 text-white rounded transition-all"
          title="Parar"
        >
          <Square size={18} />
        </button>
      </div>
    );
  }

  return (
    <button
      onClick={startRecording}
      className="p-2 text-slate-400 hover:text-red-500 transition-colors"
      title="Gravar áudio"
    >
      <Mic size={20} />
    </button>
  );
};

export default AudioRecorder;
