
import React, { useState, useEffect } from 'react';
import { X, Search, UserPlus, Check, AlertCircle, Loader, Users } from 'lucide-react';
import { legendDB } from '../../lib/database';

interface Friend {
  id: string;
  username: string;
  avatar?: string;
  status: 'online' | 'offline' | 'away';
  lastSeen?: Date;
}

interface AddFriendModalProps {
  onClose: () => void;
  onAddFriend: (friend: Friend) => void;
  currentFriends: Friend[];
}

const AddFriendModal: React.FC<AddFriendModalProps> = ({ onClose, onAddFriend, currentFriends }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState<Friend[]>([]);
  const [allSuggestions, setAllSuggestions] = useState<Friend[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [addedFriends, setAddedFriends] = useState<string[]>([]);
  const [allUsers, setAllUsers] = useState<Friend[]>([]);
  const [activeTab, setActiveTab] = useState<'suggestions' | 'search'>('suggestions');
  const [loading, setLoading] = useState(true);

  // Carregar todos os usuários do IndexedDB
  useEffect(() => {
    const loadUsers = async () => {
      try {
        await legendDB.init();
        const accounts = await legendDB.getAllUsers();
        
        const users: Friend[] = accounts.map((acc) => {
          const lastSeen = localStorage.getItem(`legend_last_seen_${acc.username}`);
          return {
            id: acc.id, // Usar o ID correto do IndexedDB
            username: acc.username,
            avatar: acc.avatar,
            status: Math.random() > 0.3 ? 'online' : (Math.random() > 0.5 ? 'away' : 'offline'),
            lastSeen: lastSeen ? new Date(lastSeen) : new Date()
          };
        });
        
        setAllUsers(users);
        setAllSuggestions(users.filter(u => !currentFriends.some(f => f.username === u.username)));
        setLoading(false);
      } catch (error) {
        console.error('Erro ao carregar usuários:', error);
        setLoading(false);
      }
    };
    
    loadUsers();
  }, [currentFriends]);

  // Buscar usuários
  useEffect(() => {
    if (searchTerm.trim().length < 2) {
      setSearchResults([]);
      setActiveTab('suggestions');
      return;
    }

    setActiveTab('search');
    setIsSearching(true);
    
    // Simular delay de busca
    const timer = setTimeout(() => {
      const results = allUsers.filter(user =>
        user.username.toLowerCase().includes(searchTerm.toLowerCase()) &&
        !currentFriends.some(f => f.username === user.username) &&
        !addedFriends.includes(user.id)
      );
      setSearchResults(results);
      setIsSearching(false);
    }, 300);

    return () => clearTimeout(timer);
  }, [searchTerm, allUsers, currentFriends, addedFriends]);

  const handleAddFriend = (friend: Friend) => {
    onAddFriend(friend);
    setAddedFriends([...addedFriends, friend.id]);
    setSearchResults(searchResults.filter(f => f.id !== friend.id));
    setAllSuggestions(allSuggestions.filter(f => f.id !== friend.id));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online':
        return 'bg-green-500';
      case 'away':
        return 'bg-yellow-500';
      default:
        return 'bg-slate-500';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'online':
        return 'Online';
      case 'away':
        return 'Ausente';
      default:
        return 'Offline';
    }
  };

  const formatLastSeen = (date: Date | undefined) => {
    if (!date) return 'Nunca';
    const now = new Date();
    const diff = now.getTime() - new Date(date).getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return 'Agora mesmo';
    if (minutes < 60) return `${minutes}m atrás`;
    if (hours < 24) return `${hours}h atrás`;
    if (days < 7) return `${days}d atrás`;
    
    const d = new Date(date);
    return d.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: '2-digit' });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-gradient-to-b from-slate-900 to-slate-950 border border-blue-500/30 rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600/20 to-purple-600/20 border-b border-blue-500/30 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <UserPlus className="text-blue-500" size={24} />
            <h2 className="text-xl font-orbitron font-bold text-white">Adicionar Amigo</h2>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white transition-colors p-1 hover:bg-white/10 rounded"
          >
            <X size={20} />
          </button>
        </div>

        {/* Search Bar */}
        <div className="p-6 border-b border-slate-700/50">
          <div className="relative">
            <Search className="absolute left-3 top-3 text-slate-500" size={18} />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Buscar usuário..."
              className="w-full bg-slate-950 border border-blue-500/20 rounded-lg pl-10 pr-4 py-2 text-white focus:border-blue-500 outline-none transition-colors"
              autoFocus
            />
          </div>
          <p className="text-xs text-slate-500 mt-2">Digite para buscar ou veja as sugestões abaixo</p>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-slate-700/50 px-6">
          <button
            onClick={() => setActiveTab('suggestions')}
            className={`flex-1 py-3 px-4 text-sm font-bold uppercase tracking-widest transition-all ${
              activeTab === 'suggestions'
                ? 'text-blue-400 border-b-2 border-blue-500'
                : 'text-slate-500 hover:text-white'
            }`}
          >
            <Users size={16} className="inline mr-2" />
            Sugestões ({allSuggestions.length})
          </button>
          {searchTerm && (
            <button
              onClick={() => setActiveTab('search')}
              className={`flex-1 py-3 px-4 text-sm font-bold uppercase tracking-widest transition-all ${
                activeTab === 'search'
                  ? 'text-blue-400 border-b-2 border-blue-500'
                  : 'text-slate-500 hover:text-white'
              }`}
            >
              <Search size={16} className="inline mr-2" />
              Resultados ({searchResults.length})
            </button>
          )}
        </div>

        {/* Results */}
        <div className="max-h-96 overflow-y-auto">
          {loading ? (
            <div className="p-6 text-center">
              <Loader className="mx-auto text-blue-500 mb-3 animate-spin" size={32} />
              <p className="text-sm text-slate-400">Carregando usuários...</p>
            </div>
          ) : activeTab === 'suggestions' ? (
            allSuggestions.length === 0 ? (
              <div className="p-6 text-center">
                <AlertCircle className="mx-auto text-slate-500 mb-3" size={32} />
                <p className="text-sm text-slate-400">Todos os players já são seus amigos!</p>
              </div>
            ) : (
              <div className="p-4 space-y-2">
                {allSuggestions.map((user) => (
                  <div
                    key={user.id}
                    className="flex items-center justify-between p-3 bg-slate-800/50 hover:bg-slate-700 rounded-lg border border-slate-700/50 hover:border-blue-500/50 transition-all group"
                  >
                    <div className="flex items-center gap-3 flex-1">
                      <div className="relative">
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-600 to-purple-600 flex items-center justify-center text-xs font-bold text-white">
                          {user.username.charAt(0).toUpperCase()}
                        </div>
                        <div className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-slate-950 ${getStatusColor(user.status)}`} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-bold text-white truncate">{user.username}</p>
                        <p className="text-xs text-slate-500">{getStatusLabel(user.status)}</p>
                      </div>
                    </div>
                    <button
                      onClick={() => handleAddFriend(user)}
                      className="ml-2 p-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-all hover:shadow-lg hover:shadow-blue-500/30"
                    >
                      {addedFriends.includes(user.id) ? (
                        <Check size={18} />
                      ) : (
                        <UserPlus size={18} />
                      )}
                    </button>
                  </div>
                ))}
              </div>
            )
          ) : searchTerm.trim().length < 2 ? (
            <div className="p-6 text-center">
              <AlertCircle className="mx-auto text-slate-500 mb-3" size={32} />
              <p className="text-sm text-slate-400">Digite pelo menos 2 caracteres para buscar</p>
            </div>
          ) : isSearching ? (
            <div className="p-6 text-center">
              <Loader className="mx-auto text-blue-500 mb-3 animate-spin" size={32} />
              <p className="text-sm text-slate-400">Buscando...</p>
            </div>
          ) : searchResults.length === 0 ? (
            <div className="p-6 text-center">
              <AlertCircle className="mx-auto text-slate-500 mb-3" size={32} />
              <p className="text-sm text-slate-400">Nenhum usuário encontrado</p>
            </div>
          ) : (
            <div className="p-4 space-y-2">
              {searchResults.map((user) => (
                <div
                  key={user.id}
                  className="flex items-center justify-between p-3 bg-slate-800/50 hover:bg-slate-700 rounded-lg border border-slate-700/50 hover:border-blue-500/50 transition-all group"
                >
                  <div className="flex items-center gap-3 flex-1">
                    <div className="relative">
                      <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-600 to-purple-600 flex items-center justify-center text-xs font-bold text-white">
                        {user.username.charAt(0).toUpperCase()}
                      </div>
                      <div className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-slate-950 ${getStatusColor(user.status)}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-bold text-white truncate">{user.username}</p>
                      <p className="text-xs text-slate-500">{getStatusLabel(user.status)} • {formatLastSeen(user.lastSeen)}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => handleAddFriend(user)}
                    className="ml-2 p-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-all hover:shadow-lg hover:shadow-blue-500/30"
                  >
                    {addedFriends.includes(user.id) ? (
                      <Check size={18} />
                    ) : (
                      <UserPlus size={18} />
                    )}
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-slate-700/50 px-6 py-4 bg-slate-950/50">
          <button
            onClick={onClose}
            className="w-full px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-lg transition-all uppercase text-xs tracking-widest"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
};

export default AddFriendModal;
