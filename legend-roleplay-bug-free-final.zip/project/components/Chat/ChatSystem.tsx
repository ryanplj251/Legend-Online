
import React, { useState, useEffect, useRef } from 'react';
/* Added MessageSquare to the imports from lucide-react */
import { Send, User, ArrowLeft, Search, MoreVertical, Shield, Trash2, MessageSquare, UserPlus, Clock } from 'lucide-react';
import AddFriendModal from './AddFriendModal';
import MediaUpload from './MediaUpload';
import AudioRecorder from './AudioRecorder';

interface ChatSystemProps {
  user: any;
  onBack: () => void;
}

const ChatSystem: React.FC<ChatSystemProps> = ({ user, onBack }) => {
  const [conversations, setConversations] = useState<any[]>([]);
  const [activeChat, setActiveChat] = useState<string | null>(null);
  const [message, setMessage] = useState('');
  const [chatHistory, setChatHistory] = useState<any[]>([]);
  const [showAddFriend, setShowAddFriend] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    loadConversations();
    const target = localStorage.getItem('legend_active_chat_with');
    if (target) {
      setActiveChat(target);
      localStorage.removeItem('legend_active_chat_with');
    }
  }, []);

  useEffect(() => {
    if (activeChat) {
      loadHistory(activeChat);
      markAsRead(activeChat);
    }
    const interval = setInterval(() => {
      if (activeChat) loadHistory(activeChat);
      loadConversations();
    }, 3000);
    return () => clearInterval(interval);
  }, [activeChat]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [chatHistory]);

  const loadConversations = () => {
    const all = JSON.parse(localStorage.getItem('legend_chats') || '[]');
    const userConvs = new Set<string>();
    all.forEach((m: any) => {
      if (m.from === user.name) userConvs.add(m.to);
      if (m.to === user.name) userConvs.add(m.from);
    });
    setConversations(Array.from(userConvs));
  };

  const loadHistory = (other: string) => {
    const all = JSON.parse(localStorage.getItem('legend_chats') || '[]');
    const filtered = all.filter((m: any) => 
      (m.from === user.name && m.to === other) || 
      (m.from === other && m.to === user.name)
    );
    setChatHistory(filtered);
  };

  const markAsRead = (other: string) => {
    const all = JSON.parse(localStorage.getItem('legend_chats') || '[]');
    const updated = all.map((m: any) => {
      if (m.to === user.name && m.from === other) return { ...m, read: true };
      return m;
    });
    localStorage.setItem('legend_chats', JSON.stringify(updated));
  };

  const sendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim() || !activeChat) return;

    const newMessage = {
      id: Date.now(),
      from: user.name,
      to: activeChat,
      text: message,
      date: new Date().toISOString(),
      read: false
    };

    const all = JSON.parse(localStorage.getItem('legend_chats') || '[]');
    localStorage.setItem('legend_chats', JSON.stringify([...all, newMessage]));
    setMessage('');
    loadHistory(activeChat);
    loadConversations();
  };

  const clearChat = () => {
    if (!activeChat || !window.confirm("Deseja apagar o histórico com este usuário?")) return;
    const all = JSON.parse(localStorage.getItem('legend_chats') || '[]');
    const updated = all.filter((m: any) => 
      !((m.from === user.name && m.to === activeChat) || (m.from === activeChat && m.to === user.name))
    );
    localStorage.setItem('legend_chats', JSON.stringify(updated));
    loadHistory(activeChat);
    loadConversations();
  };

  const handleMediaUpload = (file: File, preview: string) => {
    if (!activeChat) return;
    const newMessage = {
      id: Date.now(),
      from: user.name,
      to: activeChat,
      type: file.type.startsWith('image/') ? 'image' : 'video',
      media: preview,
      fileName: file.name,
      date: new Date().toISOString(),
      read: false
    };
    const all = JSON.parse(localStorage.getItem('legend_chats') || '[]');
    localStorage.setItem('legend_chats', JSON.stringify([...all, newMessage]));
    loadHistory(activeChat);
    loadConversations();
  };

  const handleAudioSend = (audioBlob: Blob, duration: number) => {
    if (!activeChat) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      const audioData = e.target?.result as string;
      const newMessage = {
        id: Date.now(),
        from: user.name,
        to: activeChat,
        type: 'audio',
        audio: audioData,
        duration: duration,
        date: new Date().toISOString(),
        read: false
      };
      const all = JSON.parse(localStorage.getItem('legend_chats') || '[]');
      localStorage.setItem('legend_chats', JSON.stringify([...all, newMessage]));
      loadHistory(activeChat);
      loadConversations();
    };
    reader.readAsDataURL(audioBlob);
  };

  return (
    <div className="pt-24 h-screen bg-slate-950 flex flex-col md:flex-row font-archivo overflow-hidden">
      {/* Contact List */}
      <aside className={`w-full md:w-96 bg-slate-900/50 border-r border-white/5 flex flex-col ${activeChat ? 'hidden md:flex' : 'flex'}`}>
        <div className="p-8 border-b border-white/5">
          <button onClick={onBack} className="flex items-center gap-2 text-slate-500 hover:text-white mb-6 text-xs font-bold uppercase">
            <ArrowLeft size={14} /> Voltar
          </button>
          <div className="flex items-center justify-between gap-4 mb-4">
            <h2 className="text-2xl font-orbitron font-black text-white uppercase italic">Mensagens <span className="text-blue-500">DMs</span></h2>
            <button
              onClick={() => setShowAddFriend(true)}
              className="p-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-all hover:shadow-lg hover:shadow-blue-500/30"
              title="Adicionar Amigo"
            >
              <UserPlus size={20} />
            </button>
          </div>
        </div>
        
        <div className="flex-grow overflow-y-auto p-4 space-y-2">
          {conversations.length > 0 ? (
            conversations.map(conv => (
              <button 
                key={conv}
                onClick={() => setActiveChat(conv)}
                className={`w-full flex items-center gap-4 p-4 rounded-2xl transition-all ${activeChat === conv ? 'bg-blue-600 text-white shadow-lg' : 'hover:bg-white/5 text-slate-300'}`}
              >
                <div className="w-12 h-12 bg-slate-800 rounded-full flex items-center justify-center border-2 border-white/5">
                  <User size={20} />
                </div>
                <div className="text-left overflow-hidden">
                  <p className="font-bold uppercase text-sm truncate">{conv}</p>
                  <p className="text-[10px] opacity-60 uppercase">Clique para conversar</p>
                </div>
              </button>
            ))
          ) : (
            <div className="text-center p-10 text-slate-600 font-bold uppercase text-xs">Nenhuma conversa iniciada.</div>
          )}
        </div>
      </aside>

      {/* Chat Area */}
      <main className={`flex-grow flex flex-col h-full bg-slate-950 ${!activeChat ? 'hidden md:flex items-center justify-center' : 'flex'}`}>
        {activeChat ? (
          <>
            {/* Header */}
            <div className="p-6 bg-slate-900/50 border-b border-white/5 flex justify-between items-center">
              <div className="flex items-center gap-4">
                <button onClick={() => setActiveChat(null)} className="md:hidden text-slate-500 p-2"><ArrowLeft size={20} /></button>
                <div className="relative">
                  <div className="w-10 h-10 bg-blue-600/20 rounded-full flex items-center justify-center text-blue-500"><User size={20} /></div>
                  <div className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-green-500 border-2 border-slate-900" />
                </div>
                <div>
                  <h4 className="font-bold text-white uppercase">{activeChat}</h4>
                  <p className="text-[10px] text-green-500 uppercase font-black flex items-center gap-1"><Clock size={12} /> Online agora</p>
                </div>
              </div>
              <div className="flex gap-2">
                 <button onClick={clearChat} className="p-2 text-slate-600 hover:text-red-500 transition-colors" title="Apagar Histórico"><Trash2 size={18}/></button>
              </div>
            </div>

            {/* Messages */}
            <div className="flex-grow overflow-y-auto p-8 space-y-6">
              {chatHistory.map((msg) => {
                const msgDate = new Date(msg.date);
                const dateStr = msgDate.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: '2-digit' });
                const timeStr = msgDate.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
                
                return (
                  <div key={msg.id} className={`flex ${msg.from === user.name ? 'justify-end' : 'justify-start'} animate-in slide-in-from-bottom-2`}>
                    <div className={`max-w-[70%] p-5 rounded-3xl ${msg.from === user.name ? 'bg-blue-600 text-white rounded-tr-none shadow-lg shadow-blue-600/20' : 'bg-slate-900 text-slate-200 rounded-tl-none border border-white/5'}`}>
                      {msg.type === 'text' && <p className="text-sm font-medium leading-relaxed">{msg.text}</p>}
                      {msg.type === 'image' && msg.media && <img src={msg.media} alt="Imagem" className="max-w-full rounded-lg" />}
                      {msg.type === 'video' && msg.media && <video src={msg.media} controls className="max-w-full rounded-lg" />}
                      {msg.type === 'audio' && (msg.audio || msg.media) && <audio src={msg.audio || msg.media} controls className="w-full" />}
                      <p className="text-[9px] mt-2 opacity-40 text-right">{dateStr} às {timeStr}</p>
                    </div>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <form onSubmit={sendMessage} className="p-8 bg-slate-950 border-t border-white/5">
              <div className="max-w-4xl mx-auto space-y-3">
                <div className="flex items-center gap-2">
                  <MediaUpload onUpload={handleMediaUpload} />
                  <AudioRecorder onSendAudio={handleAudioSend} />
                  <input 
                    type="text" 
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Escreva sua mensagem aqui..."
                    className="flex-1 bg-slate-900 border border-white/10 rounded-2xl py-3 px-4 text-white focus:border-blue-500 outline-none transition-all shadow-2xl"
                  />
                  <button type="submit" className="w-12 h-12 bg-blue-600 hover:bg-blue-500 text-white rounded-xl flex items-center justify-center transition-all">
                    <Send size={20} />
                  </button>
                </div>
              </div>
            </form>
          </>
        ) : (
          <div className="text-center p-20 animate-pulse">
            <MessageSquare size={80} className="mx-auto text-slate-800 mb-6" />
            <h3 className="text-2xl font-orbitron font-black text-slate-700 uppercase italic">Selecione uma conversa para começar</h3>
          </div>
        )}
      </main>
      {showAddFriend && (
        <AddFriendModal
          onClose={() => setShowAddFriend(false)}
          onAddFriend={(friend) => {
            if (!conversations.includes(friend.username)) {
              setConversations([...conversations, friend.username]);
              setActiveChat(friend.username);
              const friends = JSON.parse(localStorage.getItem('legend_friends_' + user.name) || '[]');
              if (!friends.includes(friend.username)) {
                friends.push(friend.username);
                localStorage.setItem('legend_friends_' + user.name, JSON.stringify(friends));
              }
            }
            setShowAddFriend(false);
          }}
          currentFriends={conversations.map(c => ({ id: c, username: c, status: 'online' as const }))}
        />
      )}
    </div>
  );
};

export default ChatSystem;
