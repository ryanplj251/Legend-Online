
import React, { useRef, useState } from 'react';
import { Upload, X, AlertCircle, CheckCircle } from 'lucide-react';

interface MediaUploadProps {
  onUpload: (file: File, preview: string) => void;
  maxSize?: number; // em bytes, padrão 50MB
}

const MediaUpload: React.FC<MediaUploadProps> = ({ onUpload, maxSize = 50 * 1024 * 1024 }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [isUploading, setIsUploading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setError(null);
    setSuccess(false);

    // Validar tamanho
    if (file.size > maxSize) {
      setError(`Arquivo muito grande. Máximo: ${maxSize / 1024 / 1024}MB`);
      return;
    }

    // Validar tipo
    const validTypes = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'video/mp4', 'video/webm', 'audio/mpeg', 'audio/wav'];
    if (!validTypes.includes(file.type)) {
      setError('Tipo de arquivo não suportado');
      return;
    }

    setIsUploading(true);

    // Simular upload com progresso
    const interval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 90) {
          clearInterval(interval);
          return prev;
        }
        return prev + Math.random() * 30;
      });
    }, 200);

    // Criar preview
    const reader = new FileReader();
    reader.onload = (event) => {
      const preview = event.target?.result as string;
      
      clearInterval(interval);
      setUploadProgress(100);
      
      setTimeout(() => {
        onUpload(file, preview);
        setIsUploading(false);
        setUploadProgress(0);
        setSuccess(true);
        if (fileInputRef.current) fileInputRef.current.value = '';
        
        setTimeout(() => setSuccess(false), 2000);
      }, 500);
    };

    reader.readAsDataURL(file);
  };

  return (
    <div className="relative">
      <input
        ref={fileInputRef}
        type="file"
        onChange={handleFileSelect}
        accept="image/*,video/*,audio/*"
        className="hidden"
        disabled={isUploading}
      />

      <button
        onClick={() => fileInputRef.current?.click()}
        disabled={isUploading}
        className="p-2 text-slate-400 hover:text-blue-500 transition-colors disabled:opacity-50"
        title="Upload de mídia"
      >
        <Upload size={20} />
      </button>

      {isUploading && (
        <div className="absolute bottom-12 right-0 bg-slate-900 border border-blue-500/30 rounded-lg p-4 w-48 shadow-lg">
          <p className="text-xs font-bold text-white mb-2">Enviando...</p>
          <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-blue-500 to-purple-500 transition-all"
              style={{ width: `${uploadProgress}%` }}
            />
          </div>
          <p className="text-xs text-slate-400 mt-2">{Math.round(uploadProgress)}%</p>
        </div>
      )}

      {error && (
        <div className="absolute bottom-12 right-0 bg-red-900/20 border border-red-500/50 rounded-lg p-3 w-48 shadow-lg flex items-start gap-2">
          <AlertCircle size={16} className="text-red-500 flex-shrink-0 mt-0.5" />
          <p className="text-xs text-red-400">{error}</p>
        </div>
      )}

      {success && (
        <div className="absolute bottom-12 right-0 bg-green-900/20 border border-green-500/50 rounded-lg p-3 w-48 shadow-lg flex items-start gap-2">
          <CheckCircle size={16} className="text-green-500 flex-shrink-0 mt-0.5" />
          <p className="text-xs text-green-400">Arquivo enviado!</p>
        </div>
      )}
    </div>
  );
};

export default MediaUpload;
