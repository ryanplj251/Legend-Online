import React, { useMemo } from 'react';
import { Trophy, TrendingUp, Medal } from 'lucide-react';

interface Player {
  rank: number;
  name: string;
  level: number;
  money: number;
  playtime: number;
  faction: string;
}

const Ranking: React.FC = () => {
  const mockPlayers: Player[] = useMemo(() => [
    { rank: 1, name: 'Pereira_LGD', level: 150, money: 5000000, playtime: 2500, faction: 'Polícia' },
    { rank: 2, name: 'Ruan_LGD', level: 145, money: 4500000, playtime: 2400, faction: 'Polícia' },
    { rank: 3, name: 'Galo_LGD', level: 140, money: 4000000, playtime: 2300, faction: 'Tráfico' },
    { rank: 4, name: 'p2castro_LGD', level: 135, money: 3500000, playtime: 2200, faction: 'Polícia' },
    { rank: 5, name: 'Player_5', level: 130, money: 3000000, playtime: 2100, faction: 'Independente' },
    { rank: 6, name: 'Player_6', level: 125, money: 2500000, playtime: 2000, faction: 'Tráfico' },
    { rank: 7, name: 'Player_7', level: 120, money: 2000000, playtime: 1900, faction: 'Polícia' },
    { rank: 8, name: 'Player_8', level: 115, money: 1500000, playtime: 1800, faction: 'Independente' },
    { rank: 9, name: 'Player_9', level: 110, money: 1000000, playtime: 1700, faction: 'Tráfico' },
    { rank: 10, name: 'Player_10', level: 105, money: 500000, playtime: 1600, faction: 'Polícia' },
  ], []);

  const getMedalColor = (rank: number) => {
    switch(rank) {
      case 1: return 'text-yellow-400';
      case 2: return 'text-gray-300';
      case 3: return 'text-orange-400';
      default: return 'text-slate-500';
    }
  };

  const getFactionColor = (faction: string) => {
    switch(faction) {
      case 'Polícia': return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
      case 'Tráfico': return 'bg-red-500/20 text-red-400 border-red-500/30';
      default: return 'bg-slate-500/20 text-slate-400 border-slate-500/30';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950 pt-20 pb-20">
      <div className="max-w-6xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Trophy className="text-yellow-400" size={40} />
            <h1 className="text-5xl font-orbitron font-black text-white uppercase tracking-tighter">
              Top <span className="text-yellow-400">Jogadores</span>
            </h1>
            <Trophy className="text-yellow-400" size={40} />
          </div>
          <p className="text-slate-400 text-sm uppercase tracking-widest">Ranking Global - Legend Roleplay</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-12">
          <div className="bg-gradient-to-br from-blue-600/20 to-blue-900/20 border border-blue-500/30 rounded-2xl p-6">
            <div className="flex items-center gap-3 mb-2">
              <TrendingUp className="text-blue-400" size={24} />
              <span className="text-slate-400 text-xs uppercase font-bold">Jogadores Ativos</span>
            </div>
            <p className="text-3xl font-black text-blue-400">1,247</p>
          </div>
          <div className="bg-gradient-to-br from-green-600/20 to-green-900/20 border border-green-500/30 rounded-2xl p-6">
            <div className="flex items-center gap-3 mb-2">
              <Medal className="text-green-400" size={24} />
              <span className="text-slate-400 text-xs uppercase font-bold">Tempo Médio</span>
            </div>
            <p className="text-3xl font-black text-green-400">2.1h/dia</p>
          </div>
          <div className="bg-gradient-to-br from-purple-600/20 to-purple-900/20 border border-purple-500/30 rounded-2xl p-6">
            <div className="flex items-center gap-3 mb-2">
              <Trophy className="text-purple-400" size={24} />
              <span className="text-slate-400 text-xs uppercase font-bold">Servidor</span>
            </div>
            <p className="text-3xl font-black text-purple-400">Online</p>
          </div>
        </div>

        {/* Ranking Table */}
        <div className="bg-slate-900/50 border border-blue-500/20 rounded-2xl overflow-hidden backdrop-blur-sm">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-gradient-to-r from-blue-600/20 to-indigo-600/20 border-b border-blue-500/20">
                  <th className="px-6 py-4 text-left text-xs font-black text-slate-400 uppercase tracking-widest">Rank</th>
                  <th className="px-6 py-4 text-left text-xs font-black text-slate-400 uppercase tracking-widest">Jogador</th>
                  <th className="px-6 py-4 text-center text-xs font-black text-slate-400 uppercase tracking-widest">Level</th>
                  <th className="px-6 py-4 text-center text-xs font-black text-slate-400 uppercase tracking-widest">Dinheiro</th>
                  <th className="px-6 py-4 text-center text-xs font-black text-slate-400 uppercase tracking-widest">Playtime</th>
                  <th className="px-6 py-4 text-center text-xs font-black text-slate-400 uppercase tracking-widest">Facção</th>
                </tr>
              </thead>
              <tbody>
                {mockPlayers.map((player, idx) => (
                  <tr 
                    key={idx}
                    className="border-b border-slate-800/50 hover:bg-blue-500/5 transition-colors"
                  >
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2">
                        <Medal className={`${getMedalColor(player.rank)}`} size={20} />
                        <span className="font-black text-white text-lg">{player.rank}</span>
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className="font-bold text-blue-400">{player.name}</span>
                    </td>
                    <td className="px-6 py-4 text-center">
                      <span className="font-bold text-yellow-400">{player.level}</span>
                    </td>
                    <td className="px-6 py-4 text-center">
                      <span className="font-bold text-green-400">${(player.money / 1000000).toFixed(1)}M</span>
                    </td>
                    <td className="px-6 py-4 text-center">
                      <span className="font-bold text-slate-300">{player.playtime}h</span>
                    </td>
                    <td className="px-6 py-4 text-center">
                      <span className={`px-3 py-1 rounded-full text-xs font-black border ${getFactionColor(player.faction)}`}>
                        {player.faction}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Footer Info */}
        <div className="mt-8 text-center text-slate-500 text-xs uppercase font-bold tracking-widest">
          <p>Ranking atualizado em tempo real • Dados sincronizados a cada 5 minutos</p>
        </div>
      </div>
    </div>
  );
};

export default Ranking;
