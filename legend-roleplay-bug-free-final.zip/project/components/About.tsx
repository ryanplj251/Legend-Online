
import React from 'react';
import { SERVER_INFO } from '../constants';
import { ShieldCheck, Cpu, Star, Zap } from 'lucide-react';

const About: React.FC = () => {
  const features = [
    {
      icon: <ShieldCheck className="w-8 h-8 text-blue-500" />,
      title: "Roleplay Sério",
      text: "Ambiente controlado e focado na interpretação de qualidade, com staff ativa."
    },
    {
      icon: <Cpu className="w-8 h-8 text-blue-500" />,
      title: "Sistemas Otimizados",
      text: "Scripts leves que garantem fluidez e evitam crashes desnecessários."
    },
    {
      icon: <Zap className="w-8 h-8 text-blue-500" />,
      title: "Alto Desempenho",
      text: "Hospedagem de ponta com baixa latência para uma jogabilidade sem lag."
    },
    {
      icon: <Star className="w-8 h-8 text-blue-500" />,
      title: "Experiência Diferenciada",
      text: "Mecânicas de jogo pensadas para recompensar o esforço do jogador."
    }
  ];

  return (
    <div className="container mx-auto px-4">
      <div className="flex flex-col lg:flex-row items-center gap-16">
        <div className="lg:w-1/2">
          <div className="relative group">
            <div className="absolute -inset-1 bg-gradient-to-r from-blue-600 to-indigo-600 rounded-2xl blur opacity-25 group-hover:opacity-50 transition duration-1000"></div>
            <img 
              src="https://picsum.photos/seed/gtasa/1200/800" 
              alt="GTA SA Scene" 
              className="relative rounded-2xl shadow-2xl w-full border border-white/10"
            />
          </div>
        </div>
        <div className="lg:w-1/2 space-y-8">
          <div>
            <span className="text-blue-500 font-bold tracking-widest uppercase text-sm">Bem-vindo ao Legend</span>
            <h2 className="text-4xl md:text-5xl font-orbitron font-black text-white mt-2 mb-6">SOBRE O NOSSO <br/> <span className="text-blue-500">UNIVERSO</span></h2>
            <p className="text-slate-400 text-lg leading-relaxed">
              O <span className="text-white font-bold">LEGEND ROLEPLAY</span> não é apenas mais um servidor de SA-MP. É o resultado de anos de paixão pelo Roleplay, construído sobre uma base sólida de otimização e inovação. 
              Nosso objetivo é proporcionar um palco onde sua história pode ser escrita sem limitações técnicas ou toxicidade.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {features.map((f, i) => (
              <div key={`feature-${f.title}-${i}`} className="flex gap-4">
                <div className="flex-shrink-0">{f.icon}</div>
                <div>
                  <h4 className="font-orbitron text-white font-bold text-lg mb-1">{f.title}</h4>
                  <p className="text-slate-400 text-sm">{f.text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default About;
