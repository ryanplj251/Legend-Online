
import React from 'react';
import { SYSTEMS } from '../constants';

const Systems: React.FC = () => {
  return (
    <div className="container mx-auto px-4">
      <div className="text-center mb-16">
        <h2 className="text-4xl md:text-5xl font-orbitron font-black text-white mb-4">SISTEMAS DO <span className="text-blue-500">SERVIDOR</span></h2>
        <p className="text-slate-400 max-w-2xl mx-auto">Conheça o que torna o LEGEND RP o lugar ideal para o seu próximo personagem.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {SYSTEMS.map((system, index) => (
          <div 
            key={`system-${system.title}-${index}`} 
            className="group relative overflow-hidden rounded-2xl bg-slate-900 border border-white/5 hover:border-blue-500/50 transition-all duration-500 hover:-translate-y-2"
          >
            <div className="h-64 overflow-hidden">
              <img 
                src={system.img} 
                alt={system.title} 
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110 opacity-60"
              />
            </div>
            <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent p-8 flex flex-col justify-end">
              <h3 className="font-orbitron text-2xl font-bold text-white mb-2 group-hover:text-blue-500 transition-colors">
                {system.title}
              </h3>
              <p className="text-slate-300 text-sm leading-relaxed opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                {system.description}
              </p>
            </div>
            <div className="absolute top-4 right-4 bg-blue-600/20 backdrop-blur-md px-3 py-1 rounded-full border border-blue-500/30 text-[10px] text-blue-400 font-bold tracking-widest uppercase">
              Otimizado
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Systems;
