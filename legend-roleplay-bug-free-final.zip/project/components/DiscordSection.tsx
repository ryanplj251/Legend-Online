
import React from 'react';
import { SERVER_INFO } from '../constants';
import { MessageSquare, Users, Sparkles } from 'lucide-react';

const DiscordSection: React.FC = () => {
  return (
    <div className="container mx-auto px-4">
      <div className="bg-gradient-to-br from-blue-700 to-indigo-900 rounded-[2.5rem] p-12 md:p-20 relative overflow-hidden shadow-2xl">
        {/* Decorative Circles */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-white/5 rounded-full -mr-48 -mt-48 blur-3xl"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-black/10 rounded-full -ml-32 -mb-32 blur-2xl"></div>

        <div className="relative z-10 flex flex-col items-center text-center">
          <div className="w-24 h-24 bg-white/10 backdrop-blur-lg rounded-3xl flex items-center justify-center mb-8 shadow-xl animate-bounce">
            <MessageSquare className="w-12 h-12 text-white fill-current" />
          </div>
          
          <h2 className="text-4xl md:text-6xl font-orbitron font-black text-white mb-6 uppercase">
            FAÇA PARTE DA <span className="text-blue-300">COMUNIDADE</span>
          </h2>
          
          <p className="text-blue-100 text-lg md:text-xl max-w-2xl mb-12 font-medium">
            Fique por dentro das atualizações, participe de sorteios e interaja com centenas de outros jogadores no nosso canal oficial.
          </p>

          <div className="flex flex-wrap justify-center gap-12 mb-12">
            <div className="flex flex-col items-center">
              <span className="text-3xl font-black text-white font-orbitron">1000+</span>
              <span className="text-blue-200 uppercase text-xs tracking-widest font-bold">Membros</span>
            </div>
            <div className="flex flex-col items-center">
              <span className="text-3xl font-black text-white font-orbitron">24/7</span>
              <span className="text-blue-200 uppercase text-xs tracking-widest font-bold">Ativo</span>
            </div>
            <div className="flex flex-col items-center">
              <span className="text-3xl font-black text-white font-orbitron"><Sparkles className="w-6 h-6 inline mr-2"/>STAFF</span>
              <span className="text-blue-200 uppercase text-xs tracking-widest font-bold">Suporte</span>
            </div>
          </div>

          <a 
            href={SERVER_INFO.discordUrl} 
            target="_blank" 
            rel="noopener noreferrer"
            className="group px-12 py-5 bg-white text-blue-700 font-black rounded-2xl flex items-center gap-4 hover:bg-slate-100 transition-all text-xl shadow-2xl hover:scale-105 active:scale-95"
          >
            <Users className="w-6 h-6" />
            ENTRAR NO DISCORD
          </a>
        </div>
      </div>
    </div>
  );
};

export default DiscordSection;
