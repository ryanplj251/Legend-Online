
import React, { useState } from 'react';
import { Download, Terminal, Plus, Play, Copy, Check } from 'lucide-react';
import { SERVER_INFO } from '../constants';

const HowToPlay: React.FC = () => {
  const [copied, setCopied] = useState(false);

  const copyIp = () => {
    navigator.clipboard.writeText(SERVER_INFO.ip);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const steps = [
    {
      icon: <Download className="w-8 h-8" />,
      title: "Baixar GTA SA",
      desc: "Tenha o GTA San Andreas limpo instalado em seu computador."
    },
    {
      icon: <Terminal className="w-8 h-8" />,
      title: "Instalar SA-MP",
      desc: "Baixe e instale o cliente SA-MP 0.3.7 na pasta do seu jogo."
    },
    {
      icon: <Plus className="w-8 h-8" />,
      title: "Adicionar IP",
      desc: `Adicione o IP do Legend RP nos seus favoritos.`
    },
    {
      icon: <Play className="w-8 h-8" />,
      title: "Entrar e Jogar",
      desc: "Crie seu nome RP (Nome_Sobrenome) e comece sua jornada!"
    }
  ];

  return (
    <div className="container mx-auto px-4">
      <div className="flex flex-col items-center mb-16">
        <h2 className="text-4xl md:text-5xl font-orbitron font-black text-white mb-4 uppercase">COMO <span className="text-blue-500">COMEÇAR</span></h2>
        <div className="h-1 w-20 bg-blue-600 rounded-full"></div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 relative">
        <div className="hidden lg:block absolute top-10 left-0 w-full h-0.5 bg-blue-900/30 -z-10"></div>
        
        {steps.map((step, i) => (
          <div key={`step-${step.title}-${i}`} className="flex flex-col items-center text-center group">
            <div className="w-20 h-20 bg-slate-950 border-2 border-slate-800 rounded-2xl flex items-center justify-center text-blue-500 mb-6 group-hover:border-blue-500 group-hover:shadow-[0_0_15px_rgba(59,130,246,0.3)] transition-all duration-300">
              {step.icon}
            </div>
            <div className="bg-slate-900/80 backdrop-blur-sm p-6 rounded-xl border border-white/5 w-full hover:bg-slate-800 transition-colors">
              <span className="block text-blue-600 font-black text-4xl mb-2 opacity-20">0{i+1}</span>
              <h4 className="font-orbitron font-bold text-white text-lg mb-2">{step.title}</h4>
              <p className="text-slate-400 text-sm leading-relaxed">{step.desc}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-16 bg-blue-600 p-8 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-8 shadow-2xl relative overflow-hidden group">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-700 to-indigo-800 opacity-50"></div>
        <div className="relative z-10 text-white">
          <h3 className="text-2xl font-bold mb-2">Já tem tudo pronto?</h3>
          <p className="text-blue-100">Copie o IP e venha criar sua história agora mesmo!</p>
        </div>
        <button 
          onClick={copyIp}
          className="relative z-10 flex items-center gap-4 bg-slate-950/40 hover:bg-slate-950/60 p-5 rounded-xl border border-white/20 transition-all cursor-pointer group/ip w-full md:w-auto justify-between"
        >
          <code className="text-xl font-mono font-bold text-white tracking-wider">{SERVER_INFO.ip}</code>
          <div className="flex items-center gap-2 bg-blue-500 px-3 py-1 rounded-lg text-xs font-bold uppercase tracking-widest text-white group-hover/ip:bg-blue-400 transition-colors">
            {copied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            {copied ? 'Copiado' : 'Copiar'}
          </div>
        </button>
      </div>
    </div>
  );
};

export default HowToPlay;
