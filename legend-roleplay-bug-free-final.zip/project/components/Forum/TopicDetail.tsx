
import React, { useState } from 'react';
import { FORUM_CATEGORIES, TOPIC_STATUS } from '../../constants';
import { ArrowLeft, User, Calendar, ShieldCheck, FileText, ExternalLink, Download, Trash2, Edit3, Save } from 'lucide-react';

interface TopicDetailProps {
  topic: any;
  user: any;
  onBack: () => void;
  onProfileClick: (username: string) => void;
}

const TopicDetail: React.FC<TopicDetailProps> = ({ topic, user, onBack, onProfileClick }) => {
  const [currentTopic, setCurrentTopic] = useState(topic);
  const [isEditing, setIsEditing] = useState(false);
  const [editDesc, setEditDesc] = useState(topic.description);
  
  const isStaff = user?.role === 'admin' || user?.role === 'staff';
  const cat = FORUM_CATEGORIES.find(c => c.id === currentTopic.category);
  const status = TOPIC_STATUS[currentTopic.status as keyof typeof TOPIC_STATUS] || TOPIC_STATUS.PENDING;

  const deleteThis = () => {
    if (!window.confirm("Deseja apagar este tópico permanentemente?")) return;
    const all = JSON.parse(localStorage.getItem('legend_topics') || '[]');
    localStorage.setItem('legend_topics', JSON.stringify(all.filter((t: any) => t.id !== topic.id)));
    onBack();
  };

  const saveEdit = () => {
    const all = JSON.parse(localStorage.getItem('legend_topics') || '[]');
    const updated = all.map((t: any) => {
      if (t.id === topic.id) return { ...t, description: editDesc };
      return t;
    });
    localStorage.setItem('legend_topics', JSON.stringify(updated));
    setCurrentTopic({ ...currentTopic, description: editDesc });
    setIsEditing(false);
  };

  return (
    <div className="bg-slate-900 border border-white/5 rounded-3xl overflow-hidden shadow-2xl animate-in fade-in duration-500 font-archivo">
      {/* Header Info */}
      <div className="p-8 md:p-12 border-b border-white/5 bg-slate-950/50">
        <div className="flex justify-between items-start mb-8">
          <button onClick={onBack} className="flex items-center gap-2 text-blue-500 font-bold hover:translate-x-[-4px] transition-transform text-xs uppercase tracking-widest">
            <ArrowLeft size={16} /> Voltar
          </button>
          
          {isStaff && (
            <div className="flex gap-2">
              <button onClick={deleteThis} className="p-3 bg-red-600/10 text-red-500 rounded-xl hover:bg-red-600 hover:text-white transition-all"><Trash2 size={16}/></button>
              {!isEditing ? (
                <button onClick={() => setIsEditing(true)} className="p-3 bg-blue-600/10 text-blue-500 rounded-xl hover:bg-blue-600 hover:text-white transition-all"><Edit3 size={16}/></button>
              ) : (
                <button onClick={saveEdit} className="p-3 bg-green-600 text-white rounded-xl"><Save size={16}/></button>
              )}
            </div>
          )}
        </div>
        
        <div>
          <div className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase border mb-4 inline-block ${status.color}`}>
            {status.label}
          </div>
          <h1 className="text-3xl md:text-5xl font-orbitron font-black text-white uppercase tracking-tighter mb-4">{currentTopic.title}</h1>
          <div className="flex flex-wrap gap-6">
            <button 
              onClick={() => onProfileClick(currentTopic.author)}
              className="flex items-center gap-2 text-slate-500 text-xs font-bold uppercase tracking-widest hover:text-blue-500 transition-colors"
            >
              <User size={14} className="text-blue-500" /> Autor: <span className="text-white border-b border-blue-500/30">{currentTopic.author}</span>
            </button>
            <div className="flex items-center gap-2 text-slate-500 text-xs font-bold uppercase tracking-widest">
              <Calendar size={14} className="text-blue-500" /> Enviado: <span className="text-white">{new Date(currentTopic.createdAt).toLocaleString()}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="p-8 md:p-12 grid grid-cols-1 lg:grid-cols-3 gap-12">
        <div className="lg:col-span-2 space-y-12">
          <section>
            <h4 className="flex items-center gap-3 font-bold text-white uppercase tracking-widest mb-6 border-b border-white/5 pb-4 text-sm">
              <FileText size={18} className="text-blue-500" /> Descrição do Tópico
            </h4>
            {isEditing ? (
              <textarea 
                className="w-full bg-slate-950 border border-blue-500/30 rounded-2xl p-6 text-slate-200 h-64 outline-none"
                value={editDesc}
                onChange={(e) => setEditDesc(e.target.value)}
              />
            ) : (
              <div className="bg-slate-950/50 p-8 rounded-2xl text-slate-300 leading-relaxed whitespace-pre-wrap font-medium border border-white/5">
                {currentTopic.description}
              </div>
            )}
          </section>

          {currentTopic.staffResponse && (
            <section className="animate-in slide-in-from-top-4">
              <h4 className="flex items-center gap-3 font-bold text-amber-500 uppercase tracking-widest mb-6 border-b border-amber-500/20 pb-4 text-sm">
                <ShieldCheck size={18} /> Resposta Oficial STAFF
              </h4>
              <div className="bg-amber-500/5 border border-amber-500/20 p-8 rounded-2xl text-slate-200 leading-relaxed italic relative">
                {currentTopic.staffResponse}
              </div>
            </section>
          )}
        </div>

        <div className="space-y-8">
          <section className="bg-slate-950/50 p-6 rounded-2xl border border-white/5">
             <h4 className="font-bold text-white uppercase tracking-widest text-[10px] mb-6 border-l-2 border-blue-600 pl-4">Anexos Disponíveis</h4>
             <div className="space-y-4">
               {currentTopic.attachments?.length > 0 ? (
                 currentTopic.attachments.map((file: string, i: number) => (
                    <div key={i} className="flex items-center justify-between bg-slate-800 p-4 rounded-xl border border-white/5 text-xs text-slate-400 font-bold uppercase truncate">
                      {file} <Download size={14}/>
                    </div>
                 ))
               ) : (
                 <p className="text-slate-600 text-[10px] uppercase font-bold italic">Sem anexos.</p>
               )}
             </div>
          </section>
        </div>
      </div>
    </div>
  );
};

export default TopicDetail;
