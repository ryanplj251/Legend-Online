
import React, { useState, useRef } from 'react';
import { FORUM_CATEGORIES } from '../../constants';
import { Upload, X, AlertTriangle, Paperclip, CheckCircle2, Loader2 } from 'lucide-react';

interface TopicFormProps {
  category: string;
  user: any;
  onCancel: () => void;
  onSuccess: () => void;
}

const TopicForm: React.FC<TopicFormProps> = ({ category, user, onCancel, onSuccess }) => {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [files, setFiles] = useState<File[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const catInfo = FORUM_CATEGORIES.find(c => c.id === category);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files);
      const oversized = newFiles.some(f => (f as File).size > 30 * 1024 * 1024);
      
      if (oversized) {
        setError("Um ou mais arquivos excedem o limite de 30MB.");
        return;
      }
      
      setFiles(prev => [...prev, ...newFiles]);
      setError(null);
    }
  };

  const removeFile = (index: number) => {
    setFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // Simulação de delay de rede
    setTimeout(() => {
      const topicData = {
        id: Date.now().toString(),
        title,
        description,
        category,
        author: user.name,
        status: 'pending',
        createdAt: new Date().toISOString(),
        staffResponse: '',
        attachments: files.map(f => f.name), // Simulação apenas guardando nomes
        history: [{ action: 'Tópico Criado', by: user.name, date: new Date().toISOString() }]
      };

      const existing = JSON.parse(localStorage.getItem('legend_topics') || '[]');
      localStorage.setItem('legend_topics', JSON.stringify([topicData, ...existing]));
      
      setIsSubmitting(false);
      onSuccess();
    }, 1500);
  };

  return (
    <div className="bg-slate-900 border border-blue-500/30 rounded-3xl p-8 mb-16 shadow-2xl animate-in fade-in slide-in-from-bottom-4">
      <div className="flex items-center gap-4 mb-8">
        <div className="p-3 bg-blue-600/10 rounded-xl text-blue-500">
          <Paperclip size={24} />
        </div>
        <div>
          <h2 className="text-2xl font-orbitron font-bold text-white uppercase tracking-tighter">
            Novo Tópico: <span className="text-blue-500">{catInfo?.name}</span>
          </h2>
          <p className="text-slate-500 text-sm">Preencha todos os campos com precisão para agilizar o suporte.</p>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-6">
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-3">Título do Assunto</label>
              <input 
                type="text" 
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Ex: Denúncia por DM indevido - Jogador ID 42"
                className="w-full bg-slate-950 border border-white/10 rounded-xl p-4 text-white focus:border-blue-500 outline-none"
                required
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-3">Descrição Detalhada</label>
              <textarea 
                rows={10}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Descreva exatamente o que aconteceu, com nomes, IDs e horários..."
                className="w-full bg-slate-950 border border-white/10 rounded-xl p-4 text-white focus:border-blue-500 outline-none resize-none"
                required
              />
            </div>
          </div>

          <div className="space-y-6">
            <div>
              <label className="block text-xs font-bold text-slate-500 uppercase tracking-widest mb-3">Anexar Provas (Máx 30MB por arquivo)</label>
              <div 
                onClick={() => fileInputRef.current?.click()}
                className="w-full h-64 border-2 border-dashed border-white/10 rounded-2xl flex flex-col items-center justify-center cursor-pointer hover:border-blue-500/50 hover:bg-blue-600/5 transition-all group"
              >
                <Upload className="text-slate-600 mb-4 group-hover:text-blue-500 group-hover:scale-110 transition-all" size={32} />
                <p className="text-slate-500 font-bold uppercase text-xs tracking-widest">Clique para selecionar arquivos</p>
                <p className="text-slate-600 text-[10px] mt-1">Imagens, Logs ou Vídeos Curtos</p>
                <input 
                  type="file" 
                  ref={fileInputRef} 
                  onChange={handleFileChange} 
                  className="hidden" 
                  multiple 
                />
              </div>

              {files.length > 0 && (
                <div className="mt-4 grid grid-cols-1 gap-2 max-h-48 overflow-y-auto pr-2">
                  {files.map((file, idx) => (
                    <div key={idx} className="flex items-center justify-between bg-slate-950 p-3 rounded-lg border border-white/5">
                      <div className="flex items-center gap-2 overflow-hidden">
                        <Paperclip size={14} className="text-blue-500 flex-shrink-0" />
                        <span className="text-xs text-slate-400 truncate">{file.name}</span>
                        <span className="text-[10px] text-slate-600">({(file.size / (1024 * 1024)).toFixed(2)} MB)</span>
                      </div>
                      <button type="button" onClick={() => removeFile(idx)} className="text-red-500 p-1 hover:bg-red-500/10 rounded">
                        <X size={14} />
                      </button>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>

        {error && (
          <div className="bg-red-500/10 border border-red-500/30 p-4 rounded-xl flex items-start gap-3 text-red-500 text-sm">
            <AlertTriangle size={18} className="flex-shrink-0 mt-0.5" />
            <p>{error}</p>
          </div>
        )}

        <div className="flex flex-col md:flex-row gap-4 pt-4">
          <button 
            type="submit" 
            disabled={isSubmitting}
            className="flex-grow bg-blue-600 hover:bg-blue-500 disabled:bg-slate-700 text-white font-black py-5 rounded-xl flex items-center justify-center gap-3 transition-all uppercase text-lg shadow-lg shadow-blue-600/20 active:scale-95"
          >
            {isSubmitting ? (
              <Loader2 className="animate-spin" />
            ) : (
              <CheckCircle2 size={24} />
            )}
            {isSubmitting ? 'Enviando...' : 'Confirmar Envio'}
          </button>
          <button 
            type="button" 
            onClick={onCancel}
            className="px-10 py-5 bg-slate-800 hover:bg-slate-700 text-white font-bold rounded-xl transition-all uppercase active:scale-95"
          >
            Cancelar
          </button>
        </div>
      </form>
    </div>
  );
};

export default TopicForm;
