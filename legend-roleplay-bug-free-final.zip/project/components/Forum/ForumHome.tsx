
import React, { useState, useEffect } from 'react';
import { FORUM_CATEGORIES, TOPIC_STATUS } from '../../constants';
import * as Icons from 'lucide-react';
import TopicForm from './TopicForm';
import TopicDetail from './TopicDetail';

interface ForumHomeProps {
  user: any;
  onProfileClick: (username: string) => void;
}

const ForumHome: React.FC<ForumHomeProps> = ({ user, onProfileClick }) => {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [isCreatingTopic, setIsCreatingTopic] = useState(false);
  const [userTopics, setUserTopics] = useState<any[]>([]);
  const [viewingTopic, setViewingTopic] = useState<any | null>(null);

  useEffect(() => {
    loadUserTopics();
  }, [user]);

  const loadUserTopics = () => {
    const allTopics = JSON.parse(localStorage.getItem('legend_topics') || '[]');
    const userOnly = allTopics.filter((t: any) => t.author === user.name);
    setUserTopics(userOnly);
  };

  const handleTopicCreated = () => {
    setIsCreatingTopic(false);
    loadUserTopics();
  };

  return (
    <div className="pt-32 pb-20 container mx-auto px-4 font-archivo">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-12">
        <div>
          <h1 className="text-4xl md:text-5xl font-orbitron font-black text-white uppercase italic">Central do <span className="text-blue-500">Fórum</span></h1>
          <p className="text-slate-400 font-medium">Crie denúncias e solicitações de suporte oficiais.</p>
        </div>
        <div className="flex gap-4">
           {(viewingTopic || selectedCategory || isCreatingTopic) && (
             <button 
                onClick={() => { setViewingTopic(null); setSelectedCategory(null); setIsCreatingTopic(false); }}
                className="bg-slate-800 px-6 py-3 rounded-xl font-bold hover:bg-slate-700 transition-all text-sm uppercase"
             >
               Voltar ao Início
             </button>
           )}
        </div>
      </div>

      {!selectedCategory && !viewingTopic && !isCreatingTopic && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {FORUM_CATEGORIES.map((cat) => {
            const Icon = (Icons as any)[cat.icon];
            return (
              <button 
                key={cat.id}
                onClick={() => { setSelectedCategory(cat.id); setIsCreatingTopic(true); }}
                className="group p-8 bg-slate-900 border border-white/5 rounded-3xl hover:border-blue-500/50 hover:bg-blue-600/5 transition-all text-left"
              >
                <div className={`w-16 h-16 rounded-2xl bg-slate-950 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform ${cat.color}`}>
                  <Icon size={32} />
                </div>
                <h3 className="text-2xl font-bold text-white mb-2 uppercase tracking-tighter">{cat.name}</h3>
                <p className="text-slate-400 text-sm mb-6">Inicie um novo tópico oficial nesta categoria.</p>
                <div className="flex items-center gap-2 text-blue-500 font-bold uppercase text-xs tracking-widest">
                  Criar Agora <Icons.ChevronRight size={14} />
                </div>
              </button>
            );
          })}
        </div>
      )}

      {isCreatingTopic && selectedCategory && (
        <TopicForm 
          category={selectedCategory} 
          user={user} 
          onCancel={() => { setIsCreatingTopic(false); setSelectedCategory(null); }} 
          onSuccess={handleTopicCreated}
        />
      )}

      {viewingTopic && (
        <TopicDetail 
          topic={viewingTopic} 
          user={user}
          onBack={() => { setViewingTopic(null); loadUserTopics(); }} 
          onProfileClick={onProfileClick}
        />
      )}

      {!isCreatingTopic && !viewingTopic && (
        <div className="bg-slate-900 rounded-3xl border border-white/5 overflow-hidden shadow-2xl">
          <div className="p-6 border-b border-white/5 flex justify-between items-center bg-slate-950/50">
            <h4 className="font-bold text-white uppercase tracking-widest text-sm flex items-center gap-2">
              <Icons.List size={16} className="text-blue-500" /> Seus Tópicos Recentes
            </h4>
          </div>
          
          <div className="overflow-x-auto">
            {userTopics.length > 0 ? (
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-slate-950/30 text-xs font-bold text-slate-500 uppercase tracking-widest border-b border-white/5">
                    <th className="px-6 py-4">Status</th>
                    <th className="px-6 py-4">Título</th>
                    <th className="px-6 py-4">Categoria</th>
                    <th className="px-6 py-4 text-right">Ação</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {userTopics.map((topic) => (
                    <tr key={topic.id} className="hover:bg-white/5 transition-colors group">
                      <td className="px-6 py-4">
                        <span className={`px-3 py-1 rounded-full text-[10px] font-bold uppercase border ${TOPIC_STATUS[topic.status as keyof typeof TOPIC_STATUS]?.color || TOPIC_STATUS.PENDING.color}`}>
                          {TOPIC_STATUS[topic.status as keyof typeof TOPIC_STATUS]?.label}
                        </span>
                      </td>
                      <td className="px-6 py-4 font-bold text-white uppercase text-sm truncate max-w-[200px]">{topic.title}</td>
                      <td className="px-6 py-4 text-xs font-medium text-slate-400 capitalize">
                        {FORUM_CATEGORIES.find(c => c.id === topic.category)?.name}
                      </td>
                      <td className="px-6 py-4 text-right">
                        <button onClick={() => setViewingTopic(topic)} className="bg-blue-600/10 text-blue-500 hover:bg-blue-600 hover:text-white px-4 py-2 rounded-lg text-xs font-bold transition-all uppercase">
                          Ver Detalhes
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            ) : (
              <div className="p-20 text-center text-slate-500 uppercase font-bold text-xs tracking-widest">Ainda não há nada por aqui.</div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default ForumHome;
