
import React from 'react';
import { RULES } from '../constants';
import * as Icons from 'lucide-react';

const Rules: React.FC = () => {
  return (
    <div className="container mx-auto px-4">
      <div className="text-center mb-16">
         <h2 className="text-4xl md:text-5xl font-orbitron font-black text-white mb-4 uppercase">Regras de <span className="text-blue-500">Roleplay</span></h2>
         <p className="text-slate-400">Diretrizes básicas para manter a harmonia e a qualidade do nosso servidor.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {RULES.map((rule, idx) => {
          const IconComponent = (Icons as any)[rule.icon] || Icons.HelpCircle;
          return (
            <div 
              key={`rule-${rule.title}-${idx}`} 
              className="group bg-slate-900 border border-white/5 p-8 rounded-2xl hover:bg-blue-600/5 hover:border-blue-500/40 transition-all duration-300 flex flex-col h-full"
            >
              <div className="w-12 h-12 bg-blue-600/10 rounded-lg flex items-center justify-center text-blue-500 mb-6 group-hover:scale-110 transition-transform">
                <IconComponent className="w-6 h-6" />
              </div>
              <h4 className="font-orbitron font-bold text-white text-xl mb-4 uppercase tracking-tighter group-hover:text-blue-500 transition-colors">
                {rule.title}
              </h4>
              <p className="text-slate-400 text-sm leading-relaxed flex-grow">
                {rule.description}
              </p>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default Rules;
