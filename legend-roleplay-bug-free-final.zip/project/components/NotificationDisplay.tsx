import React, { useState, useEffect } from 'react';
import { X, ChevronLeft, ChevronRight } from 'lucide-react';

interface Notification {
  id: string;
  title: string;
  description: string;
  image?: string;
  video?: string;
  createdBy: string;
  createdAt: Date;
  type: 'image' | 'video' | 'text';
}

const NotificationDisplay: React.FC = () => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    loadNotifications();
    const interval = setInterval(loadNotifications, 5000);
    return () => clearInterval(interval);
  }, []);

  const loadNotifications = () => {
    const stored = localStorage.getItem('legend_notifications');
    if (stored) {
      const parsed = JSON.parse(stored);
      setNotifications(parsed);
    }
  };

  if (notifications.length === 0) return null;

  const current = notifications[currentIndex];

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % notifications.length);
  };

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + notifications.length) % notifications.length);
  };

  return (
    <>
      {/* Botão Flutuante */}
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-8 right-8 z-40 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white p-4 rounded-full shadow-lg hover:shadow-xl transition-all animate-pulse"
        title="Ver notificações"
      >
        <div className="relative">
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
          </svg>
          {notifications.length > 0 && (
            <span className="absolute top-0 right-0 bg-red-500 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center">
              {notifications.length}
            </span>
          )}
        </div>
      </button>

      {/* Modal de Notificações */}
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-gradient-to-b from-slate-900 to-slate-950 border border-blue-500/30 rounded-2xl max-w-2xl w-full shadow-2xl overflow-hidden">
            {/* Header */}
            <div className="bg-gradient-to-r from-blue-600 to-indigo-600 px-6 py-4 flex items-center justify-between">
              <h2 className="text-2xl font-orbitron font-black text-white uppercase">
                Notificações
              </h2>
              <button
                onClick={() => setIsOpen(false)}
                className="text-white hover:bg-white/20 p-2 rounded-lg transition-colors"
              >
                <X size={24} />
              </button>
            </div>

            {/* Conteúdo */}
            <div className="p-6">
              {current && (
                <div className="space-y-4">
                  {/* Mídia */}
                  {current.image && (
                    <img
                      src={current.image}
                      alt={current.title}
                      className="w-full rounded-lg max-h-96 object-cover border border-blue-500/30"
                    />
                  )}
                  {current.video && (
                    <video
                      src={current.video}
                      controls
                      className="w-full rounded-lg max-h-96 object-cover border border-blue-500/30"
                    />
                  )}

                  {/* Título */}
                  <h3 className="text-2xl font-bold text-white uppercase">{current.title}</h3>

                  {/* Descrição */}
                  <p className="text-slate-300 leading-relaxed">{current.description}</p>

                  {/* Metadados */}
                  <div className="bg-slate-950/50 border border-blue-500/20 rounded-lg p-4 text-sm">
                    <div className="flex justify-between text-slate-400">
                      <span>Por: <span className="text-blue-400 font-bold">{current.createdBy}</span></span>
                      <span>{new Date(current.createdAt).toLocaleDateString('pt-BR')}</span>
                    </div>
                  </div>

                  {/* Navegação */}
                  <div className="flex items-center justify-between pt-4 border-t border-slate-800">
                    <button
                      onClick={handlePrev}
                      className="bg-slate-800 hover:bg-slate-700 text-white p-2 rounded-lg transition-colors"
                    >
                      <ChevronLeft size={20} />
                    </button>
                    <span className="text-sm text-slate-400 font-bold">
                      {currentIndex + 1} de {notifications.length}
                    </span>
                    <button
                      onClick={handleNext}
                      className="bg-slate-800 hover:bg-slate-700 text-white p-2 rounded-lg transition-colors"
                    >
                      <ChevronRight size={20} />
                    </button>
                  </div>

                  {/* Indicadores */}
                  <div className="flex gap-2 justify-center pt-2">
                    {notifications.map((_, idx) => (
                      <button
                        key={idx}
                        onClick={() => setCurrentIndex(idx)}
                        className={`w-2 h-2 rounded-full transition-colors ${
                          idx === currentIndex ? 'bg-blue-500' : 'bg-slate-600'
                        }`}
                      />
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default NotificationDisplay;
