
import React from 'react';
import { SERVER_INFO } from '../constants';
import { Youtube, Instagram, Twitter, ChevronUp } from 'lucide-react';

const Footer: React.FC = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-slate-950 pt-24 pb-12 border-t border-blue-500/10">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-16 mb-20">
          <div className="col-span-1 md:col-span-1">
            <img 
              src={SERVER_INFO.logoUrl} 
              alt="Logo Legend RP" 
              className="w-40 mb-8 drop-shadow-[0_0_15px_rgba(59,130,246,0.3)]" 
            />
            <p className="text-slate-400 text-sm leading-relaxed mb-8 max-w-xs">
              O <span className="text-white font-bold tracking-tight">LEGEND ROLEPLAY</span> é o destino final para quem busca um SA-MP moderno, estável e inovador no Brasil.
            </p>
            <div className="flex gap-4">
              <a href="#" className="w-11 h-11 bg-slate-900 border border-slate-800 flex items-center justify-center rounded-xl text-slate-400 hover:text-blue-500 hover:border-blue-500/50 transition-all"><Youtube className="w-5 h-5"/></a>
              <a href="#" className="w-11 h-11 bg-slate-900 border border-slate-800 flex items-center justify-center rounded-xl text-slate-400 hover:text-blue-500 hover:border-blue-500/50 transition-all"><Instagram className="w-5 h-5"/></a>
              <a href="#" className="w-11 h-11 bg-slate-900 border border-slate-800 flex items-center justify-center rounded-xl text-slate-400 hover:text-blue-500 hover:border-blue-500/50 transition-all"><Twitter className="w-5 h-5"/></a>
            </div>
          </div>

          <div>
            <h4 className="font-orbitron font-bold text-white mb-8 uppercase text-xs tracking-[0.2em] border-l-2 border-blue-600 pl-4">Navegação</h4>
            <ul className="space-y-4 text-slate-500 text-sm font-semibold">
              <li><a href="#home" className="hover:text-blue-500 transition-colors">Início</a></li>
              <li><a href="#about" className="hover:text-blue-500 transition-colors">Sobre o Legend</a></li>
              <li><a href="#systems" className="hover:text-blue-500 transition-colors">Sistemas Inovadores</a></li>
              <li><a href="#how-to-play" className="hover:text-blue-500 transition-colors">Como Começar</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-orbitron font-bold text-white mb-8 uppercase text-xs tracking-[0.2em] border-l-2 border-blue-600 pl-4">Comunidade</h4>
            <ul className="space-y-4 text-slate-500 text-sm font-semibold">
              <li><a href={SERVER_INFO.discordUrl} className="hover:text-blue-500 transition-colors">Discord Oficial</a></li>
              <li><a href="#rules" className="hover:text-blue-500 transition-colors">Regras de RP</a></li>
              <li><a href="#" className="hover:text-blue-500 transition-colors">Fórum Legend</a></li>
              <li><a href="#" className="hover:text-blue-500 transition-colors">Suporte Staff</a></li>
            </ul>
          </div>

          <div>
             <h4 className="font-orbitron font-bold text-white mb-8 uppercase text-xs tracking-[0.2em] border-l-2 border-blue-600 pl-4">Servidor</h4>
             <p className="text-slate-400 text-sm mb-6">Entre agora e crie seu legado:</p>
             <div className="bg-slate-900/80 p-5 rounded-2xl border border-blue-500/20 font-mono text-sm text-blue-400 shadow-inner">
                {SERVER_INFO.ip}
             </div>
          </div>
        </div>

        <div className="pt-10 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-8">
          <p className="text-slate-600 text-sm font-medium">
            &copy; {new Date().getFullYear()} <span className="text-slate-400 font-bold uppercase tracking-wider">Legend Roleplay</span>. Desenvolvido para a elite do SA-MP.
          </p>
          <button 
            onClick={scrollToTop}
            className="group w-14 h-14 bg-blue-600 rounded-2xl flex items-center justify-center text-white hover:bg-blue-500 transition-all shadow-2xl hover:shadow-blue-600/40 active:scale-95"
          >
            <ChevronUp className="w-7 h-7 group-hover:-translate-y-1 transition-transform" />
          </button>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
