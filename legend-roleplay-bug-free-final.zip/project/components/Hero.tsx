
import React from 'react';
import { SERVER_INFO } from '../constants';
import { ChevronDown, MessageSquare, Play } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <div className="relative h-screen w-full flex items-center justify-center overflow-hidden">
      {/* Video Background */}
      <div className="absolute inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-b from-slate-950/90 via-slate-950/50 to-slate-950 z-10"></div>
        <video
          autoPlay
          muted
          loop
          playsInline
          className="w-full h-full object-cover scale-105"
        >
          <source src={SERVER_INFO.heroVideo} type="video/mp4" />
        </video>
      </div>

      {/* Content */}
      <div className="relative z-20 text-center px-4 max-w-5xl mx-auto">
        <div className="flex justify-center mb-12">
           <div className="relative group p-4">
              {/* Glow effect behind logo */}
              <div className="absolute inset-0 bg-blue-600/20 blur-[80px] rounded-full group-hover:bg-blue-500/30 transition-all duration-700"></div>
              
              <img 
                src={SERVER_INFO.logoUrl} 
                alt="Legend Roleplay Official Logo" 
                className="relative z-10 w-64 md:w-80 lg:w-[480px] h-auto drop-shadow-[0_0_30px_rgba(59,130,246,0.7)] transition-transform duration-500 group-hover:scale-105"
                onError={(e) => {
                  const target = e.target as HTMLImageElement;
                  // Tenta um formato de link diferente caso o postimg falhe
                  if (!target.src.includes('postimg.cc/raw')) {
                    target.src = "https://i.postimg.cc/Wb7CjV6j/legend-logo.png";
                  }
                }}
              />
           </div>
        </div>
        
        <h1 className="font-orbitron text-4xl md:text-6xl lg:text-8xl font-black text-white mb-6 tracking-tighter uppercase italic leading-none">
          O NOVO ROLEPLAY <br/> <span className="text-blue-500 text-glow">INOVADOR</span> DO SA-MP
        </h1>
        
        <p className="text-lg md:text-2xl text-slate-300 mb-12 max-w-3xl mx-auto font-medium tracking-wide leading-relaxed">
          Venha para o <span className="text-blue-400 font-bold">LEGEND RP</span>. Performance máxima, sistemas exclusivos e o realismo que você sempre buscou.
        </p>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
          <a
            href="#how-to-play"
            className="group relative px-12 py-5 bg-blue-600 hover:bg-blue-500 text-white font-black rounded-xl transition-all flex items-center gap-4 overflow-hidden shadow-[0_0_30px_rgba(59,130,246,0.6)] active:scale-95 text-lg"
          >
            <div className="absolute inset-0 w-1/3 h-full bg-white/20 skew-x-[-20deg] -translate-x-full group-hover:translate-x-[400%] transition-transform duration-1000"></div>
            <Play className="w-6 h-6 fill-current" />
            JOGAR AGORA
          </a>
          <a
            href={SERVER_INFO.discordUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="px-12 py-5 bg-slate-800/60 hover:bg-slate-700/80 text-white font-bold rounded-xl transition-all border border-slate-600 flex items-center gap-4 backdrop-blur-md active:scale-95 text-lg"
          >
            <MessageSquare className="w-6 h-6" />
            DISCORD OFICIAL
          </a>
        </div>
        
        <div className="mt-8 inline-block px-4 py-2 bg-blue-900/20 rounded-full border border-blue-500/30 backdrop-blur-sm">
           <code className="text-blue-400 font-mono font-bold text-sm tracking-widest">{SERVER_INFO.ip}</code>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-10 left-1/2 -translate-x-1/2 z-20 animate-bounce cursor-pointer opacity-70 hover:opacity-100" onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}>
        <ChevronDown className="w-10 h-10 text-blue-500" />
      </div>
    </div>
  );
};

export default Hero;
