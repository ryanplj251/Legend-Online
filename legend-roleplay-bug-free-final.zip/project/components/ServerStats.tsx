import React, { useEffect, useState } from 'react';
import { Users, Zap, Clock, Activity, Server, TrendingUp } from 'lucide-react';

interface ServerStat {
  label: string;
  value: string | number;
  icon: React.ReactNode;
  color: string;
  trend?: string;
}

const ServerStats: React.FC = () => {
  const [stats, setStats] = useState<ServerStat[]>([]);

  useEffect(() => {
    // Simular dados em tempo real
    const updateStats = () => {
      setStats([
        {
          label: 'Jogadores Online',
          value: Math.floor(Math.random() * 150) + 50,
          icon: <Users size={32} />,
          color: 'from-blue-600 to-blue-900',
          trend: '+12%'
        },
        {
          label: 'Uptime',
          value: '99.8%',
          icon: <Activity size={32} />,
          color: 'from-green-600 to-green-900',
          trend: '+0.2%'
        },
        {
          label: 'Ping Médio',
          value: '45ms',
          icon: <Zap size={32} />,
          color: 'from-yellow-600 to-yellow-900',
          trend: '-5ms'
        },
        {
          label: 'Total de Contas',
          value: '2,847',
          icon: <Users size={32} />,
          color: 'from-purple-600 to-purple-900',
          trend: '+23'
        },
        {
          label: 'Tempo Médio Sessão',
          value: '2.4h',
          icon: <Clock size={32} />,
          color: 'from-pink-600 to-pink-900',
          trend: '+0.3h'
        },
        {
          label: 'Taxa de Retorno',
          value: '87%',
          icon: <TrendingUp size={32} />,
          color: 'from-indigo-600 to-indigo-900',
          trend: '+5%'
        }
      ]);
    };

    updateStats();
    const interval = setInterval(updateStats, 10000); // Atualiza a cada 10 segundos

    return () => clearInterval(interval);
  }, []);

  return (
    <section className="py-20 bg-gradient-to-b from-slate-950 to-slate-900">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Server className="text-blue-400" size={40} />
            <h2 className="text-4xl font-orbitron font-black text-white uppercase tracking-tighter">
              Estatísticas do <span className="text-blue-500">Servidor</span>
            </h2>
          </div>
          <p className="text-slate-400 text-sm uppercase tracking-widest">Dados em tempo real</p>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {stats.map((stat, idx) => (
            <div
              key={idx}
              className={`bg-gradient-to-br ${stat.color} border border-white/10 rounded-2xl p-8 hover:border-white/20 transition-all duration-300 group cursor-pointer`}
            >
              <div className="flex items-start justify-between mb-6">
                <div className="text-white/80 group-hover:text-white transition-colors">
                  {stat.icon}
                </div>
                {stat.trend && (
                  <div className="bg-white/10 px-3 py-1 rounded-lg">
                    <span className="text-xs font-black text-white uppercase">{stat.trend}</span>
                  </div>
                )}
              </div>
              <p className="text-slate-300 text-xs uppercase font-bold tracking-widest mb-2">
                {stat.label}
              </p>
              <p className="text-4xl font-black text-white group-hover:scale-110 transition-transform">
                {stat.value}
              </p>
            </div>
          ))}
        </div>

        {/* Info Box */}
        <div className="mt-12 bg-blue-500/10 border border-blue-500/30 rounded-2xl p-8 text-center">
          <p className="text-slate-300 text-sm font-archivo">
            Nosso servidor está otimizado para oferecer a melhor experiência de jogo com latência mínima e máxima estabilidade. 
            <span className="block mt-2 text-blue-400 font-bold">Junte-se a milhares de jogadores agora!</span>
          </p>
        </div>
      </div>
    </section>
  );
};

export default ServerStats;
