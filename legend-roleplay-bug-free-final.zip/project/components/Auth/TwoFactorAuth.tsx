
import React, { useState } from 'react';
import { Lock, Copy, Check, AlertCircle } from 'lucide-react';

interface TwoFactorAuthProps {
  onVerify: (code: string) => void;
  onBackupCode: (code: string) => void;
  backupCodesAvailable: number;
  isLoading: boolean;
}

const TwoFactorAuth: React.FC<TwoFactorAuthProps> = ({
  onVerify,
  onBackupCode,
  backupCodesAvailable,
  isLoading
}) => {
  const [code, setCode] = useState('');
  const [useBackupCode, setUseBackupCode] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (useBackupCode) {
      onBackupCode(code);
    } else {
      onVerify(code);
    }
    setCode('');
  };

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-gradient-to-b from-slate-900 to-slate-950 border border-purple-500/30 rounded-2xl p-8 max-w-md w-full shadow-2xl">
        
        <div className="flex items-center gap-3 mb-6">
          <Lock className="text-purple-500" size={28} />
          <h2 className="text-2xl font-orbitron font-bold text-white">Autenticação 2FA</h2>
        </div>

        <p className="text-sm text-slate-300 mb-6">
          {useBackupCode
            ? 'Digite um dos seus códigos de backup'
            : 'Digite o código de 6 dígitos do seu autenticador'}
        </p>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase mb-2">
              {useBackupCode ? 'Código de Backup' : 'Código 2FA'}
            </label>
            <input
              type="text"
              value={code}
              onChange={(e) => setCode(e.target.value.toUpperCase())}
              placeholder={useBackupCode ? 'ABC123DEF456' : '000000'}
              maxLength={useBackupCode ? 12 : 6}
              className="w-full bg-slate-950 border border-purple-500/30 rounded-lg px-4 py-3 text-white text-center font-mono text-lg focus:border-purple-500 outline-none transition-colors"
              disabled={isLoading}
              autoFocus
            />
          </div>

          <button
            type="submit"
            disabled={isLoading || code.length < (useBackupCode ? 8 : 6)}
            className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 disabled:opacity-50 text-white font-bold py-3 rounded-lg transition-all uppercase text-sm tracking-widest"
          >
            {isLoading ? 'Verificando...' : 'Verificar'}
          </button>
        </form>

        <div className="mt-6 pt-6 border-t border-white/10">
          <button
            onClick={() => setUseBackupCode(!useBackupCode)}
            className="text-sm text-purple-400 hover:text-purple-300 transition-colors"
          >
            {useBackupCode
              ? '← Voltar para código 2FA'
              : `Usar código de backup (${backupCodesAvailable} disponíveis)`}
          </button>
        </div>

        <div className="mt-6 p-4 bg-blue-500/10 border border-blue-500/30 rounded-lg">
          <div className="flex items-start gap-3">
            <AlertCircle className="text-blue-500 flex-shrink-0 mt-0.5" size={18} />
            <p className="text-xs text-blue-400">
              Guarde seus códigos de backup em local seguro. Eles são a única forma de recuperar sua conta se perder acesso ao autenticador.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TwoFactorAuth;
