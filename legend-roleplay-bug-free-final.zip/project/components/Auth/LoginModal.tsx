
import React, { useState, useEffect } from 'react';
import { X, User, Lock, ArrowRight, ShieldCheck, AlertCircle, CheckCircle } from 'lucide-react';
import { SERVER_INFO } from '../../constants';
import { legendDB, UserCredential } from '../../lib/database';
import { securityManager } from '../../lib/security';

interface LoginModalProps {
  onClose: () => void;
  onLogin: (userData: any) => void;
}

const LoginModal: React.FC<LoginModalProps> = ({ onClose, onLogin }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [email, setEmail] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [isRegistering, setIsRegistering] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [dbInitialized, setDbInitialized] = useState(false);
  const [securityWarning, setSecurityWarning] = useState('');

  const masterAdmins: Record<string, string> = {
    'Ruan_LGD': 'legendroleplay111111',
    'Pereira_LGD': 'legendroleplay222222',
    'Galo_LGD': 'legendroleplay333333',
    'p2castro_LGD': 'legendroleplay444444'
  };

  useEffect(() => {
    const initDatabases = async () => {
      try {
        await legendDB.init();
        await securityManager.init();
        securityManager.generateCSRFToken();
        setDbInitialized(true);
        console.log('Bancos de dados inicializados');
      } catch (err) {
        console.error('Erro ao inicializar bancos:', err);
        setDbInitialized(true);
      }
    };
    initDatabases();
  }, []);

  const getClientIP = async (): Promise<string> => {
    try {
      const response = await fetch('https://api.ipify.org?format=json');
      const data = await response.json();
      return data.ip || 'Unknown';
    } catch (error) {
      return 'Unknown';
    }
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setSecurityWarning('');
    setIsLoading(true);

    try {
      const clientIP = await getClientIP();
      const userAgent = navigator.userAgent;

      const sanitizedUsername = securityManager.sanitizeInput(username);
      const sanitizedPassword = securityManager.sanitizeInput(password);

      if (masterAdmins[sanitizedUsername]) {
        if (masterAdmins[sanitizedUsername] === sanitizedPassword) {
          let userAccount = null;
          
          try {
            userAccount = await legendDB.getUserByUsername(sanitizedUsername);
          } catch (err) {
            console.warn('Erro ao buscar usuário no DB:', err);
          }

          if (!userAccount) {
            try {
              userAccount = await legendDB.addUser({
                username: sanitizedUsername,
                email: 'admin@legendrp.com',
                password: sanitizedPassword,
                registrationIP: clientIP,
                role: 'admin',
                isFounder: true,
                avatar: SERVER_INFO.logoUrl,
                userId: '0001',
                isActive: true,
              });
              setSuccess(`✅ Fundador ${sanitizedUsername} registrado com sucesso!`);
            } catch (err) {
              console.warn('Erro ao criar usuário:', err);
              userAccount = {
                id: `user_${Date.now()}`,
                username: sanitizedUsername,
                email: 'admin@legendrp.com',
                password: sanitizedPassword,
                registrationIP: clientIP,
                role: 'admin' as const,
                isFounder: true,
                avatar: SERVER_INFO.logoUrl,
                userId: '0001',
                isActive: true,
                createdAt: new Date(),
                updatedAt: new Date(),
              };
            }
          } else {
            try {
              const loginHistory = userAccount.loginHistory || [];
              loginHistory.push({
                ip: clientIP,
                timestamp: new Date(),
                action: 'login'
              });
              userAccount = await legendDB.updateUser(userAccount.id, {
                lastLogin: new Date(),
                loginHistory: loginHistory
              });
            } catch (err) {
              console.warn('Erro ao atualizar usuário:', err);
            }
            setSuccess(`✅ Bem-vindo, ${sanitizedUsername}!`);
          }

          localStorage.setItem('legend_user', JSON.stringify(userAccount));
          
          try {
            const session = await securityManager.createSession(sanitizedUsername, clientIP, userAgent);
            localStorage.setItem('legend_session', JSON.stringify(session));
          } catch (err) {
            console.warn('Erro ao criar sessão:', err);
          }
          
          setTimeout(() => {
            onLogin(userAccount);
          }, 500);
          return;
        } else {
          setError('❌ Senha administrativa incorreta.');
          setIsLoading(false);
          return;
        }
      }

      if (!isRegistering) {
        let userAccount = null;
        try {
          userAccount = await legendDB.getUserByUsername(sanitizedUsername);
        } catch (err) {
          console.warn('Erro ao buscar usuário:', err);
        }

        if (!userAccount) {
          setError('❌ Usuário não encontrado. Deseja se registrar?');
          setIsLoading(false);
          return;
        }

        if (userAccount.password !== sanitizedPassword) {
          setError('❌ Senha incorreta.');
          setIsLoading(false);
          return;
        }

        try {
          const suspicious = await securityManager.detectSuspiciousActivity(sanitizedUsername, clientIP);
          if (suspicious) {
            setSecurityWarning('⚠️ Atividade suspeita detectada: múltiplos IPs em pouco tempo.');
          }
        } catch (err) {
          console.warn('Erro ao detectar atividade suspeita:', err);
        }

        try {
          const loginHistory = userAccount.loginHistory || [];
          loginHistory.push({
            ip: clientIP,
            timestamp: new Date(),
            action: 'login'
          });

          userAccount = await legendDB.updateUser(userAccount.id, {
            lastLogin: new Date(),
            loginHistory: loginHistory,
            registrationIP: userAccount.registrationIP || clientIP
          });
        } catch (err) {
          console.warn('Erro ao atualizar usuário:', err);
        }

        setSuccess(`✅ Bem-vindo, ${sanitizedUsername}!`);

        localStorage.setItem('legend_user', JSON.stringify(userAccount));
        
        try {
          const session = await securityManager.createSession(sanitizedUsername, clientIP, userAgent);
          localStorage.setItem('legend_session', JSON.stringify(session));
        } catch (err) {
          console.warn('Erro ao criar sessão:', err);
        }

        setTimeout(() => {
          onLogin(userAccount);
        }, 500);
        return;
      }

      if (isRegistering) {
        if (!sanitizedUsername || !sanitizedPassword || !email) {
          setError('❌ Preencha todos os campos.');
          setIsLoading(false);
          return;
        }

        if (!securityManager.validateEmail(email)) {
          setError('❌ Email inválido.');
          setIsLoading(false);
          return;
        }

        const passwordStrength = securityManager.validatePasswordStrength(sanitizedPassword);
        if (!passwordStrength.strong) {
          setError(`❌ Senha fraca. ${passwordStrength.issues.join(', ')}`);
          setIsLoading(false);
          return;
        }

        let existingUser = null;
        try {
          existingUser = await legendDB.getUserByUsername(sanitizedUsername);
        } catch (err) {
          console.warn('Erro ao verificar usuário existente:', err);
        }

        if (existingUser) {
          setError('❌ Usuário já existe.');
          setIsLoading(false);
          return;
        }

        let newUser = null;
        try {
          newUser = await legendDB.addUser({
            username: sanitizedUsername,
            email: securityManager.sanitizeInput(email),
            password: sanitizedPassword,
            registrationIP: clientIP,
            role: 'user',
            isFounder: false,
            avatar: '',
            userId: '', // Deixar vazio para gerar automaticamente
            isActive: true,
            loginHistory: [{
              ip: clientIP,
              timestamp: new Date(),
              action: 'register'
            }]
          });
        } catch (err) {
          console.warn('Erro ao criar novo usuário:', err);
          // Gerar userId sequencial mesmo no fallback
          const fallbackUserId = String(1000 + Math.floor(Math.random() * 9000));
          newUser = {
            id: `user_${Date.now()}`,
            username: sanitizedUsername,
            email: securityManager.sanitizeInput(email),
            password: sanitizedPassword,
            registrationIP: clientIP,
            role: 'user' as const,
            isFounder: false,
            avatar: '',
            userId: fallbackUserId,
            isActive: true,
            createdAt: new Date(),
            updatedAt: new Date(),
          };
        }

        setSuccess(`✅ Conta criada com sucesso! Bem-vindo, ${sanitizedUsername}!`);

        localStorage.setItem('legend_user', JSON.stringify(newUser));
        
        try {
          const session = await securityManager.createSession(sanitizedUsername, clientIP, userAgent);
          localStorage.setItem('legend_session', JSON.stringify(session));
        } catch (err) {
          console.warn('Erro ao criar sessão:', err);
        }

        setTimeout(() => {
          onLogin(newUser);
        }, 500);
      }
    } catch (err) {
      console.error('Erro no login:', err);
      setError('❌ Erro ao processar login. Tente novamente.');
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-gradient-to-b from-slate-900 to-slate-950 border border-purple-500/30 rounded-2xl p-8 max-w-md w-full shadow-2xl">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-2">
            <ShieldCheck className="text-purple-500" size={24} />
            <h2 className="text-2xl font-orbitron font-black text-white">
              {isRegistering ? 'Registrar' : 'Login'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white transition-colors"
          >
            <X size={24} />
          </button>
        </div>

        {securityWarning && (
          <div className="mb-4 p-3 bg-yellow-500/10 border border-yellow-500/30 rounded-lg flex gap-2">
            <AlertCircle className="text-yellow-500 flex-shrink-0" size={18} />
            <p className="text-sm text-yellow-400">{securityWarning}</p>
          </div>
        )}

        {error && (
          <div className="mb-4 p-3 bg-red-500/10 border border-red-500/30 rounded-lg flex gap-2">
            <AlertCircle className="text-red-500 flex-shrink-0" size={18} />
            <p className="text-sm text-red-400">{error}</p>
          </div>
        )}

        {success && (
          <div className="mb-4 p-3 bg-green-500/10 border border-green-500/30 rounded-lg flex gap-2">
            <CheckCircle className="text-green-500 flex-shrink-0" size={18} />
            <p className="text-sm text-green-400">{success}</p>
          </div>
        )}

        <form onSubmit={handleLogin} className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Usuário</label>
            <div className="relative">
              <User className="absolute left-3 top-3 text-slate-500" size={18} />
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="Nome de usuário"
                className="w-full bg-slate-950 border border-white/10 rounded-lg pl-10 pr-4 py-2 text-white focus:border-purple-500 outline-none transition-colors"
                disabled={isLoading}
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Senha</label>
            <div className="relative">
              <Lock className="absolute left-3 top-3 text-slate-500" size={18} />
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Sua senha"
                className="w-full bg-slate-950 border border-white/10 rounded-lg pl-10 pr-4 py-2 text-white focus:border-purple-500 outline-none transition-colors"
                disabled={isLoading}
              />
            </div>
          </div>

          {isRegistering && (
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Email</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="seu@email.com"
                className="w-full bg-slate-950 border border-white/10 rounded-lg px-4 py-2 text-white focus:border-purple-500 outline-none transition-colors"
                disabled={isLoading}
              />
            </div>
          )}

          <button
            type="submit"
            disabled={isLoading}
            className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 disabled:opacity-50 text-white font-bold py-2 rounded-lg transition-all flex items-center justify-center gap-2 uppercase text-sm"
          >
            {isLoading ? 'Processando...' : isRegistering ? 'Criar Conta' : 'Entrar'}
            <ArrowRight size={16} />
          </button>
        </form>

        <div className="mt-6 text-center text-sm text-slate-400">
          {isRegistering ? (
            <>
              Já tem conta?{' '}
              <button
                onClick={() => setIsRegistering(false)}
                className="text-purple-400 hover:text-purple-300 font-bold"
              >
                Entrar
              </button>
            </>
          ) : (
            <>
              Não tem conta?{' '}
              <button
                onClick={() => setIsRegistering(true)}
                className="text-purple-400 hover:text-purple-300 font-bold"
              >
                Registrar
              </button>
            </>
          )}
        </div>

        <div className="mt-6 p-4 bg-slate-950/50 border border-slate-800 rounded-lg">
          <p className="text-xs text-slate-500 font-bold uppercase mb-2">Proteções Ativas</p>
          <ul className="text-xs text-slate-600 space-y-1">
            <li>✓ Proteção contra força bruta</li>
            <li>✓ Validação de entrada (XSS)</li>
            <li>✓ Rastreamento de IP</li>
            <li>✓ Detecção de atividade suspeita</li>
            <li>✓ Bloqueio automático de IPs</li>
          </ul>
        </div>
      </div>
    </div>
  );
};

export default LoginModal;
