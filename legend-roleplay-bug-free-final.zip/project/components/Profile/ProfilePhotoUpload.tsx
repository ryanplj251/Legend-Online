import React, { useRef, useState } from 'react';
import { Upload, X, Image as ImageIcon, Loader } from 'lucide-react';

interface ProfilePhotoUploadProps {
  onClose: () => void;
  onUpload: (photoUrl: string) => void;
  currentPhoto?: string;
}

const ProfilePhotoUpload: React.FC<ProfilePhotoUploadProps> = ({ onClose, onUpload, currentPhoto }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string>(currentPhoto || '');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [dragActive, setDragActive] = useState(false);

  const handleFileSelect = (file: File) => {
    setError('');

    // Validar tipo de arquivo
    if (!file.type.startsWith('image/')) {
      setError('Por favor, selecione uma imagem válida (JPG, PNG, GIF, WebP)');
      return;
    }

    // Validar tamanho (máximo 5MB)
    if (file.size > 5 * 1024 * 1024) {
      setError('A imagem não pode ser maior que 5MB');
      return;
    }

    setSelectedFile(file);

    // Criar preview
    const reader = new FileReader();
    reader.onload = (e) => {
      setPreview(e.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      handleFileSelect(file);
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    const file = e.dataTransfer.files?.[0];
    if (file) {
      handleFileSelect(file);
    }
  };

  const handleUpload = async () => {
    if (!selectedFile) {
      setError('Selecione uma imagem primeiro');
      return;
    }

    setLoading(true);
    setError('');

    try {
      const reader = new FileReader();
      reader.onload = (e) => {
        const base64Data = e.target?.result as string;
        
        localStorage.setItem('legend_avatar', base64Data);
        
        const userData = JSON.parse(localStorage.getItem('legend_user') || '{}');
        userData.avatar = base64Data;
        localStorage.setItem('legend_user', JSON.stringify(userData));
        
        const accounts = JSON.parse(localStorage.getItem('legend_accounts') || '[]');
        const userIndex = accounts.findIndex((acc: any) => acc.name === userData.name);
        if (userIndex !== -1) {
          accounts[userIndex].avatar = base64Data;
          localStorage.setItem('legend_accounts', JSON.stringify(accounts));
        }

        onUpload(base64Data);
        setLoading(false);
      };
      reader.readAsDataURL(selectedFile);
    } catch (err) {
      setError('Erro ao fazer upload da imagem');
      setLoading(false);
    }
  };

  const handleRemovePhoto = () => {
    setSelectedFile(null);
    setPreview('');
    setError('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm" onClick={onClose}></div>
      
      <div className="relative w-full max-w-md bg-slate-900 border border-blue-500/30 rounded-3xl overflow-hidden shadow-2xl animate-in zoom-in duration-300">
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-600 via-indigo-500 to-blue-600"></div>
        
        <div className="p-8">
          {/* Header */}
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-2xl font-orbitron font-bold text-white uppercase tracking-tighter">
              Foto de <span className="text-blue-500">Perfil</span>
            </h2>
            <button
              onClick={onClose}
              className="p-2 hover:bg-white/10 rounded-lg text-slate-400 transition-colors"
            >
              <X size={20} />
            </button>
          </div>

          {/* Preview */}
          {preview ? (
            <div className="mb-8">
              <div className="relative w-full aspect-square rounded-2xl overflow-hidden border-2 border-blue-500/30 bg-slate-950">
                <img
                  src={preview}
                  alt="Preview"
                  className="w-full h-full object-cover"
                />
              </div>
              <p className="text-xs text-slate-400 mt-3 text-center uppercase tracking-widest">
                {selectedFile?.name || 'Imagem selecionada'}
              </p>
            </div>
          ) : (
            <div className="mb-8">
              <div className="w-full aspect-square rounded-2xl border-2 border-dashed border-blue-500/30 bg-slate-950/50 flex items-center justify-center">
                <ImageIcon size={48} className="text-slate-600" />
              </div>
            </div>
          )}

          {/* Upload Area */}
          <div
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
            className={`border-2 border-dashed rounded-xl p-8 text-center transition-all mb-6 cursor-pointer ${
              dragActive
                ? 'border-blue-500 bg-blue-500/10'
                : 'border-slate-700 bg-slate-950/50 hover:border-blue-500/50'
            }`}
            onClick={() => fileInputRef.current?.click()}
          >
            <Upload className="mx-auto mb-3 text-blue-500" size={32} />
            <p className="text-white font-bold mb-1">Clique ou arraste uma imagem</p>
            <p className="text-slate-400 text-xs">JPG, PNG, GIF ou WebP (máx. 5MB)</p>
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*"
              onChange={handleInputChange}
              className="hidden"
            />
          </div>

          {/* Error Message */}
          {error && (
            <div className="p-3 bg-red-500/10 border border-red-500/30 text-red-500 text-xs font-bold uppercase rounded-lg mb-6">
              {error}
            </div>
          )}

          {/* Buttons */}
          <div className="flex gap-3">
            {preview && (
              <button
                onClick={handleRemovePhoto}
                disabled={loading}
                className="flex-1 bg-slate-800 hover:bg-slate-700 disabled:bg-slate-700 text-white font-bold py-3 rounded-xl transition-all uppercase text-sm"
              >
                Remover
              </button>
            )}
            <button
              onClick={handleUpload}
              disabled={!selectedFile || loading}
              className="flex-1 bg-blue-600 hover:bg-blue-500 disabled:bg-slate-700 text-white font-bold py-3 rounded-xl transition-all flex items-center justify-center gap-2 uppercase text-sm"
            >
              {loading ? (
                <>
                  <Loader size={16} className="animate-spin" /> Enviando...
                </>
              ) : (
                <>
                  <Upload size={16} /> Confirmar
                </>
              )}
            </button>
          </div>

          {/* Info */}
          <p className="text-slate-500 text-[10px] mt-6 text-center uppercase tracking-widest">
            A imagem será armazenada localmente e usada em seu perfil
          </p>
        </div>
      </div>
    </div>
  );
};

export default ProfilePhotoUpload;
