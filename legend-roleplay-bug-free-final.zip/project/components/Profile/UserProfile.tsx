
import React, { useState, useEffect } from 'react';
import { User, MessageSquare, Shield, Clock, MapPin, ArrowLeft, FileText } from 'lucide-react';

interface UserProfileProps {
  username: string;
  currentUser: any;
  onOpenChat: () => void;
  onBack: () => void;
}

const UserProfile: React.FC<UserProfileProps> = ({ username, currentUser, onOpenChat, onBack }) => {
  const [profileData, setProfileData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadProfile = () => {
      const accounts = JSON.parse(localStorage.getItem('legend_accounts') || '[]');
      const profile = accounts.find((acc: any) => acc.name === username) || {
        name: username,
        avatar: '',
        role: 'user',
        userId: '1000',
        bio: ''
      };
      setProfileData(profile);
      setLoading(false);
    };

    loadProfile();
    // Recarregar perfil a cada 1 segundo para sincronizar mudanças de biografia
    const interval = setInterval(loadProfile, 1000);
    return () => clearInterval(interval);
  }, [username]);

  if (loading || !profileData) {
    return (
      <div className="pt-32 pb-20 container mx-auto px-4 font-archivo">
        <button onClick={onBack} className="flex items-center gap-2 text-blue-500 font-bold mb-8 uppercase text-xs tracking-widest">
          <ArrowLeft size={16} /> Voltar ao Fórum
        </button>
        <div className="text-center text-slate-400">Carregando perfil...</div>
      </div>
    );
  }

  const stats = {
    level: 15,
    joined: 'Jan 2024',
    job: 'Caminhoneiro',
    warns: 0,
    isStaff: profileData.role === 'admin' || profileData.role === 'staff'
  };

  const startConversation = () => {
    if (!currentUser) {
      alert("Você precisa estar logado para enviar mensagens.");
      return;
    }
    localStorage.setItem('legend_active_chat_with', username);
    onOpenChat();
  };

  return (
    <div className="pt-32 pb-20 container mx-auto px-4 font-archivo">
      <button onClick={onBack} className="flex items-center gap-2 text-blue-500 font-bold mb-8 uppercase text-xs tracking-widest">
        <ArrowLeft size={16} /> Voltar ao Fórum
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1">
          <div className="bg-slate-900 border border-white/5 rounded-[2.5rem] overflow-hidden shadow-2xl relative">
            <div className="h-32 bg-gradient-to-r from-blue-600 to-indigo-800"></div>
            <div className="p-8 -mt-16 text-center">
              <div className="inline-block relative">
                <div className="w-32 h-32 bg-slate-950 rounded-3xl border-4 border-slate-900 flex items-center justify-center text-slate-500 shadow-xl overflow-hidden">
                   {profileData.avatar ? <img src={profileData.avatar} className="w-full h-full object-cover" /> : <User size={64} />}
                </div>
                {stats.isStaff && <div className="absolute bottom-0 right-0 bg-amber-500 text-white p-2 rounded-xl border-4 border-slate-900 shadow-lg"><Shield size={16} /></div>}
              </div>
              <h2 className="mt-4 text-3xl font-orbitron font-black text-white uppercase tracking-tighter italic">{username}</h2>
              <p className="text-slate-500 font-bold uppercase text-[10px] tracking-widest mb-6">{stats.isStaff ? 'Membro da Staff' : 'Membro da Comunidade'}</p>
              {currentUser?.name !== username && (
                <button onClick={startConversation} className="w-full bg-blue-600 hover:bg-blue-500 text-white font-black py-4 rounded-2xl flex items-center justify-center gap-3 transition-all uppercase shadow-lg shadow-blue-600/20 active:scale-95 mb-4"><MessageSquare size={20} /> Enviar Mensagem</button>
              )}
              <div className="pt-6 border-t border-white/5 grid grid-cols-2 gap-4">
                <div className="p-4 bg-slate-950/50 rounded-2xl border border-white/5">
                   <p className="text-[10px] text-slate-600 font-black uppercase">Level RP</p>
                   <p className="text-xl font-orbitron text-white italic">{stats.level}</p>
                </div>
                <div className="p-4 bg-slate-950/50 rounded-2xl border border-white/5">
                   <p className="text-[10px] text-slate-600 font-black uppercase">ID Único</p>
                   <p className="text-xl font-orbitron text-white italic">{profileData.userId}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="lg:col-span-2 space-y-8">
           {profileData.bio && profileData.bio.trim() && (
             <div className="bg-slate-900 border border-white/5 rounded-[2.5rem] p-10 shadow-xl animate-in fade-in">
               <h3 className="text-2xl font-orbitron font-black text-white uppercase italic mb-6 border-b border-white/5 pb-4 flex items-center gap-3"><FileText size={24} className="text-blue-500" /> Biografia</h3>
               <p className="text-slate-300 leading-relaxed">{profileData.bio}</p>
             </div>
           )}
           <div className="bg-slate-900 border border-white/5 rounded-[2.5rem] p-10 shadow-xl">
             <h3 className="text-2xl font-orbitron font-black text-white uppercase italic mb-8 border-b border-white/5 pb-4">Histórico de <span className="text-blue-500">Jogo</span></h3>
             <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="flex items-center gap-4">
                   <div className="w-12 h-12 bg-blue-500/10 rounded-xl flex items-center justify-center text-blue-500"><Clock size={20}/></div>
                   <div><p className="text-[10px] text-slate-500 font-black uppercase">Entrou em</p><p className="text-white font-bold uppercase">{stats.joined}</p></div>
                </div>
                <div className="flex items-center gap-4">
                   <div className="w-12 h-12 bg-blue-500/10 rounded-xl flex items-center justify-center text-blue-500"><MapPin size={20}/></div>
                   <div><p className="text-[10px] text-slate-500 font-black uppercase">Trabalho</p><p className="text-white font-bold uppercase">{stats.job}</p></div>
                </div>
             </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default UserProfile;
