
import React, { useState } from 'react';
import { User, Mail, Phone, Lock, Save, ArrowLeft, Camera, CheckCircle, AlertCircle, Shield, FileText } from 'lucide-react';
import ProfilePhotoUpload from './ProfilePhotoUpload';
import { legendDB } from '../../lib/database';

interface AccountSettingsProps {
  user: any;
  onUpdate: (updated: any) => void;
  onBack: () => void;
}

const AccountSettings: React.FC<AccountSettingsProps> = ({ user, onUpdate, onBack }) => {
  const savedAvatar = localStorage.getItem('legend_avatar');
  const [formData, setFormData] = useState({
    name: user.name,
    email: user.email || '',
    phone: user.phone || '',
    avatar: user.avatar || savedAvatar || '',
    userId: user.userId || '1234',
    bio: user.bio || ''
  });

  const [passwordData, setPasswordData] = useState({
    current: '',
    new: '',
    confirm: ''
  });

  const [status, setStatus] = useState<{type: 'success'|'error', msg: string} | null>(null);
  const [showPhotoUpload, setShowPhotoUpload] = useState(false);

  const handlePhotoUpload = (photoUrl: string) => {
    setFormData({ ...formData, avatar: photoUrl });
    setShowPhotoUpload(false);
    setStatus({ type: 'success', msg: 'Foto de perfil atualizada!' });
    setTimeout(() => setStatus(null), 3000);
  };

  const handleProfileUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    const accounts = JSON.parse(localStorage.getItem('legend_accounts') || '[]');
    const updatedAccounts = accounts.map((acc: any) => {
      if (acc.name === user.name) {
        return { ...acc, ...formData, bio: formData.bio };
      }
      return acc;
    });
    localStorage.setItem('legend_accounts', JSON.stringify(updatedAccounts));
    
    const updatedSession = { ...user, ...formData, bio: formData.bio };
    onUpdate(updatedSession);
    
    // Também atualizar no IndexedDB se disponível
    try {
      legendDB.updateUser(user.id, { bio: formData.bio }).catch((err: any) => console.warn('Erro ao atualizar bio no DB:', err));
    } catch (err) {
      console.warn('IndexedDB não disponível');
    }
    
    setStatus({type: 'success', msg: 'Perfil atualizado com sucesso!'});
    setTimeout(() => setStatus(null), 3000);
  };

  const handlePasswordUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    
    const accounts = JSON.parse(localStorage.getItem('legend_accounts') || '[]');
    const accountIndex = accounts.findIndex((acc: any) => acc.name === user.name);
    const account = accounts[accountIndex];

    if (account.password !== passwordData.current) {
      setStatus({type: 'error', msg: 'Senha atual incorreta.'});
      return;
    }

    if (passwordData.new !== passwordData.confirm) {
      setStatus({type: 'error', msg: 'As novas senhas não coincidem.'});
      return;
    }

    accounts[accountIndex].password = passwordData.new;
    localStorage.setItem('legend_accounts', JSON.stringify(accounts));
    
    setStatus({type: 'success', msg: 'Senha alterada com sucesso!'});
    setPasswordData({current: '', new: '', confirm: ''});
    setTimeout(() => setStatus(null), 3000);
  };

  return (
    <div className="pt-32 pb-20 min-h-screen bg-slate-950 font-archivo">
      <div className="container mx-auto px-4 max-w-4xl">
        <button onClick={onBack} className="flex items-center gap-2 text-slate-500 hover:text-white mb-10 text-xs font-bold uppercase tracking-widest transition-colors">
          <ArrowLeft size={16} /> Voltar ao Início
        </button>

        <div className="flex flex-col md:flex-row gap-12">
          {/* Sidebar */}
          <div className="w-full md:w-64 space-y-4">
             <div className="p-8 bg-slate-900 rounded-[2rem] border border-white/5 text-center">
                <button
                  type="button"
                  onClick={() => setShowPhotoUpload(true)}
                  className="relative inline-block mb-4 group hover:scale-105 transition-transform"
                >
                  <div className="w-24 h-24 bg-slate-950 rounded-2xl overflow-hidden border-2 border-blue-500/30 flex items-center justify-center">
                    {formData.avatar ? <img src={formData.avatar} className="w-full h-full object-cover" /> : <User size={40} className="text-slate-700" />}
                  </div>
                  <div className="absolute inset-0 bg-blue-600/60 opacity-0 group-hover:opacity-100 flex items-center justify-center rounded-2xl transition-all cursor-pointer">
                    <Camera className="text-white" size={24} />
                  </div>
                </button>
                <h2 className="text-xl font-orbitron font-bold text-white uppercase italic">{user.name}</h2>
                <p className="text-[10px] text-blue-500 font-black uppercase tracking-widest mt-1">ID: {formData.userId}</p>
             </div>
             
             <div className="p-6 bg-slate-900/50 rounded-2xl border border-white/5 space-y-3">
               <p className="text-[10px] text-slate-600 font-black uppercase tracking-widest mb-4">Segurança</p>
               <div className="flex items-center gap-3 text-xs text-slate-400 font-bold">
                 <Shield size={14} className="text-green-500" /> Verificado
               </div>
               <div className="flex items-center gap-3 text-xs text-slate-400 font-bold">
                 <Lock size={14} className="text-blue-500" /> Protegido
               </div>
             </div>
          </div>

          {/* Forms */}
          <div className="flex-grow space-y-8">
            {status && (
              <div className={`p-4 rounded-xl flex items-center gap-3 animate-in slide-in-from-top-4 duration-300 ${status.type === 'success' ? 'bg-green-500/10 border border-green-500/30 text-green-500' : 'bg-red-500/10 border border-red-500/30 text-red-500'}`}>
                {status.type === 'success' ? <CheckCircle size={20} /> : <AlertCircle size={20} />}
                <p className="text-sm font-bold uppercase tracking-wide">{status.msg}</p>
              </div>
            )}

            {/* Profile Info Form */}
            <div className="bg-slate-900 border border-white/5 rounded-[2.5rem] p-8 md:p-10 shadow-2xl">
               <h3 className="text-2xl font-orbitron font-black text-white uppercase italic mb-8">Informações de <span className="text-blue-500">Perfil</span></h3>
               <form onSubmit={handleProfileUpdate} className="space-y-6">
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">E-mail</label>
                      <div className="relative">
                        <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600" size={16} />
                        <input type="email" value={formData.email} onChange={e => setFormData({...formData, email: e.target.value})} className="w-full bg-slate-950 border border-white/10 rounded-xl py-4 pl-12 pr-4 text-white focus:border-blue-500 outline-none text-sm" placeholder="seuemail@exemplo.com" />
                      </div>
                    </div>
                    <div>
                      <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Telefone</label>
                      <div className="relative">
                        <Phone className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600" size={16} />
                        <input type="text" value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} className="w-full bg-slate-950 border border-white/10 rounded-xl py-4 pl-12 pr-4 text-white focus:border-blue-500 outline-none text-sm" placeholder="(11) 99999-9999" />
                      </div>
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">URL da Foto de Perfil (Avatar)</label>
                      <div className="relative">
                        <Camera className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600" size={16} />
                        <input type="text" value={formData.avatar} onChange={e => setFormData({...formData, avatar: e.target.value})} className="w-full bg-slate-950 border border-white/10 rounded-xl py-4 pl-12 pr-4 text-white focus:border-blue-500 outline-none text-sm font-mono" placeholder="https://imagem.com/foto.jpg" />
                      </div>
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Biografia</label>
                      <div className="relative">
                        <FileText className="absolute left-4 top-4 text-slate-600" size={16} />
                        <textarea value={formData.bio} onChange={e => setFormData({...formData, bio: e.target.value})} maxLength={150} className="w-full bg-slate-950 border border-white/10 rounded-xl py-4 pl-12 pr-4 text-white focus:border-blue-500 outline-none text-sm resize-none h-24" placeholder="Conte um pouco sobre você... (máx 150 caracteres)" />
                        <p className="text-[10px] text-slate-500 mt-1">{formData.bio.length}/150 caracteres</p>
                      </div>
                    </div>
                 </div>
                 <button type="submit" className="bg-blue-600 hover:bg-blue-500 text-white font-black py-4 px-8 rounded-xl flex items-center gap-3 transition-all uppercase text-xs tracking-widest shadow-lg shadow-blue-600/20 active:scale-95">
                   <Save size={16} /> Salvar Alterações
                 </button>
               </form>
            </div>

            {/* Password Update Form */}
            <div className="bg-slate-900 border border-white/5 rounded-[2.5rem] p-8 md:p-10 shadow-2xl">
               <h3 className="text-2xl font-orbitron font-black text-white uppercase italic mb-8">Segurança & <span className="text-blue-500">Senha</span></h3>
               <form onSubmit={handlePasswordUpdate} className="space-y-6">
                 <div>
                    <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Senha Atual</label>
                    <div className="relative">
                      <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600" size={16} />
                      <input type="password" value={passwordData.current} onChange={e => setPasswordData({...passwordData, current: e.target.value})} className="w-full bg-slate-950 border border-white/10 rounded-xl py-4 pl-12 pr-4 text-white focus:border-blue-500 outline-none text-sm" placeholder="Sua senha atual" required />
                    </div>
                 </div>
                 <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Nova Senha</label>
                      <input type="password" value={passwordData.new} onChange={e => setPasswordData({...passwordData, new: e.target.value})} className="w-full bg-slate-950 border border-white/10 rounded-xl py-4 px-6 text-white focus:border-blue-500 outline-none text-sm" placeholder="Nova senha" required />
                    </div>
                    <div>
                      <label className="block text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">Confirmar Nova Senha</label>
                      <input type="password" value={passwordData.confirm} onChange={e => setPasswordData({...passwordData, confirm: e.target.value})} className="w-full bg-slate-950 border border-white/10 rounded-xl py-4 px-6 text-white focus:border-blue-500 outline-none text-sm" placeholder="Confirme a senha" required />
                    </div>
                 </div>
                 <button type="submit" className="bg-slate-800 hover:bg-slate-700 text-white font-black py-4 px-8 rounded-xl flex items-center gap-3 transition-all uppercase text-xs tracking-widest active:scale-95">
                   <Lock size={16} /> Atualizar Senha
                 </button>
               </form>
            </div>
          </div>
        </div>
      </div>
      {showPhotoUpload && (
        <ProfilePhotoUpload
          onClose={() => setShowPhotoUpload(false)}
          onUpload={handlePhotoUpload}
          currentPhoto={formData.avatar}
        />
      )}
    </div>
  );
};

export default AccountSettings;
