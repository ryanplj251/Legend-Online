
import React, { useState, useEffect } from 'react';
import { Search, ArrowLeft, User, Calendar, Shield, Trophy, Clock, MessageCircle } from 'lucide-react';
import { legendDB } from '../../lib/database';

interface Player {
  id: string;
  username: string;
  name: string;
  level?: number;
  faction?: string;
  joinDate?: string;
  lastSeen?: string;
  status: 'online' | 'offline' | 'away';
  avatar?: string;
  bio?: string;
  kills?: number;
  deaths?: number;
  reputation?: number;
}

interface PlayerSearchProps {
  onBack: () => void;
  currentUser?: any;
  onOpenChat?: (username: string) => void;
}

const PlayerSearch: React.FC<PlayerSearchProps> = ({ onBack, currentUser, onOpenChat }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState<Player[]>([]);
  const [selectedPlayer, setSelectedPlayer] = useState<Player | null>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [allPlayers, setAllPlayers] = useState<Player[]>([]);
  const [loading, setLoading] = useState(true);

  // Carregar todos os players do IndexedDB
  useEffect(() => {
    const loadPlayers = async () => {
      try {
        await legendDB.init();
        const accounts = await legendDB.getAllUsers();
        const localAccounts = JSON.parse(localStorage.getItem('legend_accounts') || '[]');
        
        const players: Player[] = accounts.map((acc) => {
          const lastSeen = localStorage.getItem(`legend_last_seen_${acc.username}`);
          const localAcc = localAccounts.find((la: any) => la.username === acc.username);
          return {
            id: acc.id,
            username: acc.username,
            name: acc.username,
            level: Math.floor(Math.random() * 100) + 1,
            faction: ['Mafia', 'Polícia', 'Civil'][Math.floor(Math.random() * 3)],
            joinDate: acc.createdAt ? new Date(acc.createdAt).toISOString() : new Date(Date.now() - Math.random() * 365 * 24 * 60 * 60 * 1000).toISOString(),
            lastSeen: lastSeen || new Date().toISOString(),
            status: Math.random() > 0.3 ? 'online' : (Math.random() > 0.5 ? 'away' : 'offline'),
            avatar: acc.avatar || localAcc?.avatar,
            bio: localAcc?.bio || acc.bio || '',
            kills: Math.floor(Math.random() * 500),
            deaths: Math.floor(Math.random() * 300),
            reputation: Math.floor(Math.random() * 1000)
          };
        });
        
        setAllPlayers(players);
        setLoading(false);
      } catch (error) {
        console.error('Erro ao carregar players:', error);
        setLoading(false);
      }
    };
    
    loadPlayers();
    // Recarregar players a cada 1 segundo para sincronizar mudancas
    const interval = setInterval(loadPlayers, 1000);
    return () => clearInterval(interval);
  }, []);

  // Buscar players
  useEffect(() => {
    if (searchTerm.trim().length < 2) {
      setSearchResults([]);
      setSelectedPlayer(null);
      return;
    }

    setIsSearching(true);
    
    const timer = setTimeout(() => {
      const results = allPlayers.filter(player =>
        player.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
        player.name.toLowerCase().includes(searchTerm.toLowerCase())
      );
      setSearchResults(results);
      setIsSearching(false);
    }, 300);

    return () => clearTimeout(timer);
  }, [searchTerm, allPlayers]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online':
        return 'bg-green-500';
      case 'away':
        return 'bg-yellow-500';
      default:
        return 'bg-slate-500';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'online':
        return 'Online';
      case 'away':
        return 'Ausente';
      default:
        return 'Offline';
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: '2-digit' });
  };

  const formatLastSeen = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return 'Agora mesmo';
    if (minutes < 60) return `${minutes}m atrás`;
    if (hours < 24) return `${hours}h atrás`;
    if (days < 7) return `${days}d atrás`;
    
    return date.toLocaleDateString('pt-BR', { day: '2-digit', month: '2-digit', year: '2-digit' });
  };

  const getFactionColor = (faction: string) => {
    switch (faction) {
      case 'Mafia':
        return 'text-red-500';
      case 'Polícia':
        return 'text-blue-500';
      default:
        return 'text-slate-500';
    }
  };

  return (
    <div className="pt-24 min-h-screen bg-slate-950 flex flex-col font-archivo">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600/20 to-purple-600/20 border-b border-blue-500/30 px-4 md:px-8 py-6">
        <button onClick={onBack} className="flex items-center gap-2 text-slate-500 hover:text-white mb-6 text-xs font-bold uppercase">
          <ArrowLeft size={14} /> Voltar
        </button>
        <h1 className="text-3xl md:text-4xl font-orbitron font-black text-white uppercase tracking-tighter italic">Buscar <span className="text-blue-500">Players</span></h1>
        <p className="text-slate-500 font-bold uppercase tracking-widest text-[10px] mt-3">Encontre e visualize perfis de jogadores</p>
      </div>

      {/* Search Bar */}
      <div className="p-4 md:p-8 border-b border-slate-700/50">
        <div className="max-w-4xl mx-auto relative">
          <Search className="absolute left-4 top-4 text-slate-500" size={20} />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Digite o nome ou username do player..."
            className="w-full bg-slate-900 border border-blue-500/30 rounded-xl pl-12 pr-4 py-4 text-white focus:border-blue-500 outline-none transition-colors text-base md:text-lg"
            autoFocus
          />
        </div>
        <p className="text-xs text-slate-500 mt-3 max-w-4xl mx-auto">Digite pelo menos 2 caracteres para buscar</p>
      </div>

      {/* Main Content - Responsivo */}
      <div className="flex-1 flex flex-col md:flex-row gap-4 md:gap-8 p-4 md:p-8 max-w-7xl mx-auto w-full">
        
        {/* Results List */}
        <div className={`w-full ${selectedPlayer ? 'md:flex-1' : 'md:flex-1'} space-y-3`}>
          {loading ? (
            <div className="text-center p-12 bg-slate-900/50 rounded-xl border border-slate-700/50">
              <div className="inline-block animate-spin">
                <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full" />
              </div>
              <p className="text-slate-400 font-bold uppercase text-sm mt-4">Carregando players...</p>
            </div>
          ) : searchTerm.trim().length < 2 ? (
            <div className="text-center p-12 bg-slate-900/50 rounded-xl border border-slate-700/50">
              <Search className="mx-auto text-slate-600 mb-4" size={48} />
              <p className="text-slate-400 font-bold uppercase text-sm">Digite para buscar players</p>
            </div>
          ) : isSearching ? (
            <div className="text-center p-12 bg-slate-900/50 rounded-xl border border-slate-700/50">
              <div className="inline-block animate-spin">
                <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full" />
              </div>
              <p className="text-slate-400 font-bold uppercase text-sm mt-4">Buscando...</p>
            </div>
          ) : searchResults.length === 0 ? (
            <div className="text-center p-12 bg-slate-900/50 rounded-xl border border-slate-700/50">
              <User className="mx-auto text-slate-600 mb-4" size={48} />
              <p className="text-slate-400 font-bold uppercase text-sm">Nenhum player encontrado</p>
            </div>
          ) : (
            searchResults.map((player) => (
              <button
                key={player.id}
                onClick={() => setSelectedPlayer(player)}
                className={`w-full text-left p-4 rounded-xl border transition-all ${
                  selectedPlayer?.id === player.id
                    ? 'bg-blue-600/20 border-blue-500/50'
                    : 'bg-slate-900/50 border-slate-700/50 hover:border-blue-500/30'
                }`}
              >
                <div className="flex items-center gap-4">
                  <div className="relative flex-shrink-0">
                    <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-600 to-purple-600 flex items-center justify-center text-sm font-bold text-white">
                      {player.username.charAt(0).toUpperCase()}
                    </div>
                    <div className={`absolute bottom-0 right-0 w-3 h-3 rounded-full border-2 border-slate-950 ${getStatusColor(player.status)}`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-bold text-white truncate">{player.username}</p>
                    <p className={`text-xs font-bold uppercase tracking-widest ${getFactionColor(player.faction)}`}>{player.faction}</p>
                  </div>
                  <div className="text-right flex-shrink-0">
                    <p className="text-xs text-slate-400">Nível {player.level}</p>
                    <p className="text-xs text-slate-500">{getStatusLabel(player.status)}</p>
                  </div>
                </div>
              </button>
            ))
          )}
        </div>

        {/* Player Profile - Responsivo */}
        {selectedPlayer && (
          <div className="w-full md:w-96 flex-shrink-0">
            {/* Profile Card */}
            <div className="bg-gradient-to-b from-slate-900 to-slate-950 border border-blue-500/30 rounded-xl overflow-hidden shadow-2xl">
              {/* Header Background */}
              <div className="h-24 bg-gradient-to-r from-blue-600/20 to-purple-600/20" />
              
              {/* Avatar */}
              <div className="px-6 pb-6">
                <div className="flex flex-col items-center -mt-16 mb-4">
                  <div className="relative">
                    <div className="w-24 h-24 rounded-full bg-gradient-to-br from-blue-600 to-purple-600 flex items-center justify-center text-2xl font-bold text-white border-4 border-slate-950">
                      {selectedPlayer.username.charAt(0).toUpperCase()}
                    </div>
                    <div className={`absolute bottom-0 right-0 w-4 h-4 rounded-full border-2 border-slate-950 ${getStatusColor(selectedPlayer.status)}`} />
                  </div>
                </div>

                {/* Basic Info */}
                <div className="text-center mb-6">
                  <h2 className="text-2xl font-orbitron font-bold text-white mb-1">{selectedPlayer.username}</h2>
                  <p className={`text-sm font-bold uppercase tracking-widest mb-2 ${getFactionColor(selectedPlayer.faction)}`}>
                    {selectedPlayer.faction}
                  </p>
                  <p className="text-xs text-slate-400">{getStatusLabel(selectedPlayer.status)}</p>
                </div>

                {/* Stats Grid */}
                <div className="grid grid-cols-2 gap-3 mb-6">
                  <div className="bg-slate-800/50 rounded-lg p-3 border border-slate-700/50">
                    <p className="text-xs text-slate-500 uppercase font-bold">Nível</p>
                    <p className="text-2xl font-orbitron font-bold text-blue-400">{selectedPlayer.level}</p>
                  </div>
                  <div className="bg-slate-800/50 rounded-lg p-3 border border-slate-700/50">
                    <p className="text-xs text-slate-500 uppercase font-bold">Reputação</p>
                    <p className="text-2xl font-orbitron font-bold text-purple-400">{selectedPlayer.reputation}</p>
                  </div>
                  <div className="bg-slate-800/50 rounded-lg p-3 border border-slate-700/50">
                    <p className="text-xs text-slate-500 uppercase font-bold">Kills</p>
                    <p className="text-2xl font-orbitron font-bold text-red-400">{selectedPlayer.kills}</p>
                  </div>
                  <div className="bg-slate-800/50 rounded-lg p-3 border border-slate-700/50">
                    <p className="text-xs text-slate-500 uppercase font-bold">Deaths</p>
                    <p className="text-2xl font-orbitron font-bold text-slate-400">{selectedPlayer.deaths}</p>
                  </div>
                </div>

                {/* Bio */}
                {selectedPlayer.bio && (
                  <div className="bg-slate-800/50 rounded-lg p-3 border border-slate-700/50 mb-6">
                    <p className="text-xs text-slate-500 uppercase font-bold mb-2">Biografia</p>
                    <p className="text-sm text-slate-300">{selectedPlayer.bio}</p>
                  </div>
                )}
                {!selectedPlayer.bio && (
                  <div className="bg-slate-800/50 rounded-lg p-3 border border-slate-700/50 mb-6">
                    <p className="text-xs text-slate-500 uppercase font-bold mb-2">Biografia</p>
                    <p className="text-sm text-slate-400 italic">Sem biografia</p>
                  </div>
                )}

                {/* Additional Info */}
                <div className="space-y-2 mb-6">
                  <div className="flex items-center gap-2 text-xs text-slate-400">
                    <Calendar size={14} />
                    <span>Entrou em: {formatDate(selectedPlayer.joinDate || '')}</span>
                  </div>
                  <div className="flex items-center gap-2 text-xs text-slate-400">
                    <Clock size={14} />
                    <span>Visto: {formatLastSeen(selectedPlayer.lastSeen || '')}</span>
                  </div>
                </div>

                {/* Actions */}
                {currentUser && onOpenChat && selectedPlayer.username !== currentUser.username && (
                  <button
                    onClick={() => onOpenChat(selectedPlayer.username)}
                    className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-bold transition-all flex items-center justify-center gap-2 uppercase text-xs tracking-widest"
                  >
                    <MessageCircle size={16} />
                    Enviar Mensagem
                  </button>
                )}

                {/* Botão para fechar no mobile */}
                <button
                  onClick={() => setSelectedPlayer(null)}
                  className="md:hidden w-full mt-4 bg-slate-800 hover:bg-slate-700 text-white py-2 rounded-lg font-bold transition-all uppercase text-xs tracking-widest"
                >
                  Fechar Perfil
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PlayerSearch;
