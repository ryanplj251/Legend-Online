
import React, { useState, useEffect } from 'react';
import { Code2, Save, RotateCcw, Eye, EyeOff, Copy, Check, AlertTriangle, Lock, History } from 'lucide-react';

interface CodeVersion {
  id: string;
  timestamp: Date;
  author: string;
  content: string;
  description: string;
}

interface CodeEditorProps {
  user: any;
  onClose: () => void;
}

const CodeEditor: React.FC<CodeEditorProps> = ({ user, onClose }) => {
  const [code, setCode] = useState('');
  const [preview, setPreview] = useState(false);
  const [versions, setVersions] = useState<CodeVersion[]>([]);
  const [selectedVersion, setSelectedVersion] = useState<string | null>(null);
  const [description, setDescription] = useState('');
  const [isSaving, setIsSaving] = useState(false);
  const [saveSuccess, setSaveSuccess] = useState(false);
  const [showVersionHistory, setShowVersionHistory] = useState(false);
  const [copied, setCopied] = useState(false);
  const [warning, setWarning] = useState('');

  // Carregar código salvo do localStorage
  useEffect(() => {
    const savedCode = localStorage.getItem('legend_code_editor');
    const savedVersions = localStorage.getItem('legend_code_versions');
    
    if (savedCode) setCode(JSON.parse(savedCode));
    if (savedVersions) setVersions(JSON.parse(savedVersions));
  }, []);

  // Validação de segurança
  const validateCode = (content: string): boolean => {
    const dangerousPatterns = [
      /eval\s*\(/gi,
      /exec\s*\(/gi,
      /Function\s*\(/gi,
      /<script/gi,
      /onclick=/gi,
      /onerror=/gi,
    ];

    for (const pattern of dangerousPatterns) {
      if (pattern.test(content)) {
        setWarning('⚠️ Código contém padrões perigosos detectados!');
        return false;
      }
    }
    setWarning('');
    return true;
  };

  const handleSave = async () => {
    if (!validateCode(code)) return;

    setIsSaving(true);
    
    try {
      // Criar nova versão
      const newVersion: CodeVersion = {
        id: `v_${Date.now()}`,
        timestamp: new Date(),
        author: user.username,
        content: code,
        description: description || 'Sem descrição'
      };

      const updatedVersions = [newVersion, ...versions];
      setVersions(updatedVersions);

      // Salvar no localStorage
      localStorage.setItem('legend_code_editor', JSON.stringify(code));
      localStorage.setItem('legend_code_versions', JSON.stringify(updatedVersions));

      // Log de auditoria
      const auditLog = {
        timestamp: new Date(),
        user: user.username,
        action: 'code_edited',
        description: description,
        ipAddress: 'local'
      };
      
      const logs = JSON.parse(localStorage.getItem('legend_audit_logs') || '[]');
      logs.push(auditLog);
      localStorage.setItem('legend_audit_logs', JSON.stringify(logs.slice(-100)));

      setSaveSuccess(true);
      setDescription('');
      setTimeout(() => setSaveSuccess(false), 3000);
    } catch (err) {
      console.error('Erro ao salvar:', err);
    } finally {
      setIsSaving(false);
    }
  };

  const handleRestore = (versionId: string) => {
    const version = versions.find(v => v.id === versionId);
    if (version) {
      setCode(version.content);
      setSelectedVersion(versionId);
      setShowVersionHistory(false);
    }
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="bg-gradient-to-b from-slate-900 to-slate-950 border border-blue-500/30 rounded-2xl w-full max-w-6xl max-h-[90vh] overflow-hidden flex flex-col shadow-2xl">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600/20 to-purple-600/20 border-b border-blue-500/30 px-8 py-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Code2 className="text-blue-500" size={28} />
            <div>
              <h2 className="text-2xl font-orbitron font-bold text-white">Editor de Código</h2>
              <p className="text-xs text-slate-400 mt-1">🔒 Acesso restrito - Apenas Ruan_LGD e Pereira_LGD</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-slate-400 hover:text-white transition-colors p-2 hover:bg-white/10 rounded-lg"
          >
            ✕
          </button>
        </div>

        {/* Security Warning */}
        {warning && (
          <div className="bg-red-500/10 border-b border-red-500/30 px-8 py-4 flex items-center gap-3">
            <AlertTriangle className="text-red-500 flex-shrink-0" size={20} />
            <p className="text-sm text-red-400">{warning}</p>
          </div>
        )}

        {/* Success Message */}
        {saveSuccess && (
          <div className="bg-green-500/10 border-b border-green-500/30 px-8 py-4 flex items-center gap-3">
            <Check className="text-green-500 flex-shrink-0" size={20} />
            <p className="text-sm text-green-400">✅ Código salvo com sucesso! Versão registrada no histórico.</p>
          </div>
        )}

        {/* Main Content */}
        <div className="flex-1 flex gap-6 overflow-hidden p-8">
          
          {/* Editor */}
          <div className="flex-1 flex flex-col gap-4">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Código-Fonte</label>
              <button
                onClick={handleCopy}
                className="flex items-center gap-2 px-3 py-1 text-xs bg-slate-800 hover:bg-slate-700 rounded text-slate-300 transition-colors"
              >
                {copied ? <Check size={14} /> : <Copy size={14} />}
                {copied ? 'Copiado!' : 'Copiar'}
              </button>
            </div>
            
            <textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="flex-1 bg-slate-950 border border-blue-500/20 rounded-lg p-4 text-slate-100 font-mono text-sm resize-none focus:border-blue-500 outline-none transition-colors"
              placeholder="Cole seu código aqui..."
              spellCheck="false"
            />
          </div>

          {/* Sidebar */}
          <div className="w-64 flex flex-col gap-4">
            
            {/* Description */}
            <div className="flex flex-col gap-2">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest">Descrição da Alteração</label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Ex: Corrigir bug de login"
                className="bg-slate-950 border border-blue-500/20 rounded-lg px-4 py-2 text-sm text-slate-100 focus:border-blue-500 outline-none transition-colors"
              />
            </div>

            {/* Buttons */}
            <div className="flex flex-col gap-2">
              <button
                onClick={handleSave}
                disabled={isSaving || !code.trim()}
                className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-500 hover:to-blue-600 disabled:opacity-50 text-white font-bold rounded-lg transition-all uppercase text-xs tracking-widest"
              >
                <Save size={16} />
                {isSaving ? 'Salvando...' : 'Salvar Versão'}
              </button>

              <button
                onClick={() => setShowVersionHistory(!showVersionHistory)}
                className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-lg transition-all uppercase text-xs tracking-widest"
              >
                <History size={16} />
                Histórico ({versions.length})
              </button>

              <button
                onClick={() => setCode('')}
                className="w-full flex items-center justify-center gap-2 px-4 py-3 bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold rounded-lg transition-all uppercase text-xs tracking-widest"
              >
                <RotateCcw size={16} />
                Limpar
              </button>
            </div>

            {/* Security Info */}
            <div className="bg-blue-500/10 border border-blue-500/30 rounded-lg p-4">
              <div className="flex items-center gap-2 mb-3">
                <Lock className="text-blue-500" size={16} />
                <p className="text-xs font-bold text-blue-400 uppercase">Segurança</p>
              </div>
              <ul className="text-xs text-slate-400 space-y-1">
                <li>✓ Validação de código</li>
                <li>✓ Histórico completo</li>
                <li>✓ Auditoria registrada</li>
                <li>✓ Rollback disponível</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Version History */}
        {showVersionHistory && (
          <div className="border-t border-blue-500/30 bg-slate-950/50 max-h-48 overflow-y-auto">
            <div className="p-6">
              <h3 className="text-sm font-bold text-white mb-4 uppercase tracking-widest">Histórico de Versões</h3>
              <div className="space-y-2">
                {versions.length === 0 ? (
                  <p className="text-xs text-slate-500">Nenhuma versão salva ainda</p>
                ) : (
                  versions.map((version) => (
                    <button
                      key={version.id}
                      onClick={() => handleRestore(version.id)}
                      className={`w-full text-left p-3 rounded-lg transition-all text-xs ${
                        selectedVersion === version.id
                          ? 'bg-blue-600/20 border border-blue-500/50'
                          : 'bg-slate-900 hover:bg-slate-800 border border-slate-700'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <div>
                          <p className="font-bold text-slate-200">{version.description}</p>
                          <p className="text-slate-500 mt-1">Por: {version.author}</p>
                        </div>
                        <p className="text-slate-400">{new Date(version.timestamp).toLocaleString('pt-BR')}</p>
                      </div>
                    </button>
                  ))
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CodeEditor;
