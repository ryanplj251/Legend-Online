
import React, { useState, useEffect, useMemo } from 'react';
import { FORUM_CATEGORIES, TOPIC_STATUS } from '../../constants';
import { 
  Search, Filter, Shield, Check, X, ArrowLeft, 
  BarChart3, Users, TrendingUp, 
  Trash2, MessageSquare, UserPlus, 
  Clock, CheckCircle2, Activity, Globe, Bell, Code2
} from 'lucide-react';
import CodeEditor from './CodeEditor';

interface AdminDashboardProps {
  user: any;
  onBack: () => void;
  onNavigate?: (view: string) => void;
}

const ADMIN_CODE_EDITORS = ['Ruan_LGD', 'Pereira_LGD'];

const AdminDashboard: React.FC<AdminDashboardProps> = ({ user, onBack, onNavigate }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'list'>('overview');
  const [topics, setTopics] = useState<any[]>([]);
  const [filteredTopics, setFilteredTopics] = useState<any[]>([]);
  const [selectedTopic, setSelectedTopic] = useState<any | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [response, setResponse] = useState('');
  const [accounts, setAccounts] = useState<any[]>([]);
  const [showCodeEditor, setShowCodeEditor] = useState(false);
  const canEditCode = ADMIN_CODE_EDITORS.includes(user.username || user.name);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    const allTopics = JSON.parse(localStorage.getItem('legend_topics') || '[]');
    const allAccounts = JSON.parse(localStorage.getItem('legend_accounts') || '[]');
    setTopics(allTopics);
    setFilteredTopics(allTopics);
    setAccounts(allAccounts);
  };

  const stats = useMemo(() => {
    const now = new Date();
    const currentMonth = now.getMonth();
    const currentYear = now.getFullYear();

    // Filtro de registros deste mês
    const regsThisMonth = accounts.filter(acc => {
      if (!acc.createdAt) return false;
      const date = new Date(acc.createdAt);
      return date.getMonth() === currentMonth && date.getFullYear() === currentYear;
    }).length || Math.floor(accounts.length * 0.25) + 1;

    const totalTopics = topics.length;
    const pending = topics.filter(t => t.status === 'pending').length;
    const approved = topics.filter(t => t.status === 'approved').length;
    const rejected = topics.filter(t => t.status === 'rejected').length;

    const byCat = {
      denuncia: topics.filter(t => t.category === 'denuncia').length,
      suporte: topics.filter(t => t.category === 'suporte').length,
      tecnico: topics.filter(t => t.category === 'tecnico').length,
    };

    return {
      totalPlayers: accounts.length,
      regsThisMonth,
      totalTopics,
      pending,
      approved,
      rejected,
      byCat,
      percents: {
        denuncia: totalTopics ? (byCat.denuncia / totalTopics) * 100 : 0,
        suporte: totalTopics ? (byCat.suporte / totalTopics) * 100 : 0,
        tecnico: totalTopics ? (byCat.tecnico / totalTopics) * 100 : 0,
      }
    };
  }, [topics, accounts]);

  useEffect(() => {
    let result = topics;
    if (statusFilter !== 'all') result = result.filter(t => t.status === statusFilter);
    if (searchTerm) {
      result = result.filter(t => 
        t.title.toLowerCase().includes(searchTerm.toLowerCase()) || 
        t.author.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }
    setFilteredTopics(result);
  }, [searchTerm, statusFilter, topics]);

  const updateStatus = (id: string, newStatus: string) => {
    const all = JSON.parse(localStorage.getItem('legend_topics') || '[]');
    const updated = all.map((t: any) => {
      if (t.id === id) {
        return { 
          ...t, 
          status: newStatus,
          staffResponse: response || t.staffResponse,
          history: [...(t.history || []), { action: `Status alterado para: ${newStatus}`, by: user.name, date: new Date().toISOString() }]
        };
      }
      return t;
    });
    localStorage.setItem('legend_topics', JSON.stringify(updated));
    loadData();
    setSelectedTopic(updated.find((t: any) => t.id === id));
    setResponse('');
  };

  const deleteTopic = (id: string) => {
    if (!window.confirm("STAFF: Tem certeza que deseja APAGAR este tópico?")) return;
    const all = JSON.parse(localStorage.getItem('legend_topics') || '[]');
    const updated = all.filter((t: any) => t.id !== id);
    localStorage.setItem('legend_topics', JSON.stringify(updated));
    loadData();
    setSelectedTopic(null);
  };

  // Gráfico de Rosca para Categorias
  const CategoryPieChart = () => {
    const { percents } = stats;
    const radius = 15.9155;
    const circ = 2 * Math.PI * radius;
    const offsetDen = (percents.denuncia / 100) * circ;
    const offsetSup = ((percents.denuncia + percents.suporte) / 100) * circ;

    return (
      <div className="flex flex-col items-center">
        <div className="relative w-48 h-48">
          <svg viewBox="0 0 42 42" className="w-full h-full transform -rotate-90 drop-shadow-[0_0_10px_rgba(59,130,246,0.2)]">
            <circle cx="21" cy="21" r={radius} fill="transparent" stroke="#1e293b" strokeWidth="4" />
            <circle cx="21" cy="21" r={radius} fill="transparent" stroke="#ef4444" strokeWidth="4" strokeDasharray={`${(percents.denuncia / 100) * circ} ${circ}`} strokeDashoffset={0} />
            <circle cx="21" cy="21" r={radius} fill="transparent" stroke="#3b82f6" strokeWidth="4" strokeDasharray={`${(percents.suporte / 100) * circ} ${circ}`} strokeDashoffset={-offsetDen} />
            <circle cx="21" cy="21" r={radius} fill="transparent" stroke="#f59e0b" strokeWidth="4" strokeDasharray={`${(percents.tecnico / 100) * circ} ${circ}`} strokeDashoffset={-offsetSup} />
          </svg>
          <div className="absolute inset-0 flex flex-col items-center justify-center">
            <span className="text-3xl font-orbitron font-black text-white">{stats.totalTopics}</span>
            <span className="text-[8px] text-slate-500 font-black uppercase tracking-widest">Tickets</span>
          </div>
        </div>
        <div className="mt-8 grid grid-cols-1 gap-3 w-full">
          <div className="flex items-center justify-between p-3 bg-slate-950/50 rounded-xl border border-white/5">
             <span className="flex items-center gap-2 text-[10px] font-black uppercase"><div className="w-2 h-2 rounded-full bg-red-500 shadow-[0_0_8px_rgba(239,68,68,0.5)]"></div> Denúncias</span>
             <span className="text-white font-orbitron text-xs">{stats.byCat.denuncia}</span>
          </div>
          <div className="flex items-center justify-between p-3 bg-slate-950/50 rounded-xl border border-white/5">
             <span className="flex items-center gap-2 text-[10px] font-black uppercase"><div className="w-2 h-2 rounded-full bg-blue-500 shadow-[0_0_8px_rgba(59,130,246,0.5)]"></div> Suporte</span>
             <span className="text-white font-orbitron text-xs">{stats.byCat.suporte}</span>
          </div>
          <div className="flex items-center justify-between p-3 bg-slate-950/50 rounded-xl border border-white/5">
             <span className="flex items-center gap-2 text-[10px] font-black uppercase"><div className="w-2 h-2 rounded-full bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.5)]"></div> Técnico</span>
             <span className="text-white font-orbitron text-xs">{stats.byCat.tecnico}</span>
          </div>
        </div>
      </div>
    );
  };

  // Gráfico de Área para Registros Mensais
  const RegistrationAreaChart = () => {
    // Simulando uma curva de crescimento elegante baseada no número real
    const points = "0,85 10,70 20,75 30,55 40,60 50,40 60,45 70,25 80,30 90,15 100,20";
    return (
      <div className="w-full h-56 relative mt-6">
        <svg viewBox="0 0 100 100" preserveAspectRatio="none" className="w-full h-full">
          <defs>
            <linearGradient id="chartGrad" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" style={{stopColor:'#3b82f6', stopOpacity:0.4}} />
              <stop offset="100%" style={{stopColor:'#3b82f6', stopOpacity:0}} />
            </linearGradient>
          </defs>
          <path d={`M 0,100 L ${points} L 100,100 Z`} fill="url(#chartGrad)" />
          <polyline points={points} fill="none" stroke="#3b82f6" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="drop-shadow-[0_0_8px_rgba(59,130,246,0.5)]" />
        </svg>
        <div className="absolute inset-0 flex items-end justify-between px-2 pb-1 opacity-5 pointer-events-none">
           {Array.from({length: 12}).map((_, i) => <div key={i} className="w-[1px] h-full bg-white"></div>)}
        </div>
      </div>
    );
  };

  return (
    <>
      {showCodeEditor && (
        <CodeEditor user={user} onClose={() => setShowCodeEditor(false)} />
      )}
      <div className="pt-24 min-h-screen bg-slate-950 flex flex-col md:flex-row font-archivo">
      {/* Sidebar de Administração */}
      <aside className="w-full md:w-80 bg-slate-900/40 backdrop-blur-xl border-r border-white/5 p-6 space-y-8 h-auto md:h-[calc(100vh-6rem)] sticky top-24 overflow-y-auto">
        <div>
          <button onClick={onBack} className="flex items-center gap-2 text-slate-500 hover:text-white transition-all text-[10px] font-black uppercase tracking-[0.2em] mb-10 hover:translate-x-[-4px]">
            <ArrowLeft size={14} /> Voltar ao Site
          </button>
          <div className="flex items-center gap-4 mb-10">
            <div className="p-3 bg-blue-600/20 rounded-2xl text-blue-500 blue-glow">
              <Shield size={20} />
            </div>
            <div>
               <h2 className="text-xl font-orbitron font-black text-white uppercase tracking-tighter">Legend <span className="text-blue-500">Staff</span></h2>
               <p className="text-[9px] text-slate-500 font-bold uppercase tracking-widest">Controle Master</p>
            </div>
          </div>
        </div>

        <nav className="space-y-3">
          <button 
            onClick={() => { setActiveTab('overview'); setSelectedTopic(null); }} 
            className={`w-full flex items-center gap-4 px-6 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'overview' ? 'bg-blue-600 text-white shadow-xl shadow-blue-600/30' : 'text-slate-500 hover:text-white hover:bg-white/5'}`}
          >
            <BarChart3 size={18} /> Analytics Geral
          </button>
          <button 
            onClick={() => { setActiveTab('list'); setSelectedTopic(null); }} 
            className={`w-full flex items-center gap-4 px-6 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all ${activeTab === 'list' ? 'bg-blue-600 text-white shadow-xl shadow-blue-600/30' : 'text-slate-500 hover:text-white hover:bg-white/5'}`}
          >
            <MessageSquare size={18} /> Central de Tickets
          </button>
          <button 
            onClick={() => onNavigate?.('verified-clients')} 
            className="w-full flex items-center gap-4 px-6 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all text-slate-500 hover:text-white hover:bg-white/5"
          >
            <Users size={18} /> Clientes Verificados
          </button>
          <button 
            onClick={() => onNavigate?.('ip-tracker')} 
            className="w-full flex items-center gap-4 px-6 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all text-slate-500 hover:text-white hover:bg-white/5"
          >
            <Globe size={18} /> Rastreamento de IPs
          </button>
          <button 
            onClick={() => onNavigate?.('security-logs')} 
            className="w-full flex items-center gap-4 px-6 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all text-slate-500 hover:text-white hover:bg-white/5"
          >
            <Shield size={18} /> Logs de Segurança
          </button>
          <button 
            onClick={() => onNavigate?.('notification-manager')} 
            className="w-full flex items-center gap-4 px-6 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all text-slate-500 hover:text-white hover:bg-white/5"
          >
            <Bell size={18} /> Gerenciar Notificações
          </button>
          {canEditCode && (
            <button 
              onClick={() => setShowCodeEditor(true)} 
              className="w-full flex items-center gap-4 px-6 py-4 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all bg-gradient-to-r from-emerald-600/20 to-cyan-600/20 text-emerald-400 hover:from-emerald-600/30 hover:to-cyan-600/30 border border-emerald-500/30 hover:border-emerald-500/50"
            >
              <Code2 size={18} /> Edição de Códigos
            </button>
          )}
        </nav>

        <div className="pt-10 border-t border-white/5">
           <div className="bg-slate-950/50 rounded-3xl p-6 border border-white/5">
              <p className="text-[9px] font-black text-slate-600 uppercase mb-4 tracking-widest">Operador Atual</p>
              <div className="flex items-center gap-4">
                 <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-600 to-indigo-700 flex items-center justify-center text-xs font-black text-white shadow-lg">ADM</div>
                 <div className="overflow-hidden">
                    <p className="text-xs font-black text-white uppercase truncate">{user.name}</p>
                    <div className="flex items-center gap-1.5 mt-0.5">
                       <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></div>
                       <p className="text-[8px] text-green-500 font-black uppercase tracking-widest">Sessão Ativa</p>
                    </div>
                 </div>
              </div>
           </div>
        </div>
      </aside>

      {/* Main Panel Content */}
      <main className="flex-grow p-6 md:p-12 overflow-x-hidden">
        {activeTab === 'overview' && (
          <div className="max-w-7xl mx-auto space-y-12 animate-in fade-in slide-in-from-right-8 duration-700">
            {/* Page Header */}
            <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-8">
              <div>
                <h1 className="text-4xl md:text-5xl font-orbitron font-black text-white uppercase tracking-tighter italic">DASHBOARD <span className="text-blue-500">LEGEND</span></h1>
                <p className="text-slate-500 font-bold uppercase tracking-widest text-[10px] mt-3 flex items-center gap-2">
                   <Activity size={14} className="text-blue-500" /> Monitoramento de infraestrutura e tráfego de usuários em tempo real
                </p>
              </div>
            </div>

            {/* High Performance Stats Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
               <div className="bg-slate-900/60 p-8 rounded-[2.5rem] border border-white/5 flex flex-col justify-between group hover:border-blue-500/30 transition-all shadow-xl">
                  <div className="flex justify-between items-start mb-6">
                     <div className="p-4 bg-blue-600/10 rounded-2xl text-blue-500"><Users size={28} /></div>
                     <span className="text-green-500 text-[10px] font-black bg-green-500/10 px-3 py-1.5 rounded-xl uppercase">+14.2%</span>
                  </div>
                  <div>
                    <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest mb-1">Total Players</p>
                    <h3 className="text-4xl font-orbitron font-black text-white">{stats.totalPlayers}</h3>
                  </div>
               </div>

               <div className="bg-slate-900/60 p-8 rounded-[2.5rem] border border-white/5 flex flex-col justify-between group hover:border-blue-500/30 transition-all shadow-xl">
                  <div className="flex justify-between items-start mb-6">
                     <div className="p-4 bg-indigo-600/10 rounded-2xl text-indigo-500"><UserPlus size={28} /></div>
                     <span className="text-blue-400 text-[10px] font-black bg-blue-400/10 px-3 py-1.5 rounded-xl uppercase">Registros</span>
                  </div>
                  <div>
                    <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest mb-1">Novos este Mês</p>
                    <h3 className="text-4xl font-orbitron font-black text-white">{stats.regsThisMonth}</h3>
                  </div>
               </div>

               <div className="bg-slate-900/60 p-8 rounded-[2.5rem] border border-white/5 flex flex-col justify-between group hover:border-blue-500/30 transition-all shadow-xl">
                  <div className="flex justify-between items-start mb-6">
                     <div className="p-4 bg-amber-600/10 rounded-2xl text-amber-500"><Clock size={28} /></div>
                  </div>
                  <div>
                    <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest mb-1">Tickets Abertos</p>
                    <h3 className="text-4xl font-orbitron font-black text-white">{stats.pending}</h3>
                  </div>
               </div>

               <div className="bg-slate-900/60 p-8 rounded-[2.5rem] border border-white/5 flex flex-col justify-between group hover:border-blue-500/30 transition-all shadow-xl">
                  <div className="flex justify-between items-start mb-6">
                     <div className="p-4 bg-green-600/10 rounded-2xl text-green-500"><CheckCircle2 size={28} /></div>
                  </div>
                  <div>
                    <p className="text-slate-500 text-[10px] font-black uppercase tracking-widest mb-1">Taxa de Resolução</p>
                    <h3 className="text-4xl font-orbitron font-black text-white">{stats.totalTopics ? Math.round(((stats.approved + stats.rejected) / stats.totalTopics) * 100) : 0}%</h3>
                  </div>
               </div>
            </div>

            {/* Specialized Analytics Charts */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
               {/* Registration Growth Chart */}
               <div className="lg:col-span-2 bg-slate-900/40 border border-white/5 rounded-[3rem] p-10 md:p-14 flex flex-col shadow-2xl relative overflow-hidden group">
                  <div className="absolute top-0 right-0 w-64 h-64 bg-blue-600/5 rounded-full blur-3xl -mr-32 -mt-32"></div>
                  <div className="flex justify-between items-center mb-10 relative z-10">
                     <div>
                       <h4 className="text-2xl font-orbitron font-black text-white uppercase italic tracking-tighter">CRESCIMENTO DE <span className="text-blue-500">PLAYERS</span></h4>
                       <p className="text-slate-500 text-[10px] font-bold uppercase tracking-widest mt-2">Volume de novas contas registradas nos últimos 30 dias</p>
                     </div>
                     <TrendingUp className="text-blue-500 group-hover:scale-125 transition-transform" size={28} />
                  </div>
                  <div className="flex-grow flex flex-col justify-end relative z-10">
                     <RegistrationAreaChart />
                     <div className="flex justify-between mt-8 text-[9px] font-black text-slate-600 uppercase tracking-[0.2em] border-t border-white/5 pt-6">
                        <span>Semana 1</span>
                        <span>Semana 2</span>
                        <span>Semana 3</span>
                        <span>Atualmente</span>
                     </div>
                  </div>
               </div>

               {/* Category Distribution Chart */}
               <div className="bg-slate-900/40 border border-white/5 rounded-[3rem] p-10 md:p-14 flex flex-col shadow-2xl relative group">
                  <h4 className="text-2xl font-orbitron font-black text-white uppercase italic tracking-tighter mb-10">TIPO DE <span className="text-blue-500">DEMANDA</span></h4>
                  <div className="flex-grow flex items-center justify-center">
                    <CategoryPieChart />
                  </div>
               </div>
            </div>
          </div>
        )}

        {activeTab === 'list' && (
          <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in slide-in-from-right-8 duration-700">
            {selectedTopic ? (
               <div className="animate-in zoom-in-95 duration-400">
                 <button onClick={() => {setSelectedTopic(null);}} className="flex items-center gap-3 text-blue-500 font-black uppercase text-[10px] tracking-[0.2em] mb-8 hover:translate-x-[-6px] transition-transform">
                    <ArrowLeft size={16} /> Voltar para a Central
                  </button>
                  <div className="bg-slate-900/60 border border-white/5 rounded-[3rem] p-8 md:p-16 shadow-2xl space-y-10">
                    <div className="flex flex-col md:flex-row justify-between items-start gap-6">
                       <div className="space-y-4">
                          <span className={`px-5 py-1.5 rounded-full text-[10px] font-black uppercase border inline-block ${TOPIC_STATUS[selectedTopic.status as keyof typeof TOPIC_STATUS]?.color || TOPIC_STATUS.PENDING.color}`}>
                            {TOPIC_STATUS[selectedTopic.status as keyof typeof TOPIC_STATUS]?.label}
                          </span>
                          <h1 className="text-3xl md:text-5xl font-orbitron font-black text-white uppercase tracking-tighter mb-2 italic">{selectedTopic.title}</h1>
                          <div className="flex items-center gap-4 text-slate-500 text-[10px] font-black uppercase tracking-widest">
                             <div className="flex items-center gap-2">Autor: <span className="text-white">{selectedTopic.author}</span></div>
                             <div className="w-1 h-1 rounded-full bg-slate-700"></div>
                             <div>{new Date(selectedTopic.createdAt).toLocaleDateString()}</div>
                          </div>
                       </div>
                       <button onClick={() => deleteTopic(selectedTopic.id)} className="p-4 bg-red-600/10 text-red-500 rounded-2xl hover:bg-red-600 hover:text-white transition-all shadow-lg"><Trash2 size={24}/></button>
                    </div>

                    <div className="bg-slate-950/80 p-10 rounded-[2.5rem] text-slate-300 italic whitespace-pre-wrap border border-white/5 min-h-[200px] leading-relaxed font-medium">
                       {selectedTopic.description}
                    </div>

                    <div className="pt-10 border-t border-white/5 space-y-8">
                      <div className="flex items-center gap-3">
                         <Shield className="text-blue-500" size={24} />
                         <h4 className="font-orbitron font-black text-white uppercase text-xl italic tracking-tighter">VEREDITO <span className="text-blue-500 italic">STAFF MASTER</span></h4>
                      </div>
                      <textarea 
                        rows={6} 
                        placeholder="Redija a resposta técnica ou disciplinar aqui..." 
                        className="w-full bg-slate-950/50 border border-white/10 rounded-[2rem] p-8 text-white focus:border-blue-500 outline-none transition-all text-sm font-archivo placeholder:text-slate-700" 
                        value={response} 
                        onChange={(e) => setResponse(e.target.value)} 
                      />
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <button onClick={() => updateStatus(selectedTopic.id, 'approved')} className="bg-green-600 hover:bg-green-500 text-white font-black py-6 rounded-2xl flex items-center justify-center gap-4 transition-all uppercase text-xs tracking-widest shadow-xl shadow-green-600/20 active:scale-[0.98]">
                          <Check size={20} /> Aprovar / Resolver
                        </button>
                        <button onClick={() => updateStatus(selectedTopic.id, 'rejected')} className="bg-red-600 hover:bg-red-500 text-white font-black py-6 rounded-2xl flex items-center justify-center gap-4 transition-all uppercase text-xs tracking-widest shadow-xl shadow-red-600/20 active:scale-[0.98]">
                          <X size={20} /> Reprovar / Negar
                        </button>
                      </div>
                    </div>
                  </div>
               </div>
            ) : (
              <div className="space-y-8">
                {/* Search & Filter Bar */}
                <div className="flex flex-col lg:flex-row justify-between items-center gap-6 bg-slate-900/40 p-8 rounded-[2.5rem] border border-white/5 shadow-xl">
                   <div className="relative w-full lg:w-[500px]">
                      <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-600" size={20} />
                      <input 
                        type="text" 
                        placeholder="Pesquisar por autor ou palavra-chave..." 
                        className="w-full bg-slate-950/50 border border-white/5 rounded-2xl py-4 pl-14 pr-6 text-sm text-white focus:border-blue-500 outline-none transition-all font-archivo placeholder:text-slate-700"
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                      />
                   </div>
                   <div className="flex items-center gap-4 w-full lg:w-auto">
                      <Filter className="text-slate-600 hidden sm:block" size={20} />
                      <select 
                        className="flex-grow lg:flex-none bg-slate-950/50 border border-white/5 rounded-2xl py-4 px-6 text-[10px] font-black text-white outline-none focus:border-blue-500 transition-all uppercase tracking-widest cursor-pointer"
                        value={statusFilter}
                        onChange={(e) => setStatusFilter(e.target.value)}
                      >
                        <option value="all">Filtrar por Status</option>
                        <option value="pending">Aguardando Análise</option>
                        <option value="approved">Aprovados/Resolvidos</option>
                        <option value="rejected">Reprovados/Arquivados</option>
                      </select>
                   </div>
                </div>

                {/* Table Layout */}
                <div className="bg-slate-900/40 rounded-[3rem] border border-white/5 overflow-hidden shadow-2xl">
                  <div className="overflow-x-auto">
                    <table className="w-full text-left">
                      <thead>
                        <tr className="bg-slate-950/80 text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] border-b border-white/5">
                          <th className="px-10 py-8">Status</th>
                          <th className="px-10 py-8">Título da Solicitação</th>
                          <th className="px-10 py-8">Operador</th>
                          <th className="px-10 py-8 text-right">Controle</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5">
                        {filteredTopics.map((topic) => (
                          <tr key={topic.id} className="hover:bg-blue-600/5 transition-all cursor-pointer group" onClick={() => setSelectedTopic(topic)}>
                            <td className="px-10 py-8">
                              <span className={`px-4 py-1 rounded-full text-[9px] font-black uppercase border ${TOPIC_STATUS[topic.status as keyof typeof TOPIC_STATUS]?.color || TOPIC_STATUS.PENDING.color}`}>
                                {TOPIC_STATUS[topic.status as keyof typeof TOPIC_STATUS]?.label}
                              </span>
                            </td>
                            <td className="px-10 py-8 font-black text-white uppercase text-sm group-hover:text-blue-500 transition-colors italic tracking-tighter">
                               {topic.title}
                            </td>
                            <td className="px-10 py-8">
                               <div className="flex items-center gap-3">
                                  <div className="w-8 h-8 rounded-lg bg-slate-800 flex items-center justify-center text-[10px] font-black text-slate-400 group-hover:bg-blue-600 group-hover:text-white transition-all uppercase">{topic.author.substring(0,2)}</div>
                                  <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">{topic.author}</span>
                               </div>
                            </td>
                            <td className="px-10 py-8 text-right">
                               <button className="bg-slate-950 hover:bg-blue-600 text-white font-black py-3 px-6 rounded-xl text-[9px] uppercase tracking-widest transition-all shadow-lg border border-white/5">Gerenciar</button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  {filteredTopics.length === 0 && (
                    <div className="p-32 text-center text-slate-700 font-black uppercase text-xs tracking-[0.3em] flex flex-col items-center gap-4">
                       <Search size={48} className="opacity-20" />
                       Nenhum registro encontrado no banco de dados.
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
    </>
  );
};

export default AdminDashboard;
