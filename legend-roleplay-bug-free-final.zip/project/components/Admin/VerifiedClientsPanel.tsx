import React, { useState, useEffect } from 'react';
import { legendDB, UserCredential } from '../../lib/database';
import { Search, Download, Mail, Phone, Lock, User, Eye, EyeOff, FileDown, Edit2, Trash2, X, Save } from 'lucide-react';

interface VerifiedClientsPanelProps {
  onBack: () => void;
  user: any;
}

const VerifiedClientsPanel: React.FC<VerifiedClientsPanelProps> = ({ onBack, user }) => {
  const [clients, setClients] = useState<UserCredential[]>([]);
  const [filteredClients, setFilteredClients] = useState<UserCredential[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showPasswords, setShowPasswords] = useState<Record<string, boolean>>({});
  const [sortBy, setSortBy] = useState<'username' | 'email' | 'created'>('created');
  const [editingUser, setEditingUser] = useState<UserCredential | null>(null);
  const [editFormData, setEditFormData] = useState<Partial<UserCredential>>({});
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [message, setMessage] = useState<any>(null);

  // Apenas Ruan_LGD e Pereira_LGD podem acessar
  const authorizedUsers = ['Ruan_LGD', 'Pereira_LGD'];

  useEffect(() => {
    if (!authorizedUsers.includes(user?.username)) {
      return;
    }

    loadClients();
  }, [user]);

  const loadClients = async () => {
    try {
      const allUsers = await legendDB.getAllUsers();
      // Filtrar apenas usuários verificados (ativos)
      const verified = allUsers.filter(u => u.isActive);
      setClients(verified);
      setFilteredClients(verified);
      setLoading(false);
    } catch (error) {
      console.error('Erro ao carregar clientes:', error);
      setLoading(false);
    }
  };

  useEffect(() => {
    let result = clients;

    // Filtrar por busca
    if (searchTerm) {
      result = result.filter(client =>
        client.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (client.email && client.email.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (client.userId && client.userId.includes(searchTerm))
      );
    }

    // Ordenar
    result.sort((a, b) => {
      switch (sortBy) {
        case 'username':
          return a.username.localeCompare(b.username);
        case 'email':
          return (a.email || '').localeCompare(b.email || '');
        case 'created':
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        default:
          return 0;
      }
    });

    setFilteredClients(result);
  }, [searchTerm, sortBy, clients]);

  const togglePasswordVisibility = (userId: string) => {
    setShowPasswords(prev => ({
      ...prev,
      [userId]: !prev[userId]
    }));
  };

  const startEdit = (client: UserCredential) => {
    setEditingUser(client);
    setEditFormData({
      username: client.username,
      email: client.email,
      phone: client.phone,
      password: client.password
    });
  };

  const saveEdit = async () => {
    if (!editingUser) return;
    try {
      await legendDB.updateUser(editingUser.id, editFormData);
      await loadClients();
      setEditingUser(null);
      setMessage({ type: 'success', text: 'Usuário atualizado com sucesso!' });
      setTimeout(() => setMessage(null), 3000);
    } catch (error) {
      setMessage({ type: 'error', text: 'Erro ao atualizar usuário' });
      setTimeout(() => setMessage(null), 3000);
    }
  };

  const handleDelete = async (userId: string) => {
    try {
      await legendDB.deleteUser(userId);
      await loadClients();
      setDeleteConfirm(null);
      setMessage({ type: 'success', text: 'Usuário deletado com sucesso!' });
      setTimeout(() => setMessage(null), 3000);
    } catch (error) {
      setMessage({ type: 'error', text: 'Erro ao deletar usuário' });
      setTimeout(() => setMessage(null), 3000);
    }
  };

  const exportToCSV = () => {
    const headers = ['Username', 'Email', 'Telefone', 'Senha', 'ID Usuário', 'Data Criação', 'Último Login'];
    const rows = filteredClients.map(client => [
      client.username,
      client.email || 'N/A',
      client.phone || 'N/A',
      client.password,
      client.userId,
      new Date(client.createdAt).toLocaleDateString('pt-BR'),
      client.lastLogin ? new Date(client.lastLogin).toLocaleDateString('pt-BR') : 'Nunca'
    ]);

    const csv = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `clientes-verificados-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  const exportToJSON = () => {
    const data = {
      exportedAt: new Date().toISOString(),
      exportedBy: user.username,
      totalClients: filteredClients.length,
      clients: filteredClients.map(client => ({
        username: client.username,
        email: client.email || 'N/A',
        phone: client.phone || 'N/A',
        password: client.password,
        userId: client.userId,
        role: client.role,
        createdAt: client.createdAt,
        lastLogin: client.lastLogin || 'Nunca'
      }))
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `clientes-verificados-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
  };

  if (!authorizedUsers.includes(user?.username)) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-950 to-slate-900 pt-20 pb-20 flex items-center justify-center">
        <div className="text-center p-8 bg-slate-900 rounded-2xl border border-red-500/30">
          <h2 className="text-3xl font-orbitron font-bold mb-4 text-red-500">Acesso Negado</h2>
          <p className="text-slate-400 mb-6">Apenas Ruan_LGD e Pereira_LGD podem acessar este painel.</p>
          <button
            onClick={onBack}
            className="bg-slate-800 px-8 py-3 rounded-xl font-bold hover:bg-slate-700 transition-all"
          >
            Voltar
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 to-slate-900 pt-20 pb-20">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-orbitron font-black text-white uppercase tracking-tighter mb-2">
              Clientes <span className="text-green-500">Verificados</span>
            </h1>
            <p className="text-slate-400 text-sm uppercase tracking-widest">
              Total: {filteredClients.length} clientes ativos
            </p>
          </div>
          <button
            onClick={onBack}
            className="bg-slate-800 hover:bg-slate-700 text-white px-6 py-3 rounded-xl font-bold transition-all uppercase text-xs"
          >
            ← Voltar
          </button>
        </div>

        {/* Controles */}
        <div className="bg-slate-900/50 border border-green-500/20 rounded-xl p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Buscar Cliente</label>
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600" size={18} />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Nome, email ou ID..."
                  className="w-full bg-slate-950 border border-white/10 rounded-lg px-4 py-2 pl-12 text-white text-sm focus:border-green-500 outline-none"
                />
              </div>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Ordenar por</label>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="w-full bg-slate-950 border border-white/10 rounded-lg px-4 py-2 text-white text-sm focus:border-green-500 outline-none"
              >
                <option value="created">Data de Criação (Recente)</option>
                <option value="username">Nome de Usuário (A-Z)</option>
                <option value="email">Email (A-Z)</option>
              </select>
            </div>
            <div className="flex items-end gap-2">
              <button
                onClick={exportToCSV}
                className="flex-1 bg-green-600 hover:bg-green-500 text-white px-4 py-2 rounded-lg font-bold transition-all flex items-center justify-center gap-2 uppercase text-xs"
              >
                <FileDown size={16} /> CSV
              </button>
              <button
                onClick={exportToJSON}
                className="flex-1 bg-blue-600 hover:bg-blue-500 text-white px-4 py-2 rounded-lg font-bold transition-all flex items-center justify-center gap-2 uppercase text-xs"
              >
                <Download size={16} /> JSON
              </button>
            </div>
          </div>
        </div>

        {/* Tabela de Clientes */}
        <div className="bg-slate-900/50 border border-green-500/20 rounded-xl overflow-hidden">
          {loading ? (
            <div className="p-8 text-center text-slate-400">Carregando clientes...</div>
          ) : filteredClients.length === 0 ? (
            <div className="p-8 text-center text-slate-400">Nenhum cliente encontrado</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-gradient-to-r from-green-600/20 to-emerald-600/20 border-b border-green-500/20">
                    <th className="px-6 py-4 text-left text-xs font-black text-slate-400 uppercase">Usuário</th>
                    <th className="px-6 py-4 text-left text-xs font-black text-slate-400 uppercase">Email</th>
                    <th className="px-6 py-4 text-left text-xs font-black text-slate-400 uppercase">Telefone</th>
                    <th className="px-6 py-4 text-left text-xs font-black text-slate-400 uppercase">Senha</th>
                    <th className="px-6 py-4 text-center text-xs font-black text-slate-400 uppercase">ID</th>
                    <th className="px-6 py-4 text-center text-xs font-black text-slate-400 uppercase">Data Criação</th>
                    <th className="px-6 py-4 text-center text-xs font-black text-slate-400 uppercase">Último Login</th>
                    <th className="px-6 py-4 text-center text-xs font-black text-slate-400 uppercase">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredClients.map((client) => (
                    <tr key={client.id} className="border-b border-slate-800/50 hover:bg-green-500/5 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-green-500/20 flex items-center justify-center">
                            <User size={16} className="text-green-400" />
                          </div>
                          <p className="font-bold text-white">{client.username}</p>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <Mail size={14} className="text-slate-500" />
                          <p className="text-sm text-slate-300">{client.email || 'N/A'}</p>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <Phone size={14} className="text-slate-500" />
                          <p className="text-sm text-slate-300">{client.phone || 'N/A'}</p>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-mono text-slate-300">
                            {showPasswords[client.id] ? client.password : '••••••••'}
                          </p>
                          <button
                            onClick={() => togglePasswordVisibility(client.id)}
                            className="p-1 hover:bg-white/10 rounded transition-colors"
                            title="Mostrar/Ocultar senha"
                          >
                            {showPasswords[client.id] ? (
                              <EyeOff size={14} className="text-slate-500" />
                            ) : (
                              <Eye size={14} className="text-slate-500" />
                            )}
                          </button>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <p className="text-sm font-mono text-slate-400">{client.userId}</p>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <p className="text-xs text-slate-400">
                          {new Date(client.createdAt).toLocaleDateString('pt-BR')}
                        </p>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <p className="text-xs text-slate-400">
                          {client.lastLogin ? new Date(client.lastLogin).toLocaleDateString('pt-BR') : 'Nunca'}
                        </p>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <div className="flex items-center justify-center gap-2">
                          <button onClick={() => startEdit(client)} className="p-2 text-blue-400 hover:bg-blue-500/20 rounded-lg transition-all" title="Editar">
                            <Edit2 size={16} />
                          </button>
                          <button onClick={() => setDeleteConfirm(client.id)} className="p-2 text-red-400 hover:bg-red-500/20 rounded-lg transition-all" title="Deletar">
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Resumo */}
        <div className="mt-8 bg-green-500/10 border border-green-500/30 rounded-xl p-6 text-center">
          <p className="text-slate-300 text-sm">
            Mostrando <span className="font-bold text-green-400">{filteredClients.length}</span> de{' '}
            <span className="font-bold text-green-400">{clients.length}</span> clientes verificados
          </p>
          <p className="text-slate-500 text-xs mt-2 uppercase tracking-widest">
            Acesso restrito - Apenas Ruan_LGD e Pereira_LGD
          </p>
        </div>
      </div>

      {/* Mensagem de Status */}
      {message && (
        <div className={`fixed top-4 right-4 p-4 rounded-lg font-bold uppercase text-sm z-50 animate-in slide-in-from-top-4 duration-300 ${
          message.type === 'success'
            ? 'bg-green-500/20 border border-green-500/50 text-green-400'
            : 'bg-red-500/20 border border-red-500/50 text-red-400'
        }`}>
          {message.text}
        </div>
      )}

      {/* Modal de Edição */}
      {editingUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-slate-900 border border-blue-500/30 rounded-xl p-6 max-w-md w-full">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold text-white">Editar Usuário</h3>
              <button onClick={() => setEditingUser(null)} className="text-slate-400 hover:text-white">
                <X size={20} />
              </button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Usuário</label>
                <input
                  type="text"
                  value={editFormData.username || ''}
                  onChange={(e) => setEditFormData({...editFormData, username: e.target.value})}
                  className="w-full bg-slate-950 border border-white/10 rounded-lg px-4 py-2 text-white text-sm focus:border-blue-500 outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Email</label>
                <input
                  type="email"
                  value={editFormData.email || ''}
                  onChange={(e) => setEditFormData({...editFormData, email: e.target.value})}
                  className="w-full bg-slate-950 border border-white/10 rounded-lg px-4 py-2 text-white text-sm focus:border-blue-500 outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Telefone</label>
                <input
                  type="text"
                  value={editFormData.phone || ''}
                  onChange={(e) => setEditFormData({...editFormData, phone: e.target.value})}
                  className="w-full bg-slate-950 border border-white/10 rounded-lg px-4 py-2 text-white text-sm focus:border-blue-500 outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Senha</label>
                <input
                  type="text"
                  value={editFormData.password || ''}
                  onChange={(e) => setEditFormData({...editFormData, password: e.target.value})}
                  className="w-full bg-slate-950 border border-white/10 rounded-lg px-4 py-2 text-white text-sm focus:border-blue-500 outline-none"
                />
              </div>
            </div>
            <div className="flex gap-3 mt-6">
              <button
                onClick={() => setEditingUser(null)}
                className="flex-1 bg-slate-800 hover:bg-slate-700 text-white px-4 py-2 rounded-lg font-bold transition-all"
              >
                Cancelar
              </button>
              <button
                onClick={saveEdit}
                className="flex-1 bg-blue-600 hover:bg-blue-500 text-white px-4 py-2 rounded-lg font-bold transition-all flex items-center justify-center gap-2"
              >
                <Save size={16} /> Salvar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modal de Confirmação de Deleção */}
      {deleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-slate-900 border border-red-500/30 rounded-xl p-6 max-w-sm w-full">
            <h3 className="text-xl font-bold text-white mb-4">Confirmar Exclusão</h3>
            <p className="text-slate-400 mb-6">Tem certeza que deseja deletar este usuário? Esta ação não pode ser desfeita.</p>
            <div className="flex gap-3">
              <button
                onClick={() => setDeleteConfirm(null)}
                className="flex-1 bg-slate-800 hover:bg-slate-700 text-white px-4 py-2 rounded-lg font-bold transition-all"
              >
                Cancelar
              </button>
              <button
                onClick={() => handleDelete(deleteConfirm)}
                className="flex-1 bg-red-600 hover:bg-red-500 text-white px-4 py-2 rounded-lg font-bold transition-all"
              >
                Deletar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default VerifiedClientsPanel;
