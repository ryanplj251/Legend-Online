
import React, { useState } from 'react';
import { Menu, X, BarChart3, MessageSquare, Users, Globe, Shield, Bell, Code2, ArrowLeft } from 'lucide-react';

interface StaffMenuProps {
  user: any;
  onNavigate: (view: string) => void;
  onClose: () => void;
}

const StaffMenu: React.FC<StaffMenuProps> = ({ user, onNavigate, onClose }) => {
  const [isOpen, setIsOpen] = useState(false);

  const staffFunctions = [
    { id: 'overview', name: 'Analytics Geral', icon: BarChart3, color: 'from-blue-600 to-blue-700' },
    { id: 'list', name: 'Central de Tickets', icon: MessageSquare, color: 'from-purple-600 to-purple-700' },
    { id: 'verified-clients', name: 'Clientes Verificados', icon: Users, color: 'from-cyan-600 to-cyan-700' },
    { id: 'ip-tracker', name: 'Rastreamento de IPs', icon: Globe, color: 'from-orange-600 to-orange-700' },
    { id: 'security-logs', name: 'Logs de Segurança', icon: Shield, color: 'from-red-600 to-red-700' },
    { id: 'notification-manager', name: 'Gerenciar Notificações', icon: Bell, color: 'from-yellow-600 to-yellow-700' },
    { id: 'code-editor', name: 'Edição de Códigos', icon: Code2, color: 'from-emerald-600 to-emerald-700' },
  ];

  const handleNavigate = (id: string) => {
    onNavigate(id);
    setIsOpen(false);
  };

  return (
    <>
      {/* Botão Hambúrguer */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="fixed bottom-8 right-8 z-40 p-4 bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-500 hover:to-purple-500 text-white rounded-full shadow-2xl transition-all hover:scale-110 hover:shadow-blue-500/50"
        title="Menu Staff"
      >
        {isOpen ? <X size={24} /> : <Menu size={24} />}
      </button>

      {/* Menu Overlay */}
      {isOpen && (
        <div
          className="fixed inset-0 bg-black/50 backdrop-blur-sm z-30"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Menu Panel */}
      {isOpen && (
        <div className="fixed bottom-24 right-8 z-40 w-96 bg-gradient-to-b from-slate-900 to-slate-950 border border-blue-500/30 rounded-2xl shadow-2xl overflow-hidden animate-in slide-in-from-bottom-4 duration-300">
          
          {/* Header */}
          <div className="bg-gradient-to-r from-blue-600/20 to-purple-600/20 border-b border-blue-500/30 px-6 py-4">
            <h3 className="text-lg font-orbitron font-bold text-white">Menu Staff</h3>
            <p className="text-xs text-slate-400 mt-1">Funções Administrativas</p>
          </div>

          {/* Functions Grid */}
          <div className="p-4 space-y-2 max-h-96 overflow-y-auto">
            {staffFunctions.map((func) => {
              const Icon = func.icon;
              return (
                <button
                  key={func.id}
                  onClick={() => handleNavigate(func.id)}
                  className="w-full flex items-center gap-3 px-4 py-3 rounded-lg bg-slate-800/50 hover:bg-slate-700 transition-all border border-slate-700/50 hover:border-blue-500/50 group"
                >
                  <div className={`p-2 bg-gradient-to-r ${func.color} rounded-lg text-white group-hover:shadow-lg group-hover:shadow-blue-500/30 transition-all`}>
                    <Icon size={18} />
                  </div>
                  <div className="flex-1 text-left">
                    <p className="text-sm font-bold text-white">{func.name}</p>
                  </div>
                  <div className="text-slate-500 group-hover:text-blue-400 transition-colors">
                    →
                  </div>
                </button>
              );
            })}
          </div>

          {/* Footer */}
          <div className="border-t border-slate-700/50 px-6 py-4 bg-slate-950/50">
            <button
              onClick={() => setIsOpen(false)}
              className="w-full flex items-center justify-center gap-2 px-4 py-2 text-xs font-bold text-slate-400 hover:text-white transition-colors uppercase tracking-widest"
            >
              <ArrowLeft size={14} />
              Fechar Menu
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export default StaffMenu;
