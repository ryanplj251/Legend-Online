import React, { useState, useEffect } from 'react';
import { legendDB, UserCredential, IPLog } from '../../lib/database';
import { Search, Download, Globe, Calendar, User, FileDown, X, Copy, CheckCircle } from 'lucide-react';

interface IPTrackerProps {
  onBack: () => void;
  user: any;
}

const IPTracker: React.FC<IPTrackerProps> = ({ onBack, user }) => {
  const [clients, setClients] = useState<UserCredential[]>([]);
  const [filteredClients, setFilteredClients] = useState<UserCredential[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedUser, setSelectedUser] = useState<UserCredential | null>(null);
  const [copiedIP, setCopiedIP] = useState<string | null>(null);
  const [message, setMessage] = useState<{type: 'success' | 'error', text: string} | null>(null);

  const authorizedUsers = ['Ruan_LGD', 'Pereira_LGD'];

  useEffect(() => {
    if (!authorizedUsers.includes(user?.username)) {
      return;
    }
    loadClients();
  }, [user]);

  const loadClients = async () => {
    try {
      const allUsers = await legendDB.getAllUsers();
      setClients(allUsers);
      setFilteredClients(allUsers);
      setLoading(false);
    } catch (error) {
      console.error('Erro ao carregar clientes:', error);
      setLoading(false);
    }
  };

  useEffect(() => {
    let result = clients;

    if (searchTerm) {
      result = result.filter(client =>
        client.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (client.registrationIP && client.registrationIP.includes(searchTerm))
      );
    }

    setFilteredClients(result);
  }, [searchTerm, clients]);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedIP(text);
    setTimeout(() => setCopiedIP(null), 2000);
  };

  const exportIPsToCSV = () => {
    const headers = ['Username', 'Email', 'IP Registro', 'Data Registro', 'Último Login'];
    const rows = filteredClients.map(client => [
      client.username,
      client.email || 'N/A',
      client.registrationIP || 'N/A',
      new Date(client.createdAt).toLocaleDateString('pt-BR'),
      client.lastLogin ? new Date(client.lastLogin).toLocaleDateString('pt-BR') : 'Nunca'
    ]);

    const csv = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ips-clientes-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  const exportIPsToJSON = () => {
    const data = {
      exportedAt: new Date().toISOString(),
      exportedBy: user.username,
      totalClients: filteredClients.length,
      clients: filteredClients.map(client => ({
        username: client.username,
        email: client.email || 'N/A',
        registrationIP: client.registrationIP || 'N/A',
        createdAt: client.createdAt,
        lastLogin: client.lastLogin || 'Nunca',
        loginHistory: client.loginHistory || []
      }))
    };

    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ips-clientes-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
  };

  if (!authorizedUsers.includes(user?.username)) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-950 to-slate-900 pt-20 pb-20 flex items-center justify-center">
        <div className="text-center p-8 bg-slate-900 rounded-2xl border border-red-500/30">
          <h2 className="text-3xl font-orbitron font-bold mb-4 text-red-500">Acesso Negado</h2>
          <p className="text-slate-400 mb-6">Apenas Ruan_LGD e Pereira_LGD podem acessar este painel.</p>
          <button
            onClick={onBack}
            className="bg-slate-800 px-8 py-3 rounded-xl font-bold hover:bg-slate-700 transition-all"
          >
            Voltar
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 to-slate-900 pt-20 pb-20">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-orbitron font-black text-white uppercase tracking-tighter mb-2">
              Rastreamento de <span className="text-purple-500">IPs</span>
            </h1>
            <p className="text-slate-400 text-sm uppercase tracking-widest">
              Total: {filteredClients.length} clientes com IPs registrados
            </p>
          </div>
          <button
            onClick={onBack}
            className="bg-slate-800 hover:bg-slate-700 text-white px-6 py-3 rounded-xl font-bold transition-all uppercase text-xs"
          >
            ← Voltar
          </button>
        </div>

        {/* Controles */}
        <div className="bg-slate-900/50 border border-purple-500/20 rounded-xl p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Buscar Cliente ou IP</label>
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-600" size={18} />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Nome ou IP..."
                  className="w-full bg-slate-950 border border-white/10 rounded-lg px-4 py-2 pl-12 text-white text-sm focus:border-purple-500 outline-none"
                />
              </div>
            </div>
            <div className="flex items-end gap-2">
              <button
                onClick={exportIPsToCSV}
                className="flex-1 bg-purple-600 hover:bg-purple-500 text-white px-4 py-2 rounded-lg font-bold transition-all flex items-center justify-center gap-2 uppercase text-xs"
              >
                <FileDown size={16} /> CSV
              </button>
              <button
                onClick={exportIPsToJSON}
                className="flex-1 bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2 rounded-lg font-bold transition-all flex items-center justify-center gap-2 uppercase text-xs"
              >
                <Download size={16} /> JSON
              </button>
            </div>
          </div>
        </div>

        {/* Tabela de IPs */}
        <div className="bg-slate-900/50 border border-purple-500/20 rounded-xl overflow-hidden">
          {loading ? (
            <div className="p-8 text-center text-slate-400">Carregando dados...</div>
          ) : filteredClients.length === 0 ? (
            <div className="p-8 text-center text-slate-400">Nenhum cliente encontrado</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-gradient-to-r from-purple-600/20 to-indigo-600/20 border-b border-purple-500/20">
                    <th className="px-6 py-4 text-left text-xs font-black text-slate-400 uppercase">Usuário</th>
                    <th className="px-6 py-4 text-left text-xs font-black text-slate-400 uppercase">IP Registro</th>
                    <th className="px-6 py-4 text-left text-xs font-black text-slate-400 uppercase">Email</th>
                    <th className="px-6 py-4 text-center text-xs font-black text-slate-400 uppercase">Data Registro</th>
                    <th className="px-6 py-4 text-center text-xs font-black text-slate-400 uppercase">Último Login</th>
                    <th className="px-6 py-4 text-center text-xs font-black text-slate-400 uppercase">Ação</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredClients.map((client) => (
                    <tr key={client.id} className="border-b border-slate-800/50 hover:bg-purple-500/5 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-purple-500/20 flex items-center justify-center">
                            <User size={16} className="text-purple-400" />
                          </div>
                          <p className="font-bold text-white">{client.username}</p>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-2">
                          <Globe size={14} className="text-slate-500" />
                          <p className="text-sm font-mono text-slate-300">{client.registrationIP || 'N/A'}</p>
                          {client.registrationIP && (
                            <button
                              onClick={() => copyToClipboard(client.registrationIP!)}
                              className="p-1 hover:bg-white/10 rounded transition-colors"
                              title="Copiar IP"
                            >
                              {copiedIP === client.registrationIP ? (
                                <CheckCircle size={14} className="text-green-500" />
                              ) : (
                                <Copy size={14} className="text-slate-500" />
                              )}
                            </button>
                          )}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <p className="text-sm text-slate-300">{client.email || 'N/A'}</p>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <div className="flex items-center justify-center gap-2">
                          <Calendar size={14} className="text-slate-500" />
                          <p className="text-xs text-slate-400">
                            {new Date(client.createdAt).toLocaleDateString('pt-BR')}
                          </p>
                        </div>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <p className="text-xs text-slate-400">
                          {client.lastLogin ? new Date(client.lastLogin).toLocaleDateString('pt-BR') : 'Nunca'}
                        </p>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <button
                          onClick={() => setSelectedUser(client)}
                          className="px-3 py-1 bg-purple-600 hover:bg-purple-500 text-white text-xs font-bold rounded-lg transition-all"
                        >
                          Detalhes
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Resumo */}
        <div className="mt-8 bg-purple-500/10 border border-purple-500/30 rounded-xl p-6 text-center">
          <p className="text-slate-300 text-sm">
            Mostrando <span className="font-bold text-purple-400">{filteredClients.length}</span> de{' '}
            <span className="font-bold text-purple-400">{clients.length}</span> clientes
          </p>
          <p className="text-slate-500 text-xs mt-2 uppercase tracking-widest">
            Acesso restrito - Apenas Ruan_LGD e Pereira_LGD
          </p>
        </div>
      </div>

      {/* Modal de Detalhes */}
      {selectedUser && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
          <div className="bg-slate-900 border border-purple-500/30 rounded-xl p-6 max-w-2xl w-full max-h-96 overflow-y-auto">
            <div className="flex justify-between items-center mb-6">
              <h3 className="text-xl font-bold text-white">Histórico de IPs - {selectedUser.username}</h3>
              <button onClick={() => setSelectedUser(null)} className="text-slate-400 hover:text-white">
                <X size={20} />
              </button>
            </div>
            <div className="space-y-3">
              <div className="p-4 bg-slate-950 rounded-lg border border-white/10">
                <p className="text-xs font-bold text-slate-400 uppercase mb-2">IP de Registro</p>
                <div className="flex items-center gap-2">
                  <p className="text-sm font-mono text-white">{selectedUser.registrationIP || 'N/A'}</p>
                  {selectedUser.registrationIP && (
                    <button
                      onClick={() => copyToClipboard(selectedUser.registrationIP!)}
                      className="p-1 hover:bg-white/10 rounded transition-colors"
                    >
                      <Copy size={14} className="text-slate-500" />
                    </button>
                  )}
                </div>
              </div>

              {selectedUser.loginHistory && selectedUser.loginHistory.length > 0 ? (
                <div>
                  <p className="text-xs font-bold text-slate-400 uppercase mb-2">Histórico de Acessos</p>
                  <div className="space-y-2 max-h-64 overflow-y-auto">
                    {selectedUser.loginHistory.map((log, idx) => (
                      <div key={idx} className="p-3 bg-slate-950 rounded-lg border border-white/5">
                        <div className="flex justify-between items-start">
                          <div>
                            <p className="text-xs font-mono text-purple-400">{log.ip}</p>
                            <p className="text-[10px] text-slate-500 mt-1">
                              {new Date(log.timestamp).toLocaleString('pt-BR')}
                            </p>
                          </div>
                          <span className={`text-xs font-bold px-2 py-1 rounded ${
                            log.action === 'login'
                              ? 'bg-green-500/20 text-green-400'
                              : 'bg-blue-500/20 text-blue-400'
                          }`}>
                            {log.action === 'login' ? 'LOGIN' : 'REGISTRO'}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="p-4 bg-slate-950 rounded-lg border border-white/10 text-center">
                  <p className="text-sm text-slate-400">Nenhum histórico de acesso registrado</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Mensagem de Status */}
      {message && (
        <div className={`fixed top-4 right-4 p-4 rounded-lg font-bold uppercase text-sm z-50 animate-in slide-in-from-top-4 duration-300 ${
          message.type === 'success'
            ? 'bg-green-500/20 border border-green-500/50 text-green-400'
            : 'bg-red-500/20 border border-red-500/50 text-red-400'
        }`}>
          {message.text}
        </div>
      )}
    </div>
  );
};

export default IPTracker;
