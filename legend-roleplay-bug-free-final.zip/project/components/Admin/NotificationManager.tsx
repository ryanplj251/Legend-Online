import React, { useState, useEffect } from 'react';
import { X, Upload, AlertCircle, CheckCircle, ArrowLeft, Send, Trash2 } from 'lucide-react';

interface Notification {
  id: string;
  title: string;
  description: string;
  image?: string;
  video?: string;
  createdBy: string;
  createdAt: Date;
  type: 'image' | 'video' | 'text';
}

interface NotificationManagerProps {
  onBack: () => void;
  user: any;
}

const NotificationManager: React.FC<NotificationManagerProps> = ({ onBack, user }) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [fileType, setFileType] = useState<'image' | 'video' | 'text'>('text');

  const authorizedUsers = ['Ruan_LGD', 'Pereira_LGD', 'Galo_LGD', 'p2castro_LGD'];
  const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB

  useEffect(() => {
    loadNotifications();
  }, []);

  const loadNotifications = () => {
    const stored = localStorage.getItem('legend_notifications');
    if (stored) {
      setNotifications(JSON.parse(stored));
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > MAX_FILE_SIZE) {
      setError('❌ Arquivo muito grande! Máximo 50MB.');
      return;
    }

    const isImage = file.type.startsWith('image/');
    const isVideo = file.type.startsWith('video/');

    if (!isImage && !isVideo) {
      setError('❌ Apenas imagens e vídeos são permitidos.');
      return;
    }

    setSelectedFile(file);
    setFileType(isImage ? 'image' : 'video');

    const reader = new FileReader();
    reader.onload = (event) => {
      setPreview(event.target?.result as string);
    };
    reader.readAsDataURL(file);
    setError('');
  };

  const handleCreateNotification = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!authorizedUsers.includes(user?.username)) {
      setError('❌ Você não tem permissão para criar notificações.');
      return;
    }

    if (!title.trim()) {
      setError('❌ Título é obrigatório.');
      return;
    }

    if (!description.trim()) {
      setError('❌ Descrição é obrigatória.');
      return;
    }

    setLoading(true);

    try {
      const notification: Notification = {
        id: `${Date.now()}-${Math.random()}`,
        title: title.trim(),
        description: description.trim(),
        image: fileType === 'image' ? preview : undefined,
        video: fileType === 'video' ? preview : undefined,
        createdBy: user.username,
        createdAt: new Date(),
        type: fileType
      };

      const updated = [notification, ...notifications];
      localStorage.setItem('legend_notifications', JSON.stringify(updated));
      setNotifications(updated);

      setTitle('');
      setDescription('');
      setSelectedFile(null);
      setPreview('');
      setFileType('text');
      setSuccess('✅ Notificação criada com sucesso!');

      setTimeout(() => setSuccess(''), 3000);
    } catch (err) {
      setError('❌ Erro ao criar notificação.');
    } finally {
      setLoading(false);
    }
  };

  const deleteNotification = (id: string) => {
    const updated = notifications.filter(n => n.id !== id);
    localStorage.setItem('legend_notifications', JSON.stringify(updated));
    setNotifications(updated);
  };

  if (!authorizedUsers.includes(user?.username)) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-950 to-slate-900 pt-20 pb-20 flex items-center justify-center">
        <div className="text-center p-8 bg-slate-900 rounded-2xl border border-red-500/30">
          <h2 className="text-3xl font-orbitron font-bold mb-4 text-red-500">Acesso Negado</h2>
          <p className="text-slate-400 mb-6">Apenas membros da staff (Ruan_LGD, Pereira_LGD, Galo_LGD e p2castro_LGD) podem gerenciar notificações.</p>
          <button
            onClick={onBack}
            className="bg-slate-800 px-8 py-3 rounded-xl font-bold hover:bg-slate-700 transition-all"
          >
            Voltar
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 to-slate-900 pt-20 pb-20">
      <div className="max-w-6xl mx-auto px-4">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-orbitron font-black text-white uppercase tracking-tighter mb-2">
              Gerenciar <span className="text-blue-500">Notificações</span>
            </h1>
            <p className="text-slate-400 text-sm uppercase tracking-widest">
              Total: {notifications.length} notificações
            </p>
          </div>
          <button
            onClick={onBack}
            className="bg-slate-800 hover:bg-slate-700 text-white px-6 py-3 rounded-xl font-bold transition-all uppercase text-xs flex items-center gap-2"
          >
            <ArrowLeft size={16} /> Voltar
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Formulário */}
          <div className="lg:col-span-1">
            <div className="bg-slate-900/50 border border-blue-500/20 rounded-xl p-6 sticky top-24">
              <h2 className="text-xl font-bold text-white mb-6 uppercase">Criar Notificação</h2>

              {error && (
                <div className="mb-4 p-3 bg-red-500/10 border border-red-500/30 rounded-lg flex gap-2">
                  <AlertCircle className="text-red-500 flex-shrink-0" size={18} />
                  <p className="text-sm text-red-400">{error}</p>
                </div>
              )}

              {success && (
                <div className="mb-4 p-3 bg-green-500/10 border border-green-500/30 rounded-lg flex gap-2">
                  <CheckCircle className="text-green-500 flex-shrink-0" size={18} />
                  <p className="text-sm text-green-400">{success}</p>
                </div>
              )}

              <form onSubmit={handleCreateNotification} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Título</label>
                  <input
                    type="text"
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="Título da notificação"
                    className="w-full bg-slate-950 border border-white/10 rounded-lg px-4 py-2 text-white text-sm focus:border-blue-500 outline-none"
                    disabled={loading}
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Descrição</label>
                  <textarea
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Descrição da notificação"
                    rows={4}
                    className="w-full bg-slate-950 border border-white/10 rounded-lg px-4 py-2 text-white text-sm focus:border-blue-500 outline-none resize-none"
                    disabled={loading}
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Mídia (Opcional)</label>
                  <label className="w-full bg-slate-950 border border-dashed border-blue-500/50 rounded-lg px-4 py-6 text-center cursor-pointer hover:border-blue-500 transition-colors">
                    <Upload className="mx-auto text-blue-500 mb-2" size={24} />
                    <p className="text-xs text-slate-400">Clique para selecionar imagem ou vídeo</p>
                    <p className="text-[10px] text-slate-600 mt-1">Máximo 50MB</p>
                    <input
                      type="file"
                      accept="image/*,video/*"
                      onChange={handleFileSelect}
                      className="hidden"
                      disabled={loading}
                    />
                  </label>
                </div>

                {preview && (
                  <div className="relative">
                    {fileType === 'image' ? (
                      <img src={preview} alt="Preview" className="w-full rounded-lg max-h-40 object-cover" />
                    ) : (
                      <video src={preview} className="w-full rounded-lg max-h-40 object-cover" controls />
                    )}
                    <button
                      type="button"
                      onClick={() => {
                        setPreview('');
                        setSelectedFile(null);
                      }}
                      className="absolute top-2 right-2 bg-red-600 hover:bg-red-500 text-white p-1 rounded-lg transition-all"
                    >
                      <X size={16} />
                    </button>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 disabled:opacity-50 text-white font-bold py-2 rounded-lg transition-all flex items-center justify-center gap-2 uppercase text-sm"
                >
                  {loading ? 'Criando...' : 'Criar Notificação'}
                  <Send size={16} />
                </button>
              </form>
            </div>
          </div>

          {/* Lista de Notificações */}
          <div className="lg:col-span-2">
            <div className="space-y-4">
              {notifications.length === 0 ? (
                <div className="bg-slate-900/50 border border-slate-800 rounded-xl p-8 text-center">
                  <p className="text-slate-400">Nenhuma notificação criada ainda.</p>
                </div>
              ) : (
                notifications.map((notif) => (
                  <div
                    key={notif.id}
                    className="bg-slate-900/50 border border-blue-500/20 rounded-xl p-6 hover:border-blue-500/50 transition-colors"
                  >
                    <div className="flex gap-4">
                      {/* Preview de Mídia */}
                      <div className="flex-shrink-0">
                        {notif.image ? (
                          <img
                            src={notif.image}
                            alt={notif.title}
                            className="w-20 h-20 rounded-lg object-cover border border-blue-500/30"
                          />
                        ) : notif.video ? (
                          <div className="w-20 h-20 rounded-lg bg-slate-950 border border-blue-500/30 flex items-center justify-center">
                            <span className="text-xs text-blue-400">VIDEO</span>
                          </div>
                        ) : (
                          <div className="w-20 h-20 rounded-lg bg-slate-950 border border-blue-500/30 flex items-center justify-center">
                            <span className="text-xs text-slate-500">SEM MÍDIA</span>
                          </div>
                        )}
                      </div>

                      {/* Conteúdo */}
                      <div className="flex-1">
                        <h3 className="text-lg font-bold text-white mb-1">{notif.title}</h3>
                        <p className="text-sm text-slate-400 mb-3 line-clamp-2">{notif.description}</p>
                        <div className="flex items-center justify-between text-xs">
                          <div className="flex gap-4 text-slate-500">
                            <span>Por: <span className="text-blue-400 font-bold">{notif.createdBy}</span></span>
                            <span>{new Date(notif.createdAt).toLocaleDateString('pt-BR')}</span>
                          </div>
                          <button
                            onClick={() => deleteNotification(notif.id)}
                            className="p-2 hover:bg-red-500/20 rounded-lg transition-colors text-red-500 hover:text-red-400"
                            title="Deletar notificação"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NotificationManager;
