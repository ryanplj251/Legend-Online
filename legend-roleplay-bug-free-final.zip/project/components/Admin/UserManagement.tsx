import React, { useState, useEffect } from 'react';
import { legendDB, UserCredential, DatabaseStats } from '../../lib/database';
import { Trash2, Edit2, Shield, User, Mail, Calendar, ToggleLeft, ToggleRight } from 'lucide-react';

interface UserManagementProps {
  onBack: () => void;
}

const UserManagement: React.FC<UserManagementProps> = ({ onBack }) => {
  const [users, setUsers] = useState<UserCredential[]>([]);
  const [stats, setStats] = useState<DatabaseStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterRole, setFilterRole] = useState<'all' | 'user' | 'staff' | 'admin'>('all');
  const [editingUser, setEditingUser] = useState<UserCredential | null>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState<string | null>(null);

  useEffect(() => {
    loadUsers();
    loadStats();
  }, []);

  const loadUsers = async () => {
    try {
      const allUsers = await legendDB.getAllUsers();
      setUsers(allUsers);
      setLoading(false);
    } catch (error) {
      console.error('Erro ao carregar usuários:', error);
      setLoading(false);
    }
  };

  const loadStats = async () => {
    try {
      const dbStats = await legendDB.getStats();
      setStats(dbStats);
    } catch (error) {
      console.error('Erro ao carregar estatísticas:', error);
    }
  };

  const handleDeleteUser = async (id: string) => {
    try {
      await legendDB.deleteUser(id);
      setUsers(users.filter(u => u.id !== id));
      setShowDeleteConfirm(null);
      loadStats();
    } catch (error) {
      console.error('Erro ao deletar usuário:', error);
    }
  };

  const handleToggleActive = async (user: UserCredential) => {
    try {
      const updated = await legendDB.updateUser(user.id, {
        isActive: !user.isActive,
      });
      setUsers(users.map(u => u.id === user.id ? updated : u));
      loadStats();
    } catch (error) {
      console.error('Erro ao atualizar usuário:', error);
    }
  };

  const filteredUsers = users.filter(user => {
    const matchesSearch = user.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = filterRole === 'all' || user.role === filterRole;
    return matchesSearch && matchesRole;
  });

  const getRoleColor = (role: string) => {
    switch(role) {
      case 'admin': return 'text-red-400 bg-red-500/10';
      case 'staff': return 'text-yellow-400 bg-yellow-500/10';
      default: return 'text-blue-400 bg-blue-500/10';
    }
  };

  const formatDate = (date: Date | undefined) => {
    if (!date) return 'Nunca';
    return new Date(date).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 to-slate-900 pt-20 pb-20">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-orbitron font-black text-white uppercase tracking-tighter mb-2">
              Gerenciar <span className="text-blue-500">Usuários</span>
            </h1>
            <p className="text-slate-400 text-sm uppercase tracking-widest">Banco de dados completo de credenciais</p>
          </div>
          <button
            onClick={onBack}
            className="bg-slate-800 hover:bg-slate-700 text-white px-6 py-3 rounded-xl font-bold transition-all uppercase text-xs"
          >
            ← Voltar
          </button>
        </div>

        {/* Stats */}
        {stats && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <div className="bg-blue-500/10 border border-blue-500/30 rounded-xl p-4">
              <p className="text-slate-400 text-xs uppercase font-bold mb-1">Total de Usuários</p>
              <p className="text-3xl font-black text-blue-400">{stats.totalUsers}</p>
            </div>
            <div className="bg-green-500/10 border border-green-500/30 rounded-xl p-4">
              <p className="text-slate-400 text-xs uppercase font-bold mb-1">Usuários Ativos</p>
              <p className="text-3xl font-black text-green-400">{stats.activeUsers}</p>
            </div>
            <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-4">
              <p className="text-slate-400 text-xs uppercase font-bold mb-1">Administradores</p>
              <p className="text-3xl font-black text-red-400">{stats.totalAdmins}</p>
            </div>
            <div className="bg-purple-500/10 border border-purple-500/30 rounded-xl p-4">
              <p className="text-slate-400 text-xs uppercase font-bold mb-1">Último Backup</p>
              <p className="text-xs font-bold text-purple-400">{formatDate(stats.lastBackup)}</p>
            </div>
          </div>
        )}

        {/* Filtros */}
        <div className="bg-slate-900/50 border border-blue-500/20 rounded-xl p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Buscar Usuário</label>
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Nome ou email..."
                className="w-full bg-slate-950 border border-white/10 rounded-lg px-4 py-2 text-white text-sm focus:border-blue-500 outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Filtrar por Role</label>
              <select
                value={filterRole}
                onChange={(e) => setFilterRole(e.target.value as any)}
                className="w-full bg-slate-950 border border-white/10 rounded-lg px-4 py-2 text-white text-sm focus:border-blue-500 outline-none"
              >
                <option value="all">Todos</option>
                <option value="user">Usuários</option>
                <option value="staff">Staff</option>
                <option value="admin">Administradores</option>
              </select>
            </div>
          </div>
        </div>

        {/* Tabela de Usuários */}
        <div className="bg-slate-900/50 border border-blue-500/20 rounded-xl overflow-hidden">
          {loading ? (
            <div className="p-8 text-center text-slate-400">Carregando usuários...</div>
          ) : filteredUsers.length === 0 ? (
            <div className="p-8 text-center text-slate-400">Nenhum usuário encontrado</div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead>
                  <tr className="bg-gradient-to-r from-blue-600/20 to-indigo-600/20 border-b border-blue-500/20">
                    <th className="px-6 py-4 text-left text-xs font-black text-slate-400 uppercase">Usuário</th>
                    <th className="px-6 py-4 text-left text-xs font-black text-slate-400 uppercase">Email</th>
                    <th className="px-6 py-4 text-center text-xs font-black text-slate-400 uppercase">Role</th>
                    <th className="px-6 py-4 text-center text-xs font-black text-slate-400 uppercase">Status</th>
                    <th className="px-6 py-4 text-center text-xs font-black text-slate-400 uppercase">Último Login</th>
                    <th className="px-6 py-4 text-center text-xs font-black text-slate-400 uppercase">Ações</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredUsers.map((user) => (
                    <tr key={user.id} className="border-b border-slate-800/50 hover:bg-blue-500/5 transition-colors">
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg bg-blue-500/20 flex items-center justify-center">
                            <User size={16} className="text-blue-400" />
                          </div>
                          <div>
                            <p className="font-bold text-white">{user.username}</p>
                            <p className="text-xs text-slate-500">ID: {user.id.substring(0, 12)}...</p>
                          </div>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <p className="text-sm text-slate-300">{user.email || 'N/A'}</p>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <span className={`px-3 py-1 rounded-full text-xs font-black uppercase ${getRoleColor(user.role)}`}>
                          {user.role}
                        </span>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <button
                          onClick={() => handleToggleActive(user)}
                          className={`px-3 py-1 rounded-full text-xs font-black uppercase transition-all ${
                            user.isActive
                              ? 'bg-green-500/20 text-green-400'
                              : 'bg-red-500/20 text-red-400'
                          }`}
                        >
                          {user.isActive ? 'Ativo' : 'Inativo'}
                        </button>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <p className="text-xs text-slate-400">{formatDate(user.lastLogin)}</p>
                      </td>
                      <td className="px-6 py-4 text-center">
                        <div className="flex items-center justify-center gap-2">
                          <button
                            onClick={() => setShowDeleteConfirm(user.id)}
                            className="p-2 text-red-400 hover:bg-red-500/20 rounded-lg transition-all"
                            title="Deletar usuário"
                          >
                            <Trash2 size={16} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>

        {/* Delete Confirmation */}
        {showDeleteConfirm && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
            <div className="bg-slate-900 border border-red-500/30 rounded-xl p-6 max-w-sm">
              <h3 className="text-xl font-bold text-white mb-4">Confirmar Exclusão</h3>
              <p className="text-slate-400 mb-6">Tem certeza que deseja deletar este usuário? Esta ação não pode ser desfeita.</p>
              <div className="flex gap-4">
                <button
                  onClick={() => setShowDeleteConfirm(null)}
                  className="flex-1 bg-slate-800 hover:bg-slate-700 text-white px-4 py-2 rounded-lg font-bold transition-all"
                >
                  Cancelar
                </button>
                <button
                  onClick={() => handleDeleteUser(showDeleteConfirm)}
                  className="flex-1 bg-red-600 hover:bg-red-500 text-white px-4 py-2 rounded-lg font-bold transition-all"
                >
                  Deletar
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default UserManagement;
