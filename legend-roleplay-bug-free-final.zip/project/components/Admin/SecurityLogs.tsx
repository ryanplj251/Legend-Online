import React, { useState, useEffect } from 'react';
import { securityManager, SecurityLog } from '../../lib/security';
import { ArrowLeft, AlertTriangle, CheckCircle, Shield, Download, Filter } from 'lucide-react';

interface SecurityLogsProps {
  onBack: () => void;
  user: any;
}

const SecurityLogs: React.FC<SecurityLogsProps> = ({ onBack, user }) => {
  const [logs, setLogs] = useState<SecurityLog[]>([]);
  const [filteredLogs, setFilteredLogs] = useState<SecurityLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterType, setFilterType] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');

  const authorizedUsers = ['Ruan_LGD', 'Pereira_LGD'];

  useEffect(() => {
    if (!authorizedUsers.includes(user?.username)) {
      return;
    }
    loadLogs();
  }, [user]);

  const loadLogs = async () => {
    try {
      const allLogs = await securityManager.getSecurityLogs(500);
      setLogs(allLogs);
      setFilteredLogs(allLogs);
      setLoading(false);
    } catch (error) {
      console.error('Erro ao carregar logs:', error);
      setLoading(false);
    }
  };

  useEffect(() => {
    let result = logs;

    if (filterType !== 'all') {
      result = result.filter(log => log.type === filterType);
    }

    if (searchTerm) {
      result = result.filter(log =>
        log.username?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        log.ip.includes(searchTerm)
      );
    }

    setFilteredLogs(result);
  }, [filterType, searchTerm, logs]);

  const getLogIcon = (type: string) => {
    switch (type) {
      case 'login_success':
        return <CheckCircle className="text-green-500" size={16} />;
      case 'login_failed':
        return <AlertTriangle className="text-red-500" size={16} />;
      case 'brute_force_detected':
        return <Shield className="text-red-600" size={16} />;
      case 'ip_blocked':
        return <AlertTriangle className="text-orange-500" size={16} />;
      default:
        return <Shield className="text-slate-500" size={16} />;
    }
  };

  const getLogColor = (type: string) => {
    switch (type) {
      case 'login_success':
        return 'bg-green-500/10 border-green-500/30';
      case 'login_failed':
        return 'bg-red-500/10 border-red-500/30';
      case 'brute_force_detected':
        return 'bg-red-600/10 border-red-600/30';
      case 'ip_blocked':
        return 'bg-orange-500/10 border-orange-500/30';
      default:
        return 'bg-slate-500/10 border-slate-500/30';
    }
  };

  const exportLogs = () => {
    const csv = [
      ['Timestamp', 'Type', 'Username', 'IP', 'Details'].join(','),
      ...filteredLogs.map(log => [
        new Date(log.timestamp).toLocaleString('pt-BR'),
        log.type,
        log.username || 'N/A',
        log.ip,
        log.details || 'N/A'
      ].map(cell => `"${cell}"`).join(','))
    ].join('\n');

    const blob = new Blob([csv], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `security-logs-${new Date().toISOString().split('T')[0]}.csv`;
    a.click();
  };

  if (!authorizedUsers.includes(user?.username)) {
    return (
      <div className="min-h-screen bg-gradient-to-b from-slate-950 to-slate-900 pt-20 pb-20 flex items-center justify-center">
        <div className="text-center p-8 bg-slate-900 rounded-2xl border border-red-500/30">
          <h2 className="text-3xl font-orbitron font-bold mb-4 text-red-500">Acesso Negado</h2>
          <p className="text-slate-400 mb-6">Apenas Ruan_LGD e Pereira_LGD podem acessar este painel.</p>
          <button
            onClick={onBack}
            className="bg-slate-800 px-8 py-3 rounded-xl font-bold hover:bg-slate-700 transition-all"
          >
            Voltar
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 to-slate-900 pt-20 pb-20">
      <div className="max-w-7xl mx-auto px-4">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h1 className="text-4xl font-orbitron font-black text-white uppercase tracking-tighter mb-2">
              Logs de <span className="text-red-500">Segurança</span>
            </h1>
            <p className="text-slate-400 text-sm uppercase tracking-widest">
              Total: {filteredLogs.length} eventos registrados
            </p>
          </div>
          <button
            onClick={onBack}
            className="bg-slate-800 hover:bg-slate-700 text-white px-6 py-3 rounded-xl font-bold transition-all uppercase text-xs flex items-center gap-2"
          >
            <ArrowLeft size={16} /> Voltar
          </button>
        </div>

        {/* Controles */}
        <div className="bg-slate-900/50 border border-red-500/20 rounded-xl p-6 mb-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Filtrar por Tipo</label>
              <select
                value={filterType}
                onChange={(e) => setFilterType(e.target.value)}
                className="w-full bg-slate-950 border border-white/10 rounded-lg px-4 py-2 text-white text-sm focus:border-red-500 outline-none"
              >
                <option value="all">Todos os Eventos</option>
                <option value="login_success">Login Bem-sucedido</option>
                <option value="login_failed">Login Falhado</option>
                <option value="brute_force_detected">Força Bruta Detectada</option>
                <option value="ip_blocked">IP Bloqueado</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-400 uppercase mb-2">Buscar</label>
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Usuário ou IP..."
                className="w-full bg-slate-950 border border-white/10 rounded-lg px-4 py-2 text-white text-sm focus:border-red-500 outline-none"
              />
            </div>
            <div className="flex items-end">
              <button
                onClick={exportLogs}
                className="w-full bg-red-600 hover:bg-red-500 text-white px-4 py-2 rounded-lg font-bold transition-all flex items-center justify-center gap-2 uppercase text-xs"
              >
                <Download size={16} /> Exportar CSV
              </button>
            </div>
          </div>
        </div>

        {/* Logs */}
        <div className="space-y-3">
          {loading ? (
            <div className="text-center p-8 text-slate-400">Carregando logs...</div>
          ) : filteredLogs.length === 0 ? (
            <div className="text-center p-8 text-slate-400">Nenhum log encontrado</div>
          ) : (
            filteredLogs.map((log) => (
              <div
                key={log.id}
                className={`border rounded-lg p-4 flex items-start gap-4 ${getLogColor(log.type)}`}
              >
                <div className="flex-shrink-0 mt-1">
                  {getLogIcon(log.type)}
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-bold text-white uppercase text-sm">
                      {log.type.replace(/_/g, ' ')}
                    </h3>
                    <p className="text-xs text-slate-500">
                      {new Date(log.timestamp).toLocaleString('pt-BR')}
                    </p>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-xs">
                    <div>
                      <p className="text-slate-500 uppercase font-bold">Usuário</p>
                      <p className="text-slate-300">{log.username || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-slate-500 uppercase font-bold">IP</p>
                      <p className="text-slate-300 font-mono">{log.ip}</p>
                    </div>
                    <div>
                      <p className="text-slate-500 uppercase font-bold">Detalhes</p>
                      <p className="text-slate-300">{log.details || 'N/A'}</p>
                    </div>
                    <div>
                      <p className="text-slate-500 uppercase font-bold">User Agent</p>
                      <p className="text-slate-300 truncate text-[10px]">{log.userAgent?.substring(0, 30) || 'N/A'}...</p>
                    </div>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Resumo */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-green-500/10 border border-green-500/30 rounded-xl p-4 text-center">
            <p className="text-3xl font-bold text-green-400">
              {logs.filter(l => l.type === 'login_success').length}
            </p>
            <p className="text-xs text-green-600 uppercase font-bold mt-1">Logins Bem-sucedidos</p>
          </div>
          <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-4 text-center">
            <p className="text-3xl font-bold text-red-400">
              {logs.filter(l => l.type === 'login_failed').length}
            </p>
            <p className="text-xs text-red-600 uppercase font-bold mt-1">Logins Falhados</p>
          </div>
          <div className="bg-orange-500/10 border border-orange-500/30 rounded-xl p-4 text-center">
            <p className="text-3xl font-bold text-orange-400">
              {logs.filter(l => l.type === 'brute_force_detected').length}
            </p>
            <p className="text-xs text-orange-600 uppercase font-bold mt-1">Força Bruta Detectada</p>
          </div>
          <div className="bg-purple-500/10 border border-purple-500/30 rounded-xl p-4 text-center">
            <p className="text-3xl font-bold text-purple-400">
              {logs.filter(l => l.type === 'ip_blocked').length}
            </p>
            <p className="text-xs text-purple-600 uppercase font-bold mt-1">IPs Bloqueados</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SecurityLogs;
