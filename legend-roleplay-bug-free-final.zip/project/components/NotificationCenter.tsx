import React, { useState, useEffect } from 'react';
import { Bell, X, AlertCircle, CheckCircle, Info, AlertTriangle } from 'lucide-react';

interface Notification {
  id: string;
  type: 'info' | 'success' | 'warning' | 'error';
  title: string;
  message: string;
  timestamp: Date;
  read: boolean;
  createdBy?: string;
  image?: string;
  video?: string;
}

const NotificationCenter: React.FC = () => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    loadNotifications();
    const interval = setInterval(loadNotifications, 5000);
    return () => clearInterval(interval);
  }, []);

  const loadNotifications = () => {
    // Notificações mockadas padrão
    const mockNotifications: Notification[] = [
      {
        id: '1',
        type: 'success',
        title: 'Servidor Online',
        message: 'Legend Roleplay está funcionando perfeitamente',
        timestamp: new Date(Date.now() - 5 * 60000),
        read: false
      },
      {
        id: '2',
        type: 'info',
        title: 'Nova Atualização',
        message: 'Versão 2.1.0 disponível com novos sistemas',
        timestamp: new Date(Date.now() - 15 * 60000),
        read: false
      },
      {
        id: '3',
        type: 'warning',
        title: 'Manutenção Programada',
        message: 'Manutenção do servidor em 24 horas',
        timestamp: new Date(Date.now() - 30 * 60000),
        read: true
      },
      {
        id: '4',
        type: 'success',
        title: 'Novo Jogador',
        message: 'Bem-vindo ao servidor Legend Roleplay!',
        timestamp: new Date(Date.now() - 60 * 60000),
        read: true
      }
    ];

    // Carregar notificações criadas pela staff
    const staffNotificationsStored = localStorage.getItem('legend_notifications');
    let staffNotifications: Notification[] = [];
    
    if (staffNotificationsStored) {
      try {
        const parsed = JSON.parse(staffNotificationsStored);
        staffNotifications = parsed.map((notif: any) => ({
          id: notif.id,
          type: 'info' as const,
          title: notif.title,
          message: notif.description,
          timestamp: new Date(notif.createdAt),
          read: false,
          createdBy: notif.createdBy,
          image: notif.image,
          video: notif.video
        }));
      } catch (err) {
        console.error('Erro ao carregar notificações da staff:', err);
      }
    }

    // Combinar e ordenar por timestamp (mais recentes primeiro)
    const allNotifications = [...staffNotifications, ...mockNotifications].sort((a, b) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );

    setNotifications(allNotifications);
    setUnreadCount(allNotifications.filter(n => !n.read).length);
  };

  const getIcon = (type: string) => {
    switch(type) {
      case 'success': return <CheckCircle className="text-green-400" size={20} />;
      case 'error': return <AlertCircle className="text-red-400" size={20} />;
      case 'warning': return <AlertTriangle className="text-yellow-400" size={20} />;
      default: return <Info className="text-blue-400" size={20} />;
    }
  };

  const getColorClass = (type: string) => {
    switch(type) {
      case 'success': return 'bg-green-500/10 border-green-500/30';
      case 'error': return 'bg-red-500/10 border-red-500/30';
      case 'warning': return 'bg-yellow-500/10 border-yellow-500/30';
      default: return 'bg-blue-500/10 border-blue-500/30';
    }
  };

  const markAsRead = (id: string) => {
    setNotifications(notifications.map(n => 
      n.id === id ? { ...n, read: true } : n
    ));
    setUnreadCount(prev => Math.max(0, prev - 1));
  };

  const deleteNotification = (id: string) => {
    const updated = notifications.filter(n => n.id !== id);
    setNotifications(updated);
    
    // Se for notificação da staff, remover também do localStorage
    const staffNotificationsStored = localStorage.getItem('legend_notifications');
    if (staffNotificationsStored) {
      try {
        const parsed = JSON.parse(staffNotificationsStored);
        const filtered = parsed.filter((notif: any) => notif.id !== id);
        localStorage.setItem('legend_notifications', JSON.stringify(filtered));
      } catch (err) {
        console.error('Erro ao deletar notificação:', err);
      }
    }
  };

  const formatTime = (date: Date) => {
    const now = new Date();
    const diff = now.getTime() - new Date(date).getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    
    if (minutes < 1) return 'Agora';
    if (minutes < 60) return `${minutes}m atrás`;
    if (hours < 24) return `${hours}h atrás`;
    return new Date(date).toLocaleDateString('pt-BR');
  };

  return (
    <div className="fixed bottom-6 right-6 z-50">
      {/* Notification Bell Button */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="relative bg-gradient-to-br from-blue-600 to-blue-800 hover:from-blue-500 hover:to-blue-700 text-white rounded-full p-4 shadow-lg shadow-blue-600/50 transition-all duration-300 hover:scale-110"
      >
        <Bell size={24} />
        {unreadCount > 0 && (
          <div className="absolute -top-2 -right-2 bg-red-500 text-white text-xs font-black rounded-full w-6 h-6 flex items-center justify-center animate-pulse">
            {unreadCount}
          </div>
        )}
      </button>

      {/* Notification Panel */}
      {isOpen && (
        <div className="absolute bottom-20 right-0 w-96 max-h-96 bg-slate-900 border border-blue-500/30 rounded-2xl shadow-2xl overflow-hidden animate-in slide-in-from-bottom-4 duration-300">
          {/* Header */}
          <div className="bg-gradient-to-r from-blue-600/20 to-indigo-600/20 border-b border-blue-500/20 px-6 py-4 flex justify-between items-center">
            <h3 className="text-white font-bold uppercase text-sm tracking-widest">Notificações</h3>
            <button 
              onClick={() => setIsOpen(false)}
              className="text-slate-400 hover:text-white transition-colors"
            >
              <X size={20} />
            </button>
          </div>

          {/* Notifications List */}
          <div className="overflow-y-auto max-h-80">
            {notifications.length === 0 ? (
              <div className="p-8 text-center text-slate-400">
                <Bell size={32} className="mx-auto mb-2 opacity-50" />
                <p className="text-sm">Nenhuma notificação</p>
              </div>
            ) : (
              notifications.map(notification => (
                <div
                  key={notification.id}
                  className={`border-b border-slate-800/50 p-4 hover:bg-white/5 transition-colors ${
                    !notification.read ? 'bg-blue-500/5' : ''
                  }`}
                >
                  {/* Imagem ou Vídeo da Notificação */}
                  {notification.image && (
                    <img 
                      src={notification.image} 
                      alt={notification.title}
                      className="w-full rounded-lg mb-3 max-h-32 object-cover border border-blue-500/20"
                    />
                  )}
                  {notification.video && (
                    <video 
                      src={notification.video}
                      controls
                      className="w-full rounded-lg mb-3 max-h-32 object-cover border border-blue-500/20"
                    />
                  )}

                  <div className="flex gap-3">
                    <div className="flex-shrink-0 mt-1">
                      {getIcon(notification.type)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-white font-bold text-sm">{notification.title}</p>
                      <p className="text-slate-400 text-xs mt-1">{notification.message}</p>
                      {notification.createdBy && (
                        <p className="text-slate-500 text-xs mt-1">Por: <span className="text-blue-400 font-bold">{notification.createdBy}</span></p>
                      )}
                      <p className="text-slate-500 text-xs mt-2">{formatTime(notification.timestamp)}</p>
                    </div>
                    <button
                      onClick={() => deleteNotification(notification.id)}
                      className="flex-shrink-0 text-slate-500 hover:text-red-400 transition-colors"
                    >
                      <X size={16} />
                    </button>
                  </div>
                  {!notification.read && (
                    <button
                      onClick={() => markAsRead(notification.id)}
                      className="mt-2 text-xs text-blue-400 hover:text-blue-300 font-bold uppercase"
                    >
                      Marcar como lido
                    </button>
                  )}
                </div>
              ))
            )}
          </div>

          {/* Footer */}
          {notifications.length > 0 && (
            <div className="border-t border-slate-800/50 px-6 py-3 text-center">
              <button className="text-xs text-blue-400 hover:text-blue-300 font-bold uppercase">
                Ver todas as notificações
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default NotificationCenter;
