
import React, { useState, useEffect } from 'react';
import { SERVER_INFO } from '../constants';
import { Menu, X, User, LogOut, LayoutDashboard, MessageSquare, Settings, Home, BookOpen, TrendingUp, Search } from 'lucide-react';

interface HeaderProps {
  onNavigate: (view: string) => void;
  currentView: string;
  user: any;
  unreadMessages: number;
  onLoginClick: () => void;
  onLogout: () => void;
}

const Header: React.FC<HeaderProps> = ({ onNavigate, currentView, user, unreadMessages, onLoginClick, onLogout }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);

  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleLinkClick = (id: string, type: string) => {
    setIsMobileMenuOpen(false);
    setShowUserMenu(false);
    if (type === 'view') {
      onNavigate(id);
    } else {
      onNavigate('home');
      setTimeout(() => {
        const el = document.getElementById(id);
        if (el) el.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    }
  };

  const navItems = [
    { name: 'Início', id: 'home', icon: Home, type: 'view' },
    { name: 'Sobre', id: 'about', icon: BookOpen, type: 'anchor' },
    { name: 'Fórum', id: 'forum', icon: MessageSquare, type: 'view' },
    { name: 'Buscar', id: 'player-search', icon: Search, type: 'view' },
    { name: 'Ranking', id: 'ranking', icon: TrendingUp, type: 'view' },
  ];

  return (
    <header className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
      isScrolled || currentView !== 'home' ? 'bg-slate-950/95 backdrop-blur-md py-2 border-b border-blue-500/30' : 'bg-transparent py-4'
    }`}>
      <div className="container mx-auto px-4 md:px-8 flex items-center justify-between">
        {/* Logo */}
        <button onClick={() => handleLinkClick('home', 'view')} className="flex items-center gap-4 group">
          <img src={SERVER_INFO.logoUrl} alt="Logo" className="h-12 w-auto object-contain drop-shadow-[0_0_10px_rgba(59,130,246,0.4)]" />
          <span className="font-orbitron font-bold text-xl tracking-tighter text-blue-500 hidden sm:block">LEGEND <span className="text-white">RP</span></span>
        </button>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center gap-8">
          {navItems.map((item) => (
            <button
              key={item.id}
              onClick={() => handleLinkClick(item.id, item.type)}
              className={`font-medium transition-colors uppercase tracking-widest text-xs flex items-center gap-2 ${
                currentView === item.id ? 'text-blue-500' : 'text-slate-300 hover:text-blue-500'
              }`}
            >
              <item.icon size={16} />
              {item.name}
            </button>
          ))}

          {user ? (
            <div className="flex items-center gap-6 pl-6 border-l border-white/10 relative">
              <button onClick={() => onNavigate('chat')} className="relative p-2 text-slate-400 hover:text-blue-500 transition-colors">
                <MessageSquare size={20} />
                {unreadMessages > 0 && <span className="absolute top-0 right-0 w-3 h-3 bg-blue-600 rounded-full border-2 border-slate-950 animate-pulse"></span>}
              </button>

              <div className="relative">
                <button onClick={() => setShowUserMenu(!showUserMenu)} className="flex items-center gap-3 group">
                  <div className="text-right">
                    <p className="text-[10px] text-slate-500 uppercase font-bold">Jogador</p>
                    <p className="text-xs font-bold text-white uppercase">{user.username || user.name}</p>
                  </div>
                  <div className="w-10 h-10 rounded-xl overflow-hidden border-2 border-blue-500/30 group-hover:border-blue-500 transition-all">
                    {user.avatar ? <img src={user.avatar} className="w-full h-full object-cover" /> : <div className="w-full h-full bg-slate-800 flex items-center justify-center text-slate-500"><User size={20} /></div>}
                  </div>
                </button>

                {showUserMenu && (
                  <div className="absolute right-0 mt-4 w-56 bg-slate-900 border border-white/10 rounded-2xl shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
                    {(user.role === 'admin' || user.role === 'staff') && (
                      <button onClick={() => { onNavigate('admin'); setShowUserMenu(false); }} className="w-full flex items-center gap-3 px-6 py-4 text-xs font-bold uppercase tracking-widest text-amber-500 hover:bg-white/5 transition-all">
                        <LayoutDashboard size={16} /> Painel Staff
                      </button>
                    )}
                    <button onClick={() => { onNavigate('settings'); setShowUserMenu(false); }} className="w-full flex items-center gap-3 px-6 py-4 text-xs font-bold uppercase tracking-widest text-slate-300 hover:bg-white/5 transition-all">
                      <Settings size={16} /> Configurações
                    </button>
                    <button onClick={() => { onLogout(); setShowUserMenu(false); }} className="w-full flex items-center gap-3 px-6 py-4 text-xs font-bold uppercase tracking-widest text-red-500 hover:bg-red-500/5 transition-all border-t border-white/5">
                      <LogOut size={16} /> Deslogar
                    </button>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <button onClick={onLoginClick} className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-lg font-bold transition-all shadow-lg hover:shadow-blue-500/40 uppercase text-xs tracking-widest border border-blue-400/30 flex items-center gap-2">
              <User size={14} /> Entrar
            </button>
          )}
        </nav>

        {/* Mobile Menu Button & User Avatar */}
        <div className="lg:hidden flex items-center gap-4">
          {user && (
            <button onClick={() => onNavigate('chat')} className="relative p-2 text-slate-400 hover:text-blue-500 transition-colors">
              <MessageSquare size={20} />
              {unreadMessages > 0 && <span className="absolute top-0 right-0 w-2 h-2 bg-blue-600 rounded-full border border-slate-950"></span>}
            </button>
          )}
          <button
            className="lg:hidden text-white p-2 hover:bg-white/10 rounded-lg transition-colors"
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu - Slide from Right */}
      {isMobileMenuOpen && (
        <>
          {/* Overlay */}
          <div
            className="lg:hidden fixed inset-0 bg-black/50 backdrop-blur-sm z-40"
            onClick={() => setIsMobileMenuOpen(false)}
          />
          
          {/* Menu Panel */}
          <div className="lg:hidden fixed top-0 right-0 h-screen w-80 bg-gradient-to-b from-slate-900 to-slate-950 border-l border-blue-500/30 z-40 overflow-y-auto animate-in slide-in-from-right duration-300">
            <div className="p-6">
              {/* Menu Header */}
              <div className="flex items-center justify-between mb-8">
                <h3 className="text-xl font-orbitron font-bold text-blue-500">Menu</h3>
                <button
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="p-2 hover:bg-white/10 rounded-lg transition-colors"
                >
                  <X size={20} />
                </button>
              </div>

              {/* Navigation Items */}
              <nav className="space-y-2 mb-8">
                {navItems.map((item) => (
                  <button
                    key={item.id}
                    onClick={() => handleLinkClick(item.id, item.type)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-all uppercase text-xs font-bold tracking-widest ${
                      currentView === item.id
                        ? 'bg-blue-600/20 text-blue-400 border border-blue-500/30'
                        : 'text-slate-300 hover:bg-white/5'
                    }`}
                  >
                    <item.icon size={18} />
                    {item.name}
                  </button>
                ))}
              </nav>

              {/* Divider */}
              <div className="h-px bg-gradient-to-r from-transparent via-blue-500/30 to-transparent mb-8" />

              {/* User Section */}
              {user ? (
                <div className="space-y-3">
                  <div className="bg-slate-800/50 border border-blue-500/20 rounded-lg p-4 mb-4">
                    <p className="text-[10px] text-slate-500 uppercase font-bold mb-1">Conectado como</p>
                    <p className="text-sm font-bold text-white uppercase">{user.username || user.name}</p>
                  </div>

                  {(user.role === 'admin' || user.role === 'staff') && (
                    <button
                      onClick={() => { onNavigate('admin'); setIsMobileMenuOpen(false); }}
                      className="w-full flex items-center gap-3 px-4 py-3 rounded-lg bg-amber-600/10 text-amber-400 hover:bg-amber-600/20 transition-all uppercase text-xs font-bold tracking-widest border border-amber-500/30"
                    >
                      <LayoutDashboard size={18} />
                      Painel Staff
                    </button>
                  )}

                  <button
                    onClick={() => { onNavigate('settings'); setIsMobileMenuOpen(false); }}
                    className="w-full flex items-center gap-3 px-4 py-3 rounded-lg hover:bg-white/5 transition-all uppercase text-xs font-bold tracking-widest text-slate-300"
                  >
                    <Settings size={18} />
                    Configurações
                  </button>

                  <button
                    onClick={() => { onLogout(); setIsMobileMenuOpen(false); }}
                    className="w-full flex items-center gap-3 px-4 py-3 rounded-lg bg-red-600/10 text-red-400 hover:bg-red-600/20 transition-all uppercase text-xs font-bold tracking-widest border border-red-500/30"
                  >
                    <LogOut size={18} />
                    Deslogar
                  </button>
                </div>
              ) : (
                <button
                  onClick={() => { onLoginClick(); setIsMobileMenuOpen(false); }}
                  className="w-full flex items-center justify-center gap-2 px-4 py-3 rounded-lg bg-blue-600 hover:bg-blue-700 transition-all uppercase text-xs font-bold tracking-widest text-white border border-blue-400/30"
                >
                  <User size={18} />
                  Entrar / Registrar
                </button>
              )}
            </div>
          </div>
        </>
      )}
    </header>
  );
};

export default Header;
