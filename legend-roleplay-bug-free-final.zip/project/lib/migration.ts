/**
 * Script de Migração - Correção de IDs de Usuários
 * 
 * Este script corrige os IDs dos usuários existentes no banco de dados,
 * garantindo que todos tenham userIds sequenciais válidos.
 */

import { legendDB } from './database';

export async function migrateUserIds(): Promise<void> {
  console.log('🔄 Iniciando migração de IDs de usuários...');
  
  try {
    await legendDB.init();
    const allUsers = await legendDB.getAllUsers();
    
    console.log(`📊 Total de usuários encontrados: ${allUsers.length}`);
    
    let migratedCount = 0;
    let startId = 1000;
    
    // Primeiro, identificar IDs válidos existentes
    const validUserIds = allUsers
      .map(u => parseInt(u.userId))
      .filter(id => !isNaN(id) && id >= 1000);
    
    if (validUserIds.length > 0) {
      startId = Math.max(...validUserIds) + 1;
    }
    
    console.log(`🔢 Próximo ID disponível: ${startId}`);
    
    // Migrar usuários com IDs inválidos
    for (const user of allUsers) {
      const userId = parseInt(user.userId);
      
      // Verificar se o userId é inválido (timestamp, NaN, ou menor que 1000)
      const isInvalidId = isNaN(userId) || userId > 9999999999 || (userId < 1000 && userId > 10);
      
      if (isInvalidId) {
        try {
          const newUserId = String(startId);
          await legendDB.updateUser(user.id, { userId: newUserId });
          console.log(`✅ Migrado: ${user.username} | ${user.userId} → ${newUserId}`);
          startId++;
          migratedCount++;
        } catch (error) {
          console.error(`❌ Erro ao migrar ${user.username}:`, error);
        }
      }
    }
    
    console.log(`✨ Migração concluída! ${migratedCount} usuários atualizados.`);
    
    // Exibir estatísticas finais
    const updatedUsers = await legendDB.getAllUsers();
    const stats = {
      total: updatedUsers.length,
      admins: updatedUsers.filter(u => u.role === 'admin').length,
      users: updatedUsers.filter(u => u.role === 'user').length,
      validIds: updatedUsers.filter(u => {
        const id = parseInt(u.userId);
        return !isNaN(id) && id >= 1000;
      }).length
    };
    
    console.log('📈 Estatísticas finais:', stats);
    
  } catch (error) {
    console.error('❌ Erro durante a migração:', error);
    throw error;
  }
}

/**
 * Função para executar a migração automaticamente ao carregar a página
 */
export async function autoMigrate(): Promise<void> {
  const migrationKey = 'legend_migration_v1_completed';
  const migrationCompleted = localStorage.getItem(migrationKey);
  
  if (!migrationCompleted) {
    console.log('🚀 Executando migração automática...');
    try {
      await migrateUserIds();
      localStorage.setItem(migrationKey, 'true');
      console.log('✅ Migração automática concluída!');
    } catch (error) {
      console.error('❌ Falha na migração automática:', error);
    }
  } else {
    console.log('✓ Migração já foi executada anteriormente.');
  }
}
