
/**
 * Sistema de Segurança Extraordinária para Contas Administrativas
 * Proteção contra ataques brutos, força bruta, e atividades suspeitas
 */

export interface SecurityEvent {
  id: string;
  timestamp: Date;
  type: 'login_attempt' | 'code_edit' | 'failed_auth' | 'ip_change' | 'suspicious_activity';
  username: string;
  ipAddress: string;
  userAgent: string;
  status: 'success' | 'failed' | 'blocked';
  details?: string;
}

export interface TwoFactorAuth {
  enabled: boolean;
  secret?: string;
  backupCodes: string[];
  createdAt: Date;
}

export interface AdminSecurityProfile {
  username: string;
  passwordHash: string;
  twoFactorAuth: TwoFactorAuth;
  trustedDevices: string[];
  loginAttempts: number;
  lastLoginIP: string;
  lastLoginTime: Date;
  isLocked: boolean;
  lockUntil?: Date;
  securityEvents: SecurityEvent[];
}

class AdvancedSecurityManager {
  private maxLoginAttempts = 3;
  private lockoutDuration = 30 * 60 * 1000; // 30 minutos
  private suspiciousActivityThreshold = 5;
  private ipChangeThreshold = 3;

  /**
   * Gera código 2FA (TOTP)
   */
  generateTOTPSecret(): string {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';
    let secret = '';
    for (let i = 0; i < 32; i++) {
      secret += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return secret;
  }

  /**
   * Gera códigos de backup para 2FA
   */
  generateBackupCodes(count: number = 10): string[] {
    const codes: string[] = [];
    for (let i = 0; i < count; i++) {
      const code = Math.random().toString(36).substring(2, 10).toUpperCase();
      codes.push(code);
    }
    return codes;
  }

  /**
   * Valida tentativa de login com rate limiting
   */
  validateLoginAttempt(profile: AdminSecurityProfile, ipAddress: string): {
    allowed: boolean;
    reason?: string;
  } {
    // Verificar se conta está bloqueada
    if (profile.isLocked && profile.lockUntil) {
      if (new Date() < profile.lockUntil) {
        return {
          allowed: false,
          reason: `Conta bloqueada. Tente novamente em ${Math.ceil((profile.lockUntil.getTime() - Date.now()) / 60000)} minutos.`
        };
      }
      profile.isLocked = false;
      profile.lockUntil = undefined;
    }

    // Verificar mudança de IP suspeita
    if (profile.lastLoginIP !== ipAddress) {
      const recentEvents = profile.securityEvents.filter(
        e => e.timestamp.getTime() > Date.now() - 24 * 60 * 60 * 1000
      );
      const ipChanges = recentEvents.filter(e => e.type === 'ip_change').length;
      
      if (ipChanges > this.ipChangeThreshold) {
        return {
          allowed: false,
          reason: 'Múltiplas mudanças de IP detectadas. Atividade suspeita bloqueada.'
        };
      }
    }

    // Verificar tentativas de login falhadas
    if (profile.loginAttempts >= this.maxLoginAttempts) {
      profile.isLocked = true;
      profile.lockUntil = new Date(Date.now() + this.lockoutDuration);
      return {
        allowed: false,
        reason: `Muitas tentativas falhadas. Conta bloqueada por ${this.lockoutDuration / 60000} minutos.`
      };
    }

    return { allowed: true };
  }

  /**
   * Registra evento de segurança
   */
  recordSecurityEvent(
    profile: AdminSecurityProfile,
    type: SecurityEvent['type'],
    ipAddress: string,
    userAgent: string,
    status: 'success' | 'failed' | 'blocked',
    details?: string
  ): void {
    const event: SecurityEvent = {
      id: `evt_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      timestamp: new Date(),
      type,
      username: profile.username,
      ipAddress,
      userAgent,
      status,
      details
    };

    profile.securityEvents.push(event);

    // Manter apenas últimos 1000 eventos
    if (profile.securityEvents.length > 1000) {
      profile.securityEvents = profile.securityEvents.slice(-1000);
    }

    // Salvar no localStorage
    const profiles = JSON.parse(localStorage.getItem('admin_security_profiles') || '{}');
    profiles[profile.username] = profile;
    localStorage.setItem('admin_security_profiles', JSON.stringify(profiles));
  }

  /**
   * Detecta atividade suspeita
   */
  detectSuspiciousActivity(profile: AdminSecurityProfile): {
    suspicious: boolean;
    reason?: string;
  } {
    const recentEvents = profile.securityEvents.filter(
      e => e.timestamp.getTime() > Date.now() - 60 * 60 * 1000 // Última hora
    );

    // Muitas tentativas falhadas
    const failedAttempts = recentEvents.filter(e => e.status === 'failed').length;
    if (failedAttempts > this.suspiciousActivityThreshold) {
      return {
        suspicious: true,
        reason: 'Muitas tentativas de login falhadas detectadas'
      };
    }

    // Múltiplos IPs em pouco tempo
    const uniqueIPs = new Set(recentEvents.map(e => e.ipAddress)).size;
    if (uniqueIPs > 3) {
      return {
        suspicious: true,
        reason: 'Múltiplos IPs em pouco tempo'
      };
    }

    // Edições de código suspeitas
    const codeEdits = recentEvents.filter(e => e.type === 'code_edit').length;
    if (codeEdits > 10) {
      return {
        suspicious: true,
        reason: 'Muitas edições de código em pouco tempo'
      };
    }

    return { suspicious: false };
  }

  /**
   * Criptografa senha (simples - em produção usar bcrypt)
   */
  hashPassword(password: string): string {
    let hash = 0;
    for (let i = 0; i < password.length; i++) {
      const char = password.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return Math.abs(hash).toString(16);
  }

  /**
   * Verifica força da senha
   */
  validatePasswordStrength(password: string): {
    strong: boolean;
    score: number;
    issues: string[];
  } {
    const issues: string[] = [];
    let score = 0;

    if (password.length >= 12) score += 2;
    else if (password.length >= 8) score += 1;
    else issues.push('Mínimo 8 caracteres');

    if (/[A-Z]/.test(password)) score += 1;
    else issues.push('Inclua letras maiúsculas');

    if (/[a-z]/.test(password)) score += 1;
    else issues.push('Inclua letras minúsculas');

    if (/[0-9]/.test(password)) score += 1;
    else issues.push('Inclua números');

    if (/[!@#$%^&*]/.test(password)) score += 2;
    else issues.push('Inclua caracteres especiais');

    return {
      strong: score >= 6 && issues.length === 0,
      score,
      issues
    };
  }

  /**
   * Gera token de sessão seguro
   */
  generateSecureToken(): string {
    const array = new Uint8Array(32);
    crypto.getRandomValues(array);
    return Array.from(array, byte => byte.toString(16).padStart(2, '0')).join('');
  }

  /**
   * Obtém informações do dispositivo
   */
  getDeviceFingerprint(): string {
    const navigator_obj = window.navigator;
    const screen_obj = window.screen;
    
    const fingerprint = [
      navigator_obj.userAgent,
      navigator_obj.language,
      screen_obj.width + 'x' + screen_obj.height,
      new Date().getTimezoneOffset(),
    ].join('|');

    return this.hashPassword(fingerprint);
  }

  /**
   * Cria perfil de segurança para novo admin
   */
  createAdminSecurityProfile(username: string, password: string): AdminSecurityProfile {
    return {
      username,
      passwordHash: this.hashPassword(password),
      twoFactorAuth: {
        enabled: false,
        backupCodes: this.generateBackupCodes(),
        createdAt: new Date()
      },
      trustedDevices: [this.getDeviceFingerprint()],
      loginAttempts: 0,
      lastLoginIP: 'unknown',
      lastLoginTime: new Date(),
      isLocked: false,
      securityEvents: []
    };
  }
}

export const advancedSecurityManager = new AdvancedSecurityManager();
