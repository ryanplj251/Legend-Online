/**
 * Sistema de Segurança - Legend Roleplay
 * Proteção contra ataques e gerenciamento de sessões
 */

export interface SecurityLog {
  id: string;
  timestamp: Date;
  type: 'login_attempt' | 'login_success' | 'login_failed' | 'logout' | 'suspicious_activity' | 'brute_force_detected' | 'ip_blocked';
  username?: string;
  ip: string;
  userAgent?: string;
  details?: string;
}

export interface IPBlocklist {
  ip: string;
  reason: string;
  blockedAt: Date;
  unblockAt?: Date;
  attempts: number;
}

export interface SessionRecord {
  sessionId: string;
  username: string;
  ip: string;
  userAgent: string;
  loginTime: Date;
  lastActivityTime: Date;
  logoutTime?: Date;
  isActive: boolean;
}

class SecurityManager {
  private dbName = 'LegendSecurityDB';
  private securityStoreName = 'security_logs';
  private blocklistStoreName = 'ip_blocklist';
  private sessionStoreName = 'sessions';
  private version = 1;
  private db: IDBDatabase | null = null;

  // Configurações de segurança
  private MAX_LOGIN_ATTEMPTS = 5;
  private ATTEMPT_WINDOW = 15 * 60 * 1000; // 15 minutos
  private BLOCK_DURATION = 60 * 60 * 1000; // 1 hora
  private SESSION_TIMEOUT = 30 * 60 * 1000; // 30 minutos
  private CSRF_TOKEN_EXPIRY = 24 * 60 * 60 * 1000; // 24 horas

  async init(): Promise<void> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, this.version);

      request.onerror = () => {
        console.error('Erro ao abrir banco de segurança');
        reject(request.error);
      };

      request.onsuccess = () => {
        this.db = request.result;
        console.log('Banco de segurança inicializado');
        resolve();
      };

      request.onupgradeneeded = (event: any) => {
        const db = event.target.result;

        if (!db.objectStoreNames.contains(this.securityStoreName)) {
          db.createObjectStore(this.securityStoreName, { keyPath: 'id' });
        }

        if (!db.objectStoreNames.contains(this.blocklistStoreName)) {
          const blocklistStore = db.createObjectStore(this.blocklistStoreName, { keyPath: 'ip' });
          blocklistStore.createIndex('blockedAt', 'blockedAt', { unique: false });
        }

        if (!db.objectStoreNames.contains(this.sessionStoreName)) {
          const sessionStore = db.createObjectStore(this.sessionStoreName, { keyPath: 'sessionId' });
          sessionStore.createIndex('username', 'username', { unique: false });
          sessionStore.createIndex('ip', 'ip', { unique: false });
        }
      };
    });
  }

  /**
   * Gera um CSRF token
   */
  generateCSRFToken(): string {
    const token = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
    const expiryTime = Date.now() + this.CSRF_TOKEN_EXPIRY;
    localStorage.setItem('csrf_token', token);
    localStorage.setItem('csrf_token_expiry', expiryTime.toString());
    return token;
  }

  /**
   * Valida CSRF token
   */
  validateCSRFToken(token: string): boolean {
    const storedToken = localStorage.getItem('csrf_token');
    const expiryTime = parseInt(localStorage.getItem('csrf_token_expiry') || '0');

    if (!storedToken || storedToken !== token) {
      return false;
    }

    if (Date.now() > expiryTime) {
      localStorage.removeItem('csrf_token');
      localStorage.removeItem('csrf_token_expiry');
      return false;
    }

    return true;
  }

  /**
   * Verifica se um IP está bloqueado
   */
  async isIPBlocked(ip: string): Promise<boolean> {
    if (!this.db) return false;

    return new Promise((resolve) => {
      const transaction = this.db!.transaction([this.blocklistStoreName], 'readonly');
      const store = transaction.objectStore(this.blocklistStoreName);
      const request = store.get(ip);

      request.onsuccess = () => {
        const blocklist = request.result;
        if (!blocklist) {
          resolve(false);
          return;
        }

        // Verificar se o bloqueio expirou
        if (blocklist.unblockAt && new Date(blocklist.unblockAt) < new Date()) {
          // Remover bloqueio expirado
          const deleteRequest = store.delete(ip);
          deleteRequest.onsuccess = () => resolve(false);
        } else {
          resolve(true);
        }
      };
    });
  }

  /**
   * Bloqueia um IP
   */
  async blockIP(ip: string, reason: string, duration?: number): Promise<void> {
    if (!this.db) return;

    const blockDuration = duration || this.BLOCK_DURATION;
    const blocklistEntry: IPBlocklist = {
      ip,
      reason,
      blockedAt: new Date(),
      unblockAt: new Date(Date.now() + blockDuration),
      attempts: 0
    };

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([this.blocklistStoreName], 'readwrite');
      const store = transaction.objectStore(this.blocklistStoreName);
      const request = store.put(blocklistEntry);

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  /**
   * Registra tentativa de login
   */
  async logLoginAttempt(username: string, ip: string, success: boolean, userAgent?: string): Promise<void> {
    if (!this.db) return;

    const log: SecurityLog = {
      id: `${Date.now()}-${Math.random()}`,
      timestamp: new Date(),
      type: success ? 'login_success' : 'login_failed',
      username,
      ip,
      userAgent,
      details: success ? 'Login bem-sucedido' : 'Falha na autenticação'
    };

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([this.securityStoreName], 'readwrite');
      const store = transaction.objectStore(this.securityStoreName);
      const request = store.add(log);

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  /**
   * Verifica força bruta
   */
  async checkBruteForce(ip: string): Promise<boolean> {
    if (!this.db) return false;

    return new Promise((resolve) => {
      const transaction = this.db!.transaction([this.securityStoreName], 'readonly');
      const store = transaction.objectStore(this.securityStoreName);
      const allRecords = store.getAll();

      allRecords.onsuccess = () => {
        const records = allRecords.result as SecurityLog[];
        const now = Date.now();
        const windowStart = now - this.ATTEMPT_WINDOW;

        const failedAttempts = records.filter(
          r => r.ip === ip &&
               r.type === 'login_failed' &&
               new Date(r.timestamp).getTime() > windowStart
        ).length;

        resolve(failedAttempts >= this.MAX_LOGIN_ATTEMPTS);
      };
    });
  }

  /**
   * Cria uma nova sessão
   */
  async createSession(username: string, ip: string, userAgent: string): Promise<SessionRecord> {
    if (!this.db) throw new Error('Database not initialized');

    const sessionId = `${Date.now()}-${Math.random().toString(36).substring(7)}`;
    const session: SessionRecord = {
      sessionId,
      username,
      ip,
      userAgent,
      loginTime: new Date(),
      lastActivityTime: new Date(),
      isActive: true
    };

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([this.sessionStoreName], 'readwrite');
      const store = transaction.objectStore(this.sessionStoreName);
      const request = store.add(session);

      request.onsuccess = () => {
        localStorage.setItem('session_id', sessionId);
        localStorage.setItem('session_ip', ip);
        localStorage.setItem('session_start', Date.now().toString());
        resolve(session);
      };
      request.onerror = () => reject(request.error);
    });
  }

  /**
   * Encerra uma sessão
   */
  async endSession(sessionId: string): Promise<void> {
    if (!this.db) return;

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([this.sessionStoreName], 'readwrite');
      const store = transaction.objectStore(this.sessionStoreName);
      const request = store.get(sessionId);

      request.onsuccess = () => {
        const session = request.result;
        if (session) {
          session.isActive = false;
          session.logoutTime = new Date();
          const updateRequest = store.put(session);
          updateRequest.onsuccess = () => {
            localStorage.removeItem('session_id');
            localStorage.removeItem('session_ip');
            localStorage.removeItem('session_start');
            resolve();
          };
          updateRequest.onerror = () => reject(updateRequest.error);
        } else {
          resolve();
        }
      };
    });
  }

  /**
   * Valida sessão
   */
  async validateSession(sessionId: string, ip: string): Promise<boolean> {
    if (!this.db) return false;

    return new Promise((resolve) => {
      const transaction = this.db!.transaction([this.sessionStoreName], 'readonly');
      const store = transaction.objectStore(this.sessionStoreName);
      const request = store.get(sessionId);

      request.onsuccess = () => {
        const session = request.result;
        if (!session || !session.isActive) {
          resolve(false);
          return;
        }

        // Verificar IP
        if (session.ip !== ip) {
          resolve(false);
          return;
        }

        // Verificar timeout
        const lastActivity = new Date(session.lastActivityTime).getTime();
        const now = Date.now();
        if (now - lastActivity > this.SESSION_TIMEOUT) {
          resolve(false);
          return;
        }

        resolve(true);
      };
    });
  }

  /**
   * Atualiza última atividade da sessão
   */
  async updateSessionActivity(sessionId: string): Promise<void> {
    if (!this.db) return;

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([this.sessionStoreName], 'readwrite');
      const store = transaction.objectStore(this.sessionStoreName);
      const request = store.get(sessionId);

      request.onsuccess = () => {
        const session = request.result;
        if (session) {
          session.lastActivityTime = new Date();
          const updateRequest = store.put(session);
          updateRequest.onsuccess = () => resolve();
          updateRequest.onerror = () => reject(updateRequest.error);
        } else {
          resolve();
        }
      };
    });
  }

  /**
   * Obtém todos os logs de segurança
   */
  async getSecurityLogs(limit: number = 1000): Promise<SecurityLog[]> {
    if (!this.db) return [];

    return new Promise((resolve) => {
      const transaction = this.db!.transaction([this.securityStoreName], 'readonly');
      const store = transaction.objectStore(this.securityStoreName);
      const request = store.getAll();

      request.onsuccess = () => {
        const logs = (request.result as SecurityLog[]).sort(
          (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
        ).slice(0, limit);
        resolve(logs);
      };
    });
  }

  /**
   * Sanitiza entrada para evitar XSS
   */
  sanitizeInput(input: string): string {
    const div = document.createElement('div');
    div.textContent = input;
    return div.innerHTML;
  }

  /**
   * Valida formato de email
   */
  validateEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  /**
   * Valida força da senha
   */
  validatePasswordStrength(password: string): { strong: boolean; score: number; issues: string[] } {
    const issues: string[] = [];
    let score = 0;

    if (password.length < 8) {
      issues.push('Mínimo de 8 caracteres');
    } else {
      score += 1;
    }

    if (!/[A-Z]/.test(password)) {
      issues.push('Deve conter letras maiúsculas');
    } else {
      score += 1;
    }

    if (!/[a-z]/.test(password)) {
      issues.push('Deve conter letras minúsculas');
    } else {
      score += 1;
    }

    if (!/[0-9]/.test(password)) {
      issues.push('Deve conter números');
    } else {
      score += 1;
    }

    if (!/[!@#$%^&*]/.test(password)) {
      issues.push('Deve conter caracteres especiais (!@#$%^&*)');
    } else {
      score += 1;
    }

    return {
      strong: score >= 4,
      score,
      issues
    };
  }

  /**
   * Gera hash simples (para fins de demonstração - usar bcrypt em produção)
   */
  hashPassword(password: string): string {
    let hash = 0;
    for (let i = 0; i < password.length; i++) {
      const char = password.charCodeAt(i);
      hash = ((hash << 5) - hash) + char;
      hash = hash & hash;
    }
    return Math.abs(hash).toString(16);
  }

  /**
   * Obtém informações do User Agent
   */
  getUserAgentInfo(): string {
    return navigator.userAgent;
  }

  /**
   * Detecta atividade suspeita
   */
  async detectSuspiciousActivity(username: string, ip: string): Promise<boolean> {
    if (!this.db) return false;

    return new Promise((resolve) => {
      const transaction = this.db!.transaction([this.securityStoreName], 'readonly');
      const store = transaction.objectStore(this.securityStoreName);
      const allRecords = store.getAll();

      allRecords.onsuccess = () => {
        const records = allRecords.result as SecurityLog[];
        const now = Date.now();
        const oneHourAgo = now - 60 * 60 * 1000;

        // Verificar múltiplos logins de IPs diferentes
        const recentLogins = records.filter(
          r => r.username === username &&
               r.type === 'login_success' &&
               new Date(r.timestamp).getTime() > oneHourAgo
        );

        const uniqueIPs = new Set(recentLogins.map(r => r.ip));
        const suspicious = uniqueIPs.size > 3; // Mais de 3 IPs diferentes em 1 hora

        resolve(suspicious);
      };
    });
  }
}

export const securityManager = new SecurityManager();
