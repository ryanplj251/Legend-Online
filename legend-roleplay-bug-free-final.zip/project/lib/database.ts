/**
 * Sistema de Banco de Dados - Legend Roleplay
 * Utiliza IndexedDB para armazenamento persistente de credenciais
 * com validação de nomes únicos
 */

export interface IPLog {
  ip: string;
  timestamp: Date;
  action: 'login' | 'register';
}

export interface UserCredential {
  id: string;
  username: string;
  email: string;
  password: string;
  phone?: string;
  bio?: string;
  role: 'user' | 'staff' | 'admin';
  isFounder: boolean;
  avatar: string;
  userId: string;
  createdAt: Date;
  updatedAt: Date;
  lastLogin?: Date;
  isActive: boolean;
  registrationIP?: string;
  loginHistory?: IPLog[];
}

export interface DatabaseStats {
  totalUsers: number;
  activeUsers: number;
  totalAdmins: number;
  lastBackup: Date;
}

class LegendDatabase {
  private dbName = 'LegendRoleplayDB';
  private storeName = 'users';
  private version = 1;
  private db: IDBDatabase | null = null;

  /**
   * Inicializa o banco de dados
   */
  async init(): Promise<void> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(this.dbName, this.version);

      request.onerror = () => {
        console.error('Erro ao abrir banco de dados');
        reject(request.error);
      };

      request.onsuccess = () => {
        this.db = request.result;
        console.log('Banco de dados inicializado com sucesso');
        resolve();
      };

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;
        
        // Criar object store se não existir
        if (!db.objectStoreNames.contains(this.storeName)) {
          const objectStore = db.createObjectStore(this.storeName, { keyPath: 'id' });
          
          // Criar índices para busca rápida
          objectStore.createIndex('username', 'username', { unique: true });
          objectStore.createIndex('email', 'email', { unique: true });
          objectStore.createIndex('role', 'role', { unique: false });
          objectStore.createIndex('isActive', 'isActive', { unique: false });
          objectStore.createIndex('createdAt', 'createdAt', { unique: false });
          
          console.log('Object store criado com índices');
        }
      };
    });
  }

  /**
   * Verifica se um nome de usuário já existe
   */
  async usernameExists(username: string): Promise<boolean> {
    if (!this.db) await this.init();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([this.storeName], 'readonly');
      const objectStore = transaction.objectStore(this.storeName);
      const index = objectStore.index('username');
      const request = index.get(username);

      request.onsuccess = () => {
        resolve(!!request.result);
      };

      request.onerror = () => {
        reject(request.error);
      };
    });
  }

  /**
   * Verifica se um email já existe
   */
  async emailExists(email: string): Promise<boolean> {
    if (!this.db) await this.init();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([this.storeName], 'readonly');
      const objectStore = transaction.objectStore(this.storeName);
      const index = objectStore.index('email');
      const request = index.get(email);

      request.onsuccess = () => {
        resolve(!!request.result);
      };

      request.onerror = () => {
        reject(request.error);
      };
    });
  }

  /**
   * Gera um userId sequencial único
   */
  async generateUserId(): Promise<string> {
    if (!this.db) await this.init();
    
    const allUsers = await this.getAllUsers();
    
    // Filtrar apenas userIds numéricos válidos
    const numericUserIds = allUsers
      .map(u => parseInt(u.userId))
      .filter(id => !isNaN(id) && id > 0);
    
    // Se não houver usuários ou apenas admins com IDs fixos, começar do 1000
    if (numericUserIds.length === 0) {
      return '1000';
    }
    
    // Encontrar o maior ID e incrementar
    const maxId = Math.max(...numericUserIds);
    return String(maxId + 1);
  }

  /**
   * Adiciona um novo usuário ao banco de dados
   */
  async addUser(user: Omit<UserCredential, 'id' | 'createdAt' | 'updatedAt'>): Promise<UserCredential> {
    if (!this.db) await this.init();

    // Validar nome único
    const usernameExists = await this.usernameExists(user.username);
    if (usernameExists) {
      throw new Error(`Nome de usuário "${user.username}" já está em uso!`);
    }

    // Validar email único
    if (user.email) {
      const emailExists = await this.emailExists(user.email);
      if (emailExists) {
        throw new Error(`Email "${user.email}" já está registrado!`);
      }
    }

    // Gerar userId sequencial se não foi fornecido ou é inválido
    let userId = user.userId;
    if (!userId || userId === 'undefined' || userId === Date.now().toString()) {
      userId = await this.generateUserId();
    }

    const newUser: UserCredential = {
      ...user,
      userId,
      id: `user_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([this.storeName], 'readwrite');
      const objectStore = transaction.objectStore(this.storeName);
      const request = objectStore.add(newUser);

      request.onsuccess = () => {
        console.log(`Usuário ${user.username} adicionado com sucesso`);
        resolve(newUser);
      };

      request.onerror = () => {
        reject(request.error);
      };
    });
  }

  /**
   * Busca um usuário por nome de usuário
   */
  async getUserByUsername(username: string): Promise<UserCredential | null> {
    if (!this.db) await this.init();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([this.storeName], 'readonly');
      const objectStore = transaction.objectStore(this.storeName);
      const index = objectStore.index('username');
      const request = index.get(username);

      request.onsuccess = () => {
        resolve(request.result || null);
      };

      request.onerror = () => {
        reject(request.error);
      };
    });
  }

  /**
   * Busca um usuário por ID
   */
  async getUserById(id: string): Promise<UserCredential | null> {
    if (!this.db) await this.init();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([this.storeName], 'readonly');
      const objectStore = transaction.objectStore(this.storeName);
      const request = objectStore.get(id);

      request.onsuccess = () => {
        resolve(request.result || null);
      };

      request.onerror = () => {
        reject(request.error);
      };
    });
  }

  /**
   * Atualiza um usuário
   */
  async updateUser(id: string, updates: Partial<UserCredential>): Promise<UserCredential> {
    if (!this.db) await this.init();

    const user = await this.getUserById(id);
    if (!user) {
      throw new Error(`Usuário com ID ${id} não encontrado`);
    }

    // Se está alterando o username, verificar se já existe
    if (updates.username && updates.username !== user.username) {
      const exists = await this.usernameExists(updates.username);
      if (exists) {
        throw new Error(`Nome de usuário "${updates.username}" já está em uso!`);
      }
    }

    const updatedUser: UserCredential = {
      ...user,
      ...updates,
      updatedAt: new Date(),
    };

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([this.storeName], 'readwrite');
      const objectStore = transaction.objectStore(this.storeName);
      const request = objectStore.put(updatedUser);

      request.onsuccess = () => {
        console.log(`Usuário ${id} atualizado com sucesso`);
        resolve(updatedUser);
      };

      request.onerror = () => {
        reject(request.error);
      };
    });
  }

  /**
   * Deleta um usuário
   */
  async deleteUser(id: string): Promise<void> {
    if (!this.db) await this.init();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([this.storeName], 'readwrite');
      const objectStore = transaction.objectStore(this.storeName);
      const request = objectStore.delete(id);

      request.onsuccess = () => {
        console.log(`Usuário ${id} deletado com sucesso`);
        resolve();
      };

      request.onerror = () => {
        reject(request.error);
      };
    });
  }

  /**
   * Lista todos os usuários
   */
  async getAllUsers(): Promise<UserCredential[]> {
    if (!this.db) await this.init();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([this.storeName], 'readonly');
      const objectStore = transaction.objectStore(this.storeName);
      const request = objectStore.getAll();

      request.onsuccess = () => {
        resolve(request.result);
      };

      request.onerror = () => {
        reject(request.error);
      };
    });
  }

  /**
   * Lista usuários por role
   */
  async getUsersByRole(role: 'user' | 'staff' | 'admin'): Promise<UserCredential[]> {
    if (!this.db) await this.init();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([this.storeName], 'readonly');
      const objectStore = transaction.objectStore(this.storeName);
      const index = objectStore.index('role');
      const request = index.getAll(role);

      request.onsuccess = () => {
        resolve(request.result);
      };

      request.onerror = () => {
        reject(request.error);
      };
    });
  }

  /**
   * Obtém estatísticas do banco de dados
   */
  async getStats(): Promise<DatabaseStats> {
    if (!this.db) await this.init();

    const allUsers = await this.getAllUsers();
    const activeUsers = allUsers.filter(u => u.isActive).length;
    const admins = allUsers.filter(u => u.role === 'admin').length;

    return {
      totalUsers: allUsers.length,
      activeUsers,
      totalAdmins: admins,
      lastBackup: new Date(),
    };
  }

  /**
   * Exporta todos os dados para backup
   */
  async exportData(): Promise<string> {
    const users = await this.getAllUsers();
    const backup = {
      version: this.version,
      exportedAt: new Date().toISOString(),
      users,
    };
    return JSON.stringify(backup, null, 2);
  }

  /**
   * Importa dados de um backup
   */
  async importData(backupData: string): Promise<void> {
    if (!this.db) await this.init();

    const backup = JSON.parse(backupData);
    const users = backup.users as UserCredential[];

    for (const user of users) {
      try {
        const exists = await this.usernameExists(user.username);
        if (!exists) {
          await this.addUser({
            username: user.username,
            email: user.email,
            password: user.password,
            role: user.role,
            isFounder: user.isFounder,
            avatar: user.avatar,
            userId: user.userId,
            isActive: user.isActive,
          });
        }
      } catch (error) {
        console.error(`Erro ao importar usuário ${user.username}:`, error);
      }
    }
  }

  /**
   * Limpa todos os dados do banco
   */
  async clearAll(): Promise<void> {
    if (!this.db) await this.init();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([this.storeName], 'readwrite');
      const objectStore = transaction.objectStore(this.storeName);
      const request = objectStore.clear();

      request.onsuccess = () => {
        console.log('Banco de dados limpo');
        resolve();
      };

      request.onerror = () => {
        reject(request.error);
      };
    });
  }
}

// Exportar instância singleton
export const legendDB = new LegendDatabase();
