
export const SERVER_INFO = {
  name: "LEGEND ROLEPLAY",
  ip: "178.132.198.232:28815",
  discordUrl: "https://discord.gg/Ysg7ZzAGk",
  logoUrl: "/logo.png", 
  heroVideo: "https://assets.mixkit.co/videos/preview/mixkit-top-view-of-a-car-driving-on-a-highway-34537-large.mp4",
};

export const FORUM_CATEGORIES = [
  { id: 'denuncia', name: 'Denunciar Player', icon: 'ShieldAlert', color: 'text-red-500' },
  { id: 'suporte', name: 'Solicitar Suporte', icon: 'LifeBuoy', color: 'text-blue-500' },
  { id: 'tecnico', name: 'Suporte Técnico', icon: 'Settings', color: 'text-amber-500' },
];

export const TOPIC_STATUS = {
  PENDING: { id: 'pending', label: 'Em Análise', color: 'bg-amber-500/20 text-amber-500 border-amber-500/50' },
  APPROVED: { id: 'approved', label: 'Aprovada', color: 'bg-green-500/20 text-green-500 border-green-500/50' },
  REJECTED: { id: 'rejected', label: 'Reprovada', color: 'bg-red-500/20 text-red-500 border-red-500/50' },
};

export const RULES = [
  {
    title: "O que é Roleplay?",
    description: "É a interpretação de um personagem em um mundo virtual, agindo como se fosse na vida real dentro das limitações do jogo.",
    icon: "UserCircle"
  },
  {
    title: "DM (Deathmatch)",
    description: "Matar ou agredir outros jogadores sem um motivo plausível dentro da história do seu personagem.",
    icon: "Sword"
  },
  {
    title: "MG (Metagaming)",
    description: "Usar informações de fora do jogo (como Discord ou stream) para benefício do seu personagem dentro do servidor.",
    icon: "Radio"
  },
  {
    title: "PG (Power Gaming)",
    description: "Fazer coisas impossíveis na vida real ou não dar chance de reação ao próximo jogador em uma ação.",
    icon: "Zap"
  },
  {
    title: "RK (Revenge Kill)",
    description: "Tentar se vingar de alguém que te matou logo após você 'renascer', ignorando o esquecimento da morte.",
    icon: "RotateCcw"
  },
  {
    title: "DB (Drive-By)",
    description: "Atirar de dentro de um veículo em movimento ou atropelar propositalmente para matar sem motivo de RP.",
    icon: "CarFront"
  },
  {
    title: "TK (Team Kill)",
    description: "Matar membros da sua própria equipe, facção ou corporação de forma intencional e sem contexto.",
    icon: "Users"
  }
];

export const SYSTEMS = [
  {
    title: "Sistemas Exclusivos",
    description: "Scripts únicos desenvolvidos do zero para proporcionar uma experiência que você não encontra em outro lugar.",
    img: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&w=800&q=80"
  },
  {
    title: "Otimização Extrema",
    description: "Servidor focado em alta performance, garantindo um FPS estável mesmo em áreas com muitos jogadores.",
    img: "https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&w=800&q=80"
  },
  {
    title: "Realismo Avançado",
    description: "Economia balanceada, sistemas de empregos dinâmicos e mecânicas que simulam a vida real com precisão.",
    img: "https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?auto=format&fit=crop&w=800&q=80"
  }
];
