import path from 'path';
import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig(({ mode }) => {
    const env = loadEnv(mode, '.', '');
    return {
      server: {
        port: 3001,
        host: '0.0.0.0',
        middlewareMode: false,
        allowedHosts: [
          'localhost',
          '127.0.0.1',
          '3001-ii0qu5ewmutr33j5sl1xz-7226e12d.us2.manus.computer',
          '3003-ii0qu5ewmutr33j5sl1xz-7226e12d.us2.manus.computer',
          '.manus.computer'
        ]
      },
      preview: {
        port: 3000,
        host: '0.0.0.0',
      },
      plugins: [react()],
      define: {
        'process.env.API_KEY': JSON.stringify(env.GEMINI_API_KEY),
        'process.env.GEMINI_API_KEY': JSON.stringify(env.GEMINI_API_KEY)
      },
      resolve: {
        alias: {
          '@': path.resolve(__dirname, '.'),
        }
      },
      build: {
        outDir: 'dist',
        assetsDir: 'assets',
        sourcemap: false,
        minify: 'terser',
        rollupOptions: {
          output: {
            manualChunks: undefined,
          }
        }
      }
    };
});
